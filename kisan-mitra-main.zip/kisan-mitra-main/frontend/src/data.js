/**
 * Kisan Mitra - Mock JSON Data
 * Follows the EXACT Shared Data Model:
 * - Mandi: id, name, location, crop, price, priceHistory[7 days], lastUpdated
 * - Farmer: id, name, village, phone
 * - Lot: id, farmerId, crop, quantity, grade (A/B/C), status (listed/matched/pickedup/paid)
 * - Buyer: id, name, type, verified, rating, demand{crop, quantity}
 * - Offer: id, lotId, buyerId, price, status (pending/accepted/rejected)
 * - Transaction: id, offerId, paymentStatus, logisticsStatus
 * - Grievance: id, transactionId, message, status
 * - PriceAlert: id, crop, mandiId, changePercent, direction, timestamp
 */

export const initialMandis = [
  {
    id: "mandi-1",
    name: "Neemuch Mandi",
    location: "Neemuch, Madhya Pradesh",
    crop: "Soybean",
    price: 4720,
    priceHistory: [4500, 4550, 4610, 4580, 4650, 4700, 4720],
    lastUpdated: "Today, 11:30 AM"
  },
  {
    id: "mandi-2",
    name: "Indore APMC",
    location: "Indore, Madhya Pradesh",
    crop: "Wheat",
    price: 2480,
    priceHistory: [2390, 2410, 2420, 2450, 2460, 2470, 2480],
    lastUpdated: "Today, 10:15 AM"
  },
  {
    id: "mandi-3",
    name: "Mandsaur Krishi Mandi",
    location: "Mandsaur, Madhya Pradesh",
    crop: "Mustard",
    price: 5450,
    priceHistory: [5600, 5580, 5520, 5490, 5470, 5460, 5450],
    lastUpdated: "Today, 12:00 PM"
  },
  {
    id: "mandi-4",
    name: "Nashik APMC",
    location: "Nashik, Maharashtra",
    crop: "Onion",
    price: 1850,
    priceHistory: [1600, 1650, 1720, 1750, 1800, 1820, 1850],
    lastUpdated: "Today, 09:45 AM"
  },
  {
    id: "mandi-5",
    name: "Ujjain Grain Market",
    location: "Ujjain, Madhya Pradesh",
    crop: "Chana",
    price: 5980,
    priceHistory: [5850, 5880, 5900, 5920, 5950, 5970, 5980],
    lastUpdated: "Today, 11:00 AM"
  },
  {
    id: "mandi-6",
    name: "Karnal Mandi",
    location: "Karnal, Haryana",
    crop: "Paddy",
    price: 3120,
    priceHistory: [3200, 3180, 3160, 3150, 3140, 3130, 3120],
    lastUpdated: "Today, 10:45 AM"
  }
];

export const initialFarmers = [
  {
    id: "farmer-1",
    name: "Ramesh Patel",
    village: "Pipliya Mandi, Malwa",
    phone: "+91 98261 45120"
  },
  {
    id: "farmer-2",
    name: "Baldev Singh",
    village: "Kotra, Mandsaur",
    phone: "+91 94140 78219"
  },
  {
    id: "farmer-3",
    name: "Savita Bai",
    village: "Barwaha, Khargone",
    phone: "+91 97552 11409"
  },
  {
    id: "farmer-4",
    name: "Jagdish Meena",
    village: "Shamgarh, Ratlam",
    phone: "+91 98934 62155"
  }
];

export const initialLots = [
  {
    id: "lot-1",
    farmerId: "farmer-1",
    crop: "Soybean",
    quantity: 45, // in quintals
    grade: "A",
    status: "listed"
  },
  {
    id: "lot-2",
    farmerId: "farmer-1",
    crop: "Wheat",
    quantity: 80,
    grade: "A",
    status: "matched"
  },
  {
    id: "lot-3",
    farmerId: "farmer-2",
    crop: "Mustard",
    quantity: 35,
    grade: "B",
    status: "pickedup"
  },
  {
    id: "lot-4",
    farmerId: "farmer-3",
    crop: "Chana",
    quantity: 60,
    grade: "A",
    status: "paid"
  },
  {
    id: "lot-5",
    farmerId: "farmer-4",
    crop: "Wheat",
    quantity: 120,
    grade: "B",
    status: "listed"
  },
  {
    id: "lot-6",
    farmerId: "farmer-2",
    crop: "Soybean",
    quantity: 50,
    grade: "C",
    status: "listed"
  }
];

export const initialBuyers = [
  {
    id: "buyer-1",
    name: "AgroHarvest Agri-Ventures",
    type: "Institutional Buyer",
    verified: true,
    rating: 4.8,
    demand: {
      crop: "Wheat",
      quantity: 500
    }
  },
  {
    id: "buyer-2",
    name: "Malwa Oil & Flour Mills",
    type: "Processor / Mill",
    verified: true,
    rating: 4.6,
    demand: {
      crop: "Soybean",
      quantity: 350
    }
  },
  {
    id: "buyer-3",
    name: "Kisan Seva Farmers Producer Org",
    type: "Aggregator / FPO",
    verified: true,
    rating: 4.9,
    demand: {
      crop: "Chana",
      quantity: 200
    }
  },
  {
    id: "buyer-4",
    name: "FreshField Foods Network",
    type: "Retail Chain",
    verified: false,
    rating: 4.2,
    demand: {
      crop: "Mustard",
      quantity: 150
    }
  }
];

export const initialOffers = [
  {
    id: "offer-1",
    lotId: "lot-2",
    buyerId: "buyer-1",
    price: 2490, // per quintal
    status: "accepted"
  },
  {
    id: "offer-2",
    lotId: "lot-1",
    buyerId: "buyer-2",
    price: 4750,
    status: "pending"
  },
  {
    id: "offer-3",
    lotId: "lot-3",
    buyerId: "buyer-4",
    price: 5420,
    status: "accepted"
  },
  {
    id: "offer-4",
    lotId: "lot-4",
    buyerId: "buyer-3",
    price: 6010,
    status: "accepted"
  },
  {
    id: "offer-5",
    lotId: "lot-5",
    buyerId: "buyer-1",
    price: 2420,
    status: "pending"
  },
  {
    id: "offer-6",
    lotId: "lot-1",
    buyerId: "buyer-3",
    price: 4680,
    status: "rejected"
  }
];

export const initialTransactions = [
  {
    id: "txn-1",
    offerId: "offer-1",
    paymentStatus: "in_escrow", // pending, in_escrow, paid
    logisticsStatus: "in_transit" // pickup_scheduled, in_transit, delivered
  },
  {
    id: "txn-2",
    offerId: "offer-3",
    paymentStatus: "pending",
    logisticsStatus: "pickup_scheduled"
  },
  {
    id: "txn-3",
    offerId: "offer-4",
    paymentStatus: "paid",
    logisticsStatus: "delivered"
  }
];

export const initialGrievances = [
  {
    id: "grv-1",
    transactionId: "txn-1",
    message: "Transporter truck delayed by 4 hours; small weight difference observed on weighing slip.",
    status: "in_review" // open, in_review, resolved
  },
  {
    id: "grv-2",
    transactionId: "txn-3",
    message: "Bank transfer acknowledgment slip was uploaded late by the buyer.",
    status: "resolved"
  }
];

export const initialPriceAlerts = [
  {
    id: "alert-1",
    crop: "Soybean",
    mandiId: "mandi-1",
    changePercent: 4.8,
    direction: "up", // "up" or "down"
    timestamp: "25 Sep 2026, 11:30 AM"
  },
  {
    id: "alert-2",
    crop: "Mustard",
    mandiId: "mandi-3",
    changePercent: -2.6,
    direction: "down",
    timestamp: "25 Sep 2026, 12:00 PM"
  },
  {
    id: "alert-3",
    crop: "Onion",
    mandiId: "mandi-4",
    changePercent: 15.6,
    direction: "up",
    timestamp: "25 Sep 2026, 09:45 AM"
  },
  {
    id: "alert-4",
    crop: "Wheat",
    mandiId: "mandi-2",
    changePercent: 3.7,
    direction: "up",
    timestamp: "25 Sep 2026, 10:15 AM"
  }
];
