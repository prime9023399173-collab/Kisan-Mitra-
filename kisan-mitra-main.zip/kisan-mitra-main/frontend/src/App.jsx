import React, { useState } from "react";
import { AppProvider, useApp } from "./context/AppContext";
import Navbar from "./components/Navbar";
import PriceAlertsTicker from "./components/PriceAlertsTicker";
import FarmerDashboard from "./components/FarmerDashboard";
import BuyerDashboard from "./components/BuyerDashboard";
import IvrsSimulator from "./components/IvrsSimulator";
import MandiAdminView from "./components/MandiAdminView";
import MobileApp from "./mobile/MobileApp";
import Chatbot from "./components/Chatbot";
import { Sprout, ShieldCheck, HeartHandshake, PhoneCall, Smartphone, Monitor } from "lucide-react";

function MainContent() {
  const { role, t } = useApp();

  // Mode switcher: 'desktop' | 'mobile'
  const [viewMode, setViewMode] = useState("desktop");

  return (
    <div className="min-h-screen bg-[#F5F1E8] text-[#2D2D2D] flex flex-col font-sans">
      {/* Top Application Switcher Bar: Web Portal vs Mobile App */}
      <div className="bg-[#2D2D2D] text-white px-6 py-2.5 flex items-center justify-between text-xs z-40">
        <div className="flex items-center gap-2">
          <div className="w-2.5 h-2.5 rounded-full bg-[#4A7C59] animate-pulse" />
          <span className="font-heading font-bold text-sm tracking-wide">
            Kisan Mitra Ecosystem
          </span>
          <span className="hidden sm:inline text-white/60">
            • Agricultural Trading & Mandi Information Network
          </span>
        </div>

        <div className="flex items-center bg-black/40 rounded-xl p-1 gap-1 border border-white/10">
          <button
            onClick={() => setViewMode("desktop")}
            className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer ${
              viewMode === "desktop"
                ? "bg-[#4A7C59] text-white font-bold"
                : "text-white/70 hover:text-white"
            }`}
          >
            <Monitor size={24} className="w-4 h-4" />
            <span>Desktop Portal</span>
          </button>

          <button
            onClick={() => setViewMode("mobile")}
            className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer ${
              viewMode === "mobile"
                ? "bg-[#4A7C59] text-white font-bold"
                : "text-white/70 hover:text-white"
            }`}
          >
            <Smartphone size={24} className="w-4 h-4" />
            <span>Mobile App</span>
          </button>
        </div>
      </div>

      {/* VIEW MODE 1: DESKTOP WEB PORTAL */}
      {viewMode === "desktop" && (
        <>
          <Navbar />
          <main className="flex-1 max-w-7xl w-full mx-auto p-6 space-y-6">
            {role !== "ivrs" && <PriceAlertsTicker />}
            {role === "farmer" && <FarmerDashboard />}
            {role === "buyer" && <BuyerDashboard />}
            {role === "ivrs" && <IvrsSimulator />}
            {role === "mandi" && <MandiAdminView />}
          </main>

          <footer className="bg-white border-t border-[#e2dcd0] mt-12 py-8">
            <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-[#8B6F47]">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-[#4A7C59] text-white flex items-center justify-center">
                  <Sprout size={24} />
                </div>
                <div>
                  <span className="font-heading font-bold text-sm text-[#2D2D2D] block">
                    {t.appTitle}
                  </span>
                  <span>{t.appSubtitle}</span>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-6">
                <div className="flex items-center gap-1.5">
                  <ShieldCheck size={24} className="text-[#4A7C59]" />
                  <span>APMC Benchmarks & Volatility Tracking</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <HeartHandshake size={24} className="text-[#8B6F47]" />
                  <span>Escrow Protected Settlements</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <PhoneCall size={24} className="text-[#4A7C59]" />
                  <span>Toll-Free IVRS Helpline 1800-KISAN</span>
                </div>
              </div>

              <div className="text-center md:text-right">
                <span>Design System & Data Model Compliant</span>
                <div className="text-[11px] text-[#2D2D2D] font-mono mt-0.5">
                  #4A7C59 • #8B6F47 • #F5F1E8 • #2D2D2D • #D97706
                </div>
              </div>
            </div>
          </footer>
        </>
      )}

      {/* VIEW MODE 2: MOBILE APPLICATION (Simulated Phone Container) */}
      {viewMode === "mobile" && (
        <div className="flex-1 py-8 px-4 flex flex-col items-center justify-center">
          <div className="text-center mb-4">
            <span className="font-heading font-bold text-lg text-[#2D2D2D] block">
              Kisan Mitra Mobile Application
            </span>
            <span className="text-xs text-[#8B6F47]">
              PWA Installable • Ready for Capacitor Android / iOS Build
            </span>
          </div>

          {/* Mobile Phone Shell */}
          <MobileApp />
        </div>
      )}

      {/* Interactive AI Chatbot & Slot Scheduler */}
      <Chatbot />
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <MainContent />
    </AppProvider>
  );
}
