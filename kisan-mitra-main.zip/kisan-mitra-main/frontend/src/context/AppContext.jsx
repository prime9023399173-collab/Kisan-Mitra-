import React, { createContext, useContext, useState, useEffect, useRef } from "react";
import {
  initialMandis,
  initialFarmers,
  initialLots,
  initialBuyers,
  initialOffers,
  initialTransactions,
  initialGrievances,
  initialPriceAlerts
} from "../data";
import { translations } from "../translations";

const AppContext = createContext();

export const AppProvider = ({ children }) => {
  // Navigation Role state: 'farmer' | 'buyer' | 'ivrs' | 'mandi'
  const [role, setRole] = useState("farmer");

  // Multi-Language state: 'hi' | 'en' | 'mr'
  const [lang, setLang] = useState("hi");
  const t = translations[lang] || translations.hi;

  // Selected profiles for role demo simulation
  const [activeFarmerId, setActiveFarmerId] = useState("farmer-1");
  const [activeBuyerId, setActiveBuyerId] = useState("buyer-1");

  // App data state initialized from data.js
  const [mandis, setMandis] = useState(initialMandis);
  const [farmers] = useState(initialFarmers);
  const [lots, setLots] = useState(initialLots);
  const [buyers, setBuyers] = useState(initialBuyers);
  const [offers, setOffers] = useState(initialOffers);
  const [transactions, setTransactions] = useState(initialTransactions);
  const [grievances, setGrievances] = useState(initialGrievances);
  const [priceAlerts, setPriceAlerts] = useState(initialPriceAlerts);
  const [slots, setSlots] = useState([
    {
      id: 'SLOT-101',
      token: 'KM-NMC-2026-8491',
      farmerName: 'Ramesh Patel',
      phone: '+91 98261 45120',
      mandi: 'Neemuch Mandi',
      crop: 'Soybean',
      quantity: 50,
      date: '2026-10-10',
      timeSlot: '09:00 AM - 12:00 PM',
      vehicleType: 'Tractor Trolley',
      gateStatus: 'CONFIRMED',
      createdAt: new Date().toISOString()
    }
  ]);

  // Sync state timestamp
  const lastUpdatedRef = useRef(0);
  const wsRef = useRef(null);
  const [syncStatus, setSyncStatus] = useState("active");

  // Initialize WebSocket for real-time sync
  useEffect(() => {
    const ws = new WebSocket(`ws://${window.location.host}`);
    wsRef.current = ws;
    ws.onopen = () => console.log("WebSocket connected");
    ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        if (data && data.updatedAt && data.updatedAt > lastUpdatedRef.current) {
          lastUpdatedRef.current = data.updatedAt;
          if (data.lots) setLots(data.lots);
          if (data.offers) setOffers(data.offers);
          if (data.transactions) setTransactions(data.transactions);
          if (data.grievances) setGrievances(data.grievances);
          if (data.mandis) setMandis(data.mandis);
          if (data.priceAlerts) setPriceAlerts(data.priceAlerts);
          if (data.slots) setSlots(data.slots);
          setSyncStatus("synced");
        }
      } catch (e) {
        // ignore parse errors
      }
    };
    ws.onerror = () => setSyncStatus("offline");
    ws.onclose = () => setSyncStatus("offline");
    return () => {
      ws.close();
    };
  }, []);

  // Synchronize state with /api/sync for multi-device support
  const broadcastSync = (updatedData) => {
    const timestamp = Date.now();
    lastUpdatedRef.current = timestamp;

    const payload = {
      mandis: updatedData.mandis || mandis,
      lots: updatedData.lots || lots,
      offers: updatedData.offers || offers,
      transactions: updatedData.transactions || transactions,
      grievances: updatedData.grievances || grievances,
      priceAlerts: updatedData.priceAlerts || priceAlerts,
      slots: updatedData.slots || slots,
      updatedAt: timestamp
    };

    fetch("/api/sync", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    }).catch(() => {
      // Offline fallback
    });
  };

  // Poll /api/sync periodically to receive updates made on other devices (phone / laptop)
  useEffect(() => {
    // Initial fetch
    fetch("/api/sync")
      .then((res) => res.json())
      .then((data) => {
        if (data && data.updatedAt) {
          if (data.lots) setLots(data.lots);
          if (data.offers) setOffers(data.offers);
          if (data.transactions) setTransactions(data.transactions);
          if (data.grievances) setGrievances(data.grievances);
          if (data.mandis) setMandis(data.mandis);
          if (data.priceAlerts) setPriceAlerts(data.priceAlerts);
          if (data.slots) setSlots(data.slots);
          lastUpdatedRef.current = data.updatedAt;
        } else {
          // Initialize server cache if not initialized
          broadcastSync({
            mandis,
            lots,
            offers,
            transactions,
            grievances,
            priceAlerts,
            slots
          });
        }
      })
      .catch(() => {
        setSyncStatus("local");
      });

    // Background poll every 1200ms
    const interval = setInterval(() => {
      fetch("/api/sync")
        .then((res) => res.json())
        .then((data) => {
          if (data && data.updatedAt && data.updatedAt > lastUpdatedRef.current) {
            lastUpdatedRef.current = data.updatedAt;
            if (data.lots) setLots(data.lots);
            if (data.offers) setOffers(data.offers);
            if (data.transactions) setTransactions(data.transactions);
            if (data.grievances) setGrievances(data.grievances);
            if (data.mandis) setMandis(data.mandis);
            if (data.priceAlerts) setPriceAlerts(data.priceAlerts);
            if (data.slots) setSlots(data.slots);
            setSyncStatus("synced");
          }
        })
        .catch(() => {
          setSyncStatus("offline");
        });
    }, 1200);

    return () => clearInterval(interval);
  }, []);

  // Notification badge counts
  const pendingOffersCount = offers.filter(
    (o) => {
      const lot = lots.find((l) => l.id === o.lotId);
      return lot && lot.farmerId === activeFarmerId && o.status === "pending";
    }
  ).length;

  const openGrievancesCount = grievances.filter((g) => g.status !== "resolved").length;

  // Add Lot (Farmer Action or IVRS Action)
  const addLot = ({ crop, quantity, grade, farmerId }) => {
    const newLot = {
      id: `lot-${Date.now()}`,
      farmerId: farmerId || activeFarmerId,
      crop,
      quantity: Number(quantity),
      grade,
      status: "listed"
    };
    const nextLots = [newLot, ...lots];
    setLots(nextLots);
    broadcastSync({ lots: nextLots });
    return newLot;
  };

  // Place Offer (Buyer Action)
  const makeOffer = ({ lotId, price, buyerId }) => {
    const newOffer = {
      id: `offer-${Date.now()}`,
      lotId,
      buyerId: buyerId || activeBuyerId,
      price: Number(price),
      status: "pending"
    };
    const nextOffers = [newOffer, ...offers];
    setOffers(nextOffers);
    broadcastSync({ offers: nextOffers });
    return newOffer;
  };

  // Accept Offer (Farmer Action)
  const acceptOffer = (offerId) => {
    const targetOffer = offers.find((o) => o.id === offerId);
    if (!targetOffer) return;

    const nextOffers = offers.map((o) => {
      if (o.id === offerId) {
        return { ...o, status: "accepted" };
      }
      if (o.lotId === targetOffer.lotId && o.status === "pending") {
        return { ...o, status: "rejected" };
      }
      return o;
    });

    const nextLots = lots.map((l) =>
      l.id === targetOffer.lotId ? { ...l, status: "matched" } : l
    );

    const newTxn = {
      id: `txn-${Date.now()}`,
      offerId: offerId,
      paymentStatus: "in_escrow",
      logisticsStatus: "pickup_scheduled"
    };
    const nextTransactions = [newTxn, ...transactions];

    setOffers(nextOffers);
    setLots(nextLots);
    setTransactions(nextTransactions);

    broadcastSync({
      offers: nextOffers,
      lots: nextLots,
      transactions: nextTransactions
    });
  };

  // Reject Offer (Farmer Action)
  const rejectOffer = (offerId) => {
    const nextOffers = offers.map((o) =>
      o.id === offerId ? { ...o, status: "rejected" } : o
    );
    setOffers(nextOffers);
    broadcastSync({ offers: nextOffers });
  };

  // Update Transaction Progress (Logistics / Payment)
  const updateTransaction = (txnId, updates) => {
    let nextLots = lots;
    const nextTransactions = transactions.map((t) => {
      if (t.id === txnId) {
        const updated = { ...t, ...updates };
        const offer = offers.find((o) => o.id === updated.offerId);
        if (offer) {
          if (updated.paymentStatus === "paid") {
            nextLots = nextLots.map((l) =>
              l.id === offer.lotId ? { ...l, status: "paid" } : l
            );
          } else if (
            updated.logisticsStatus === "in_transit" ||
            updated.logisticsStatus === "delivered"
          ) {
            nextLots = nextLots.map((l) =>
              l.id === offer.lotId && l.status === "matched"
                ? { ...l, status: "pickedup" }
                : l
            );
          }
        }
        return updated;
      }
      return t;
    });

    setTransactions(nextTransactions);
    setLots(nextLots);
    broadcastSync({ transactions: nextTransactions, lots: nextLots });
  };

  // Update Buyer Demand
  const updateBuyerDemand = (buyerId, newDemand) => {
    setBuyers((prev) =>
      prev.map((b) => (b.id === buyerId ? { ...b, demand: newDemand } : b))
    );
  };

  // Raise Grievance (Farmer or Buyer)
  const addGrievance = ({ transactionId, message }) => {
    const newGrievance = {
      id: `grv-${Date.now()}`,
      transactionId,
      message,
      status: "open"
    };
    const nextGrievances = [newGrievance, ...grievances];
    setGrievances(nextGrievances);
    broadcastSync({ grievances: nextGrievances });
    return newGrievance;
  };

  // Resolve or Update Grievance Status (Mandi Admin Action)
  const updateGrievanceStatus = (id, status) => {
    const nextGrievances = grievances.map((g) =>
      g.id === id ? { ...g, status } : g
    );
    setGrievances(nextGrievances);
    broadcastSync({ grievances: nextGrievances });
  };

  // Update Mandi Daily Rate (Mandi Admin Action)
  const updateMandiPrice = (mandiId, newPrice) => {
    const numPrice = Number(newPrice);
    let nextPriceAlerts = priceAlerts;

    const nextMandis = mandis.map((m) => {
      if (m.id === mandiId) {
        const oldPrice = m.price;
        const diff = numPrice - oldPrice;
        const changePercent = Number(((diff / oldPrice) * 100).toFixed(1));
        const direction = diff >= 0 ? "up" : "down";
        const updatedHistory = [...m.priceHistory.slice(1), numPrice];

        if (diff !== 0) {
          const newAlert = {
            id: `alert-${Date.now()}`,
            crop: m.crop,
            mandiId: m.id,
            changePercent: Math.abs(changePercent),
            direction,
            timestamp: "Just now"
          };
          nextPriceAlerts = [newAlert, ...nextPriceAlerts];
        }

        return {
          ...m,
          price: numPrice,
          priceHistory: updatedHistory,
          lastUpdated: "Just now"
        };
      }
      return m;
    });

    setMandis(nextMandis);
    setPriceAlerts(nextPriceAlerts);
    broadcastSync({ mandis: nextMandis, priceAlerts: nextPriceAlerts });
  };

  // Book Mandi Entry Slot or Batch Token
  const bookSlot = (slotData) => {
    const token = `KM-${(slotData.mandi || 'MND').substring(0, 3).toUpperCase()}-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;
    const newSlot = {
      id: `SLOT-${Date.now()}`,
      token,
      farmerName: slotData.farmerName || 'Ramesh Patel',
      phone: slotData.phone || '+91 98261 45120',
      mandi: slotData.mandi || 'Neemuch Mandi',
      crop: slotData.crop || 'Soybean',
      quantity: Number(slotData.quantity) || 50,
      date: slotData.date || new Date(Date.now() + 86400000).toISOString().split('T')[0],
      timeSlot: slotData.timeSlot || '09:00 AM - 12:00 PM',
      vehicleType: slotData.vehicleType || 'Tractor Trolley',
      gateStatus: 'CONFIRMED',
      createdAt: new Date().toISOString()
    };
    const nextSlots = [newSlot, ...slots];
    setSlots(nextSlots);
    broadcastSync({ slots: nextSlots });
    return newSlot;
  };

  // Helper getters
  const getFarmer = (id) => farmers.find((f) => f.id === id);
  const getBuyer = (id) => buyers.find((b) => b.id === id);
  const getLot = (id) => lots.find((l) => l.id === id);
  const getOffer = (id) => offers.find((o) => o.id === id);
  const getMandi = (id) => mandis.find((m) => m.id === id);

  return (
    <AppContext.Provider
      value={{
        role,
        setRole,
        lang,
        setLang,
        t,
        activeFarmerId,
        setActiveFarmerId,
        activeBuyerId,
        setActiveBuyerId,
        mandis,
        farmers,
        lots,
        buyers,
        offers,
        transactions,
        grievances,
        priceAlerts,
        slots,
        setSlots,
        bookSlot,
        pendingOffersCount,
        openGrievancesCount,
        syncStatus,
        addLot,
        makeOffer,
        acceptOffer,
        rejectOffer,
        updateTransaction,
        updateBuyerDemand,
        addGrievance,
        updateGrievanceStatus,
        updateMandiPrice,
        getFarmer,
        getBuyer,
        getLot,
        getOffer,
        getMandi
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error("useApp must be used within an AppProvider");
  }
  return context;
};
