import React, { useState } from "react";
import {
  Sprout,
  User,
  ShoppingBag,
  Landmark,
  PhoneCall,
  Languages,
  Smartphone,
  Check,
  Copy,
  XCircle,
  Radio
} from "lucide-react";
import { useApp } from "../context/AppContext";

export default function Navbar() {
  const {
    role,
    setRole,
    lang,
    setLang,
    t,
    farmers,
    activeFarmerId,
    setActiveFarmerId,
    buyers,
    activeBuyerId,
    setActiveBuyerId,
    pendingOffersCount,
    openGrievancesCount,
    syncStatus
  } = useApp();

  const [showDeviceModal, setShowDeviceModal] = useState(false);
  const [copied, setCopied] = useState(false);

  const localNetworkUrl = "http://192.168.0.102:5173";

  const handleCopyUrl = () => {
    navigator.clipboard.writeText(localNetworkUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <header className="bg-white border-b border-[#e2dcd0] sticky top-0 z-30 shadow-md">
      <div className="max-w-7xl mx-auto px-6 py-4 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        {/* Left-aligned Logo */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#4A7C59] text-white flex items-center justify-center shadow-md">
            <Sprout size={24} />
          </div>
          <div>
            <span className="font-heading font-bold text-2xl text-[#2D2D2D] tracking-tight block">
              {t.appTitle}
            </span>
            <span className="text-xs text-[#8B6F47] font-medium block">
              {t.appSubtitle}
            </span>
          </div>
        </div>

        {/* Right-aligned Navigation Controls: Multi-Device Sync + Language Switcher + Role Tabs */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Multi-Device Connect Button */}
          <button
            onClick={() => setShowDeviceModal(true)}
            className="flex items-center gap-1.5 bg-[#F5F1E8] border border-[#4A7C59] text-[#4A7C59] px-3 py-1.5 rounded-xl text-xs font-bold hover:bg-[#e8e2d5] cursor-pointer"
            title="Open on phone on same Wi-Fi"
          >
            <Smartphone size={24} className="w-4 h-4" />
            <span className="hidden sm:inline">Connect Phone</span>
            <span className="w-2 h-2 rounded-full bg-[#4A7C59] animate-pulse" />
          </button>

          {/* Multi-Language Selector Dropdown */}
          <div className="flex items-center bg-[#F5F1E8] border border-[#ded8cb] rounded-xl px-2.5 py-1.5 gap-1.5">
            <Languages size={24} className="text-[#8B6F47] w-4 h-4" />
            <select
              value={lang}
              onChange={(e) => setLang(e.target.value)}
              className="bg-transparent text-xs font-semibold text-[#2D2D2D] focus:outline-none cursor-pointer"
            >
              <option value="hi">हिन्दी (Hindi)</option>
              <option value="en">English (EN)</option>
              <option value="mr">मराठी (Marathi)</option>
            </select>
          </div>

          {/* Farmer Dashboard Tab */}
          <button
            onClick={() => setRole("farmer")}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold transition-colors flex items-center gap-2 cursor-pointer ${
              role === "farmer"
                ? "bg-[#4A7C59] text-white shadow-md"
                : "bg-[#F5F1E8] text-[#2D2D2D] hover:bg-[#e8e2d5]"
            }`}
          >
            <User size={24} />
            <span>{t.farmerTab}</span>
            {pendingOffersCount > 0 && (
              <span className="text-[11px] px-1.5 py-0.5 rounded-xl font-bold bg-[#D97706] text-white">
                {pendingOffersCount}
              </span>
            )}
          </button>

          {/* Mandi / Buyer Dashboard Tab */}
          <button
            onClick={() => setRole("buyer")}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold transition-colors flex items-center gap-2 cursor-pointer ${
              role === "buyer"
                ? "bg-[#4A7C59] text-white shadow-md"
                : "bg-[#F5F1E8] text-[#2D2D2D] hover:bg-[#e8e2d5]"
            }`}
          >
            <ShoppingBag size={24} />
            <span>{t.buyerTab}</span>
          </button>

          {/* Standalone IVRS Simulator Tab */}
          <button
            onClick={() => setRole("ivrs")}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold transition-colors flex items-center gap-2 cursor-pointer ${
              role === "ivrs"
                ? "bg-[#4A7C59] text-white shadow-md"
                : "bg-[#F5F1E8] text-[#2D2D2D] hover:bg-[#e8e2d5]"
            }`}
          >
            <PhoneCall size={24} />
            <span>{t.ivrsTab}</span>
          </button>

          {/* Mandi Admin Tab */}
          <button
            onClick={() => setRole("mandi")}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold transition-colors flex items-center gap-2 cursor-pointer ${
              role === "mandi"
                ? "bg-[#4A7C59] text-white shadow-md"
                : "bg-[#F5F1E8] text-[#2D2D2D] hover:bg-[#e8e2d5]"
            }`}
          >
            <Landmark size={24} />
            <span>{t.adminTab}</span>
            {openGrievancesCount > 0 && (
              <span className="text-[11px] px-1.5 py-0.5 rounded-xl font-bold bg-[#D97706] text-white">
                {openGrievancesCount}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* Role Profile Persona Context Bar */}
      <div className="bg-[#F5F1E8] border-t border-[#e2dcd0] px-6 py-2">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2 text-[#8B6F47]">
            <span className="font-semibold text-[#2D2D2D]">Persona Mode:</span>
            {role === "farmer" && (
              <span>Farmer dashboard with 3-mandi rate comparison, Sell/Wait advisory & lot stepper.</span>
            )}
            {role === "buyer" && (
              <span>Trading desk with demand broadcasting, live ticker & aggregated batching.</span>
            )}
            {role === "ivrs" && (
              <span>Interactive voice response helpline simulator with keypad DTMF.</span>
            )}
            {role === "mandi" && (
              <span>APMC administration desk for MSP management and grievance resolution.</span>
            )}
          </div>

          <div className="flex items-center gap-3">
            <span className="inline-flex items-center gap-1 text-[11px] font-bold text-[#4A7C59]">
              <span className="w-2 h-2 rounded-full bg-[#4A7C59]" />
              Live Host Sync: Active
            </span>

            {(role === "farmer" || role === "ivrs") && (
              <div className="flex items-center gap-2">
                <label className="text-[#2D2D2D] font-medium">Farmer Profile:</label>
                <select
                  value={activeFarmerId}
                  onChange={(e) => setActiveFarmerId(e.target.value)}
                  className="bg-white border border-[#ded8cb] rounded-xl px-2.5 py-1 text-xs text-[#2D2D2D] focus:outline-none focus:ring-1 focus:ring-[#4A7C59]"
                >
                  {farmers.map((f) => (
                    <option key={f.id} value={f.id}>
                      {f.name} ({f.village})
                    </option>
                  ))}
                </select>
              </div>
            )}

            {role === "buyer" && (
              <div className="flex items-center gap-2">
                <label className="text-[#2D2D2D] font-medium">Buyer Profile:</label>
                <select
                  value={activeBuyerId}
                  onChange={(e) => setActiveBuyerId(e.target.value)}
                  className="bg-white border border-[#ded8cb] rounded-xl px-2.5 py-1 text-xs text-[#2D2D2D] focus:outline-none focus:ring-1 focus:ring-[#4A7C59]"
                >
                  {buyers.map((b) => (
                    <option key={b.id} value={b.id}>
                      {b.name} ({b.type})
                    </option>
                  ))}
                </select>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Multi-Device Connection Modal */}
      {showDeviceModal && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl shadow-md p-6 max-w-md w-full border border-[#ded8cb] space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-[#F5F1E8]">
              <div className="flex items-center gap-2">
                <div className="text-[#4A7C59] flex items-center">
                  <Smartphone size={24} />
                </div>
                <h3 className="font-heading font-bold text-lg text-[#2D2D2D] m-0">
                  Connect Multiple Devices
                </h3>
              </div>
              <button
                onClick={() => setShowDeviceModal(false)}
                className="text-[#8B6F47] hover:text-[#2D2D2D] cursor-pointer"
              >
                <XCircle size={24} />
              </button>
            </div>

            <p className="text-xs text-[#8B6F47] leading-relaxed">
              Open Kisan Mitra on your <strong>mobile phone, tablet, or secondary laptop</strong> connected to the same Wi-Fi. All actions (creating produce lots, accepting bids, tracking escrow) synchronize in real-time!
            </p>

            {/* Network Address Box */}
            <div className="bg-[#F5F1E8] p-3 rounded-xl border border-[#ded8cb] space-y-2">
              <span className="text-[11px] font-bold text-[#8B6F47] block">
                Local Host Network URL:
              </span>
              <div className="flex items-center justify-between bg-white border border-[#ded8cb] rounded-xl p-2 font-mono text-sm font-bold text-[#4A7C59]">
                <span>{localNetworkUrl}</span>
                <button
                  onClick={handleCopyUrl}
                  className="bg-[#F5F1E8] hover:bg-[#ded8cb] text-[#2D2D2D] px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center gap-1 cursor-pointer transition-colors"
                >
                  {copied ? <Check size={24} className="w-3.5 h-3.5 text-[#4A7C59]" /> : <Copy size={24} className="w-3.5 h-3.5" />}
                  <span>{copied ? "Copied" : "Copy"}</span>
                </button>
              </div>
            </div>

            <div className="bg-[#fff8eb] border border-[#D97706] p-3 rounded-xl flex items-center gap-2 text-xs text-[#2D2D2D]">
              <div className="w-2.5 h-2.5 rounded-full bg-[#4A7C59] shrink-0" />
              <span>
                <strong>Live Sync Enabled:</strong> Changes made on phone appear instantly on laptop and vice versa.
              </span>
            </div>

            <button
              onClick={() => setShowDeviceModal(false)}
              className="w-full bg-[#4A7C59] text-white py-2.5 rounded-xl font-bold text-xs hover:bg-[#3d6749] shadow-md cursor-pointer"
            >
              Done
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
