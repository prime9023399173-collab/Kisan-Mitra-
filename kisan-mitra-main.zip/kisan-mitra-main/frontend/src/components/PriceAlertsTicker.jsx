import React from "react";
import { TrendingUp, TrendingDown, Bell, AlertTriangle } from "lucide-react";
import { useApp } from "../context/AppContext";

export default function PriceAlertsTicker() {
  const { priceAlerts, getMandi } = useApp();

  if (!priceAlerts || priceAlerts.length === 0) return null;

  return (
    <div className="bg-white rounded-xl shadow-md p-4 mb-6 border border-[#e2dcd0]">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#F5F1E8]">
        <div className="flex items-center gap-2">
          <div className="text-[#D97706] flex items-center justify-center">
            <Bell size={24} />
          </div>
          <h3 className="font-heading font-semibold text-lg text-[#2D2D2D] m-0">
            Live Mandi Price Alerts
          </h3>
        </div>
        <span className="text-xs text-[#8B6F47] font-medium bg-[#F5F1E8] px-2.5 py-1 rounded-xl w-fit">
          Real-Time Market Rate Volatility
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mt-3">
        {priceAlerts.slice(0, 4).map((alert) => {
          const mandi = getMandi(alert.mandiId);
          const isUp = alert.direction === "up";

          return (
            <div
              key={alert.id}
              className="bg-[#F5F1E8] rounded-xl p-3 flex items-start justify-between gap-3 border border-[#ded8cb]"
            >
              <div className="flex flex-col">
                <div className="flex items-center gap-1.5">
                  <span className="font-heading font-semibold text-[#2D2D2D] text-sm">
                    {alert.crop}
                  </span>
                  <span className="text-xs text-[#8B6F47]">
                    • {mandi ? mandi.name : "APMC"}
                  </span>
                </div>
                <div className="text-xs text-[#2D2D2D] mt-0.5">
                  {alert.timestamp}
                </div>
              </div>

              <div
                className={`flex items-center gap-1 font-semibold text-sm px-2 py-1 rounded-xl ${
                  isUp
                    ? "text-[#4A7C59] bg-white border border-[#4A7C59]"
                    : "text-[#C0392B] bg-white border border-[#C0392B]"
                }`}
              >
                {isUp ? <TrendingUp size={24} /> : <TrendingDown size={24} />}
                <span>
                  {isUp ? "+" : "-"}
                  {alert.changePercent}%
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
