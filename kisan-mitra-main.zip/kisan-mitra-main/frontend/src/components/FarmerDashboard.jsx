import React, { useState } from "react";
import {
  Wheat,
  Sprout,
  Flower2,
  Apple,
  Carrot,
  Layers,
  Sparkles,
  TrendingUp,
  TrendingDown,
  AlertTriangle,
  Clock,
  CheckCircle2,
  XCircle,
  FileQuestion,
  ChevronRight,
  ChevronLeft,
  PlusCircle,
  ShieldCheck,
  Star,
  Info,
  MapPin,
  Check,
  Calendar,
  Ticket
} from "lucide-react";
import { useApp } from "../context/AppContext";

export default function FarmerDashboard() {
  const {
    activeFarmerId,
    getFarmer,
    lots,
    offers,
    transactions,
    grievances,
    mandis,
    buyers,
    priceAlerts,
    slots,
    addLot,
    acceptOffer,
    rejectOffer,
    addGrievance,
    t
  } = useApp();

  const farmer = getFarmer(activeFarmerId) || {
    name: "Ramesh Patel",
    village: "Pipliya Mandi",
    phone: "+91 98261 45120"
  };

  // Supported crops with representative Lucide icon
  const cropList = [
    { name: "Wheat", hindiName: "गेहूं", icon: Wheat },
    { name: "Soybean", hindiName: "सोयाबीन", icon: Sprout },
    { name: "Mustard", hindiName: "सरसों", icon: Flower2 },
    { name: "Chana", hindiName: "चना", icon: Sparkles },
    { name: "Onion", hindiName: "प्याज", icon: Apple },
    { name: "Cotton", hindiName: "कपास", icon: Layers },
    { name: "Paddy", hindiName: "धान", icon: Carrot }
  ];

  // Active selected crop for 3-mandi comparison & recommendation
  const [selectedCrop, setSelectedCrop] = useState("Soybean");

  // Create Lot 3-Step Modal State
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [step, setStep] = useState(1);
  const [lotCrop, setLotCrop] = useState("Wheat");
  const [lotQuantity, setLotQuantity] = useState(50);
  const [lotGrade, setLotGrade] = useState("A");

  // Grievance Modal State
  const [grievanceTxnId, setGrievanceTxnId] = useState(null);
  const [grievanceText, setGrievanceText] = useState("");

  // Farmer specific data
  const myLots = lots.filter((l) => l.farmerId === activeFarmerId);
  const myLotIds = myLots.map((l) => l.id);
  const myOffers = offers.filter((o) => myLotIds.includes(o.lotId));
  const myTransactions = transactions.filter((t) => {
    const off = offers.find((o) => o.id === t.offerId);
    return off && myLotIds.includes(off.lotId);
  });

  // Active price alerts for farmer's crops or selected crop
  const activeAlerts = priceAlerts.filter(
    (a) => a.crop.toLowerCase() === selectedCrop.toLowerCase() || myLots.some((l) => l.crop === a.crop)
  );

  // 3-Mandi Price Comparison for selected crop
  // Look up actual mandis or simulate realistic regional benchmarks from mandis array
  const cropMandis = mandis.filter(
    (m) => m.crop.toLowerCase() === selectedCrop.toLowerCase()
  );
  // Ensure we show 3 mandis: use existing or regional derivations
  const primaryMandi = cropMandis[0] || mandis[0];
  const mandiComparisons = [
    {
      mandiName: primaryMandi ? primaryMandi.name : "Neemuch Mandi",
      location: primaryMandi ? primaryMandi.location : "Madhya Pradesh",
      price: primaryMandi ? primaryMandi.price : 4720,
      history: primaryMandi ? primaryMandi.priceHistory : [4500, 4550, 4610, 4580, 4650, 4700, 4720]
    },
    {
      mandiName: "Indore APMC Yard",
      location: "Indore, Madhya Pradesh",
      price: primaryMandi ? Math.round(primaryMandi.price * 1.015) : 4790,
      history: primaryMandi
        ? primaryMandi.priceHistory.map((p) => Math.round(p * 1.012))
        : [4540, 4590, 4650, 4620, 4690, 4740, 4790]
    },
    {
      mandiName: "Ujjain Krishi Upaj Mandi",
      location: "Ujjain, Madhya Pradesh",
      price: primaryMandi ? Math.round(primaryMandi.price * 0.985) : 4650,
      history: primaryMandi
        ? primaryMandi.priceHistory.map((p) => Math.round(p * 0.99))
        : [4480, 4510, 4570, 4530, 4610, 4640, 4650]
    }
  ];

  // "Sell Now / Wait" Recommendation logic
  // Rule: if priceHistory rising > 5% in 3 days, show Wait
  const hist = primaryMandi ? primaryMandi.priceHistory : [4500, 4550, 4610, 4580, 4650, 4700, 4720];
  const currentPrice = hist[hist.length - 1];
  const price3DaysAgo = hist[Math.max(0, hist.length - 4)];
  const change3DaysPercent = Number((((currentPrice - price3DaysAgo) / price3DaysAgo) * 100).toFixed(1));
  const shouldWait = change3DaysPercent > 5.0;

  // Handle Create Lot Submit
  const handleCreateLotSubmit = () => {
    if (!lotQuantity || Number(lotQuantity) <= 0) return;
    addLot({
      crop: lotCrop,
      quantity: Number(lotQuantity),
      grade: lotGrade,
      farmerId: activeFarmerId
    });
    setShowCreateModal(false);
    setStep(1);
  };

  // Handle Grievance Submit
  const handleGrievanceSubmit = (e) => {
    e.preventDefault();
    if (!grievanceText.trim() || !grievanceTxnId) return;
    addGrievance({
      transactionId: grievanceTxnId,
      message: grievanceText
    });
    setGrievanceText("");
    setGrievanceTxnId(null);
  };

  return (
    <div className="space-y-6">
      {/* 1. Active Price Alert Banner (using Alert color #D97706) */}
      {activeAlerts.length > 0 && (
        <div className="bg-[#fff8eb] border-2 border-[#D97706] rounded-xl shadow-md p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-start gap-3">
            <div className="text-[#D97706] flex items-center shrink-0 mt-0.5">
              <AlertTriangle size={24} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-heading font-bold text-base text-[#2D2D2D]">
                  {t.recommendationTitle}
                </span>
                <span className="bg-[#D97706] text-white text-[11px] font-bold px-2 py-0.5 rounded-xl uppercase">
                  Alert
                </span>
              </div>
              <p className="text-sm text-[#2D2D2D] mt-0.5 font-medium">
                {activeAlerts[0].crop}: {activeAlerts[0].direction === "up" ? "तेजी (+)" : "मंदी (-)"}{" "}
                <strong>{activeAlerts[0].changePercent}%</strong> (
                {activeAlerts[0].timestamp}) • मंडी भाव में तेज हलचल जारी है।
              </p>
            </div>
          </div>

          <div className="shrink-0 flex items-center gap-2">
            <span className="text-xs text-[#8B6F47] font-semibold bg-white border border-[#D97706] px-3 py-1.5 rounded-xl">
              {activeAlerts.length} Active Market Alerts
            </span>
          </div>
        </div>
      )}

      {/* 2. Top Header & Quick Action */}
      <div className="bg-white rounded-xl shadow-md p-4 flex flex-col md:flex-row md:items-center justify-between gap-4 border border-[#e2dcd0]">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="font-heading font-bold text-2xl text-[#2D2D2D] m-0">
              {farmer.name}
            </h1>
            <span className="bg-[#4A7C59] text-white text-xs font-semibold px-2.5 py-1 rounded-xl flex items-center gap-1.5">
              <ShieldCheck size={24} />
              <span>{t.verifiedFarmer}</span>
            </span>
          </div>
          <p className="text-sm text-[#8B6F47] mt-1 font-sans">
            {t.village}: <span className="font-semibold text-[#2D2D2D]">{farmer.village}</span> | {t.phone}:{" "}
            <span className="font-semibold text-[#2D2D2D]">{farmer.phone}</span>
          </p>
        </div>

        <button
          onClick={() => {
            setStep(1);
            setShowCreateModal(true);
          }}
          className="bg-[#4A7C59] text-white rounded-xl px-5 py-3 text-base font-semibold flex items-center justify-center gap-2 shadow-md hover:bg-[#3d6749] transition-colors cursor-pointer"
        >
          <PlusCircle size={24} />
          <span>{t.createLotBtn}</span>
        </button>
      </div>

      {/* 3. Crop Selection: Large Icon Cards (Tap to see today's price at 3 mandis) */}
      <div className="bg-white rounded-xl shadow-md p-4 border border-[#e2dcd0]">
        <div className="flex items-center justify-between mb-3 pb-2 border-b border-[#F5F1E8]">
          <div>
            <h2 className="font-heading font-bold text-lg text-[#2D2D2D] m-0">
              {t.mandiComparisonTitle}
            </h2>
            <span className="text-xs text-[#8B6F47]">{t.selectCropTip}</span>
          </div>
          <span className="text-xs font-semibold text-[#4A7C59] bg-[#F5F1E8] px-3 py-1 rounded-xl">
            Active: {selectedCrop}
          </span>
        </div>

        {/* Large Crop Icon Cards Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-4">
          {cropList.map((crop) => {
            const IconComponent = crop.icon;
            const isSelected = selectedCrop.toLowerCase() === crop.name.toLowerCase();

            return (
              <button
                key={crop.name}
                onClick={() => setSelectedCrop(crop.name)}
                className={`rounded-xl p-4 flex flex-col items-center justify-center gap-2 text-center transition-all cursor-pointer border ${
                  isSelected
                    ? "bg-[#4A7C59] text-white border-[#4A7C59] shadow-md scale-102"
                    : "bg-[#F5F1E8] text-[#2D2D2D] border-[#ded8cb] hover:bg-[#e8e2d5]"
                }`}
              >
                <div
                  className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                    isSelected ? "bg-white/20 text-white" : "bg-white text-[#4A7C59] shadow-sm"
                  }`}
                >
                  <IconComponent size={24} />
                </div>
                <div className="flex flex-col items-center">
                  <span className="font-heading font-bold text-sm tracking-tight">
                    {crop.name}
                  </span>
                  <span
                    className={`text-xs ${
                      isSelected ? "text-white/80" : "text-[#8B6F47]"
                    }`}
                  >
                    {crop.hindiName}
                  </span>
                </div>
              </button>
            );
          })}
        </div>

        {/* 3-Mandi Price Comparison Table / Cards for Selected Crop */}
        <div className="mt-4 pt-4 border-t border-[#F5F1E8]">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {mandiComparisons.map((item, index) => {
              const diffPercent = ((item.price - item.history[item.history.length - 2]) / item.history[item.history.length - 2]) * 100;
              const isUp = diffPercent >= 0;

              return (
                <div
                  key={index}
                  className="bg-[#F5F1E8] rounded-xl p-4 border border-[#ded8cb] flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between">
                      <span className="font-heading font-bold text-base text-[#2D2D2D]">
                        {item.mandiName}
                      </span>
                      <span className="text-[11px] font-semibold text-[#8B6F47] bg-white px-2 py-0.5 rounded-xl border border-[#ded8cb]">
                        APMC {index + 1}
                      </span>
                    </div>

                    <div className="flex items-center gap-1.5 text-xs text-[#8B6F47] mt-1">
                      <MapPin size={24} className="text-[#8B6F47]" />
                      <span>{item.location}</span>
                    </div>

                    <div className="mt-4 flex items-baseline justify-between">
                      <div>
                        <span className="text-xs text-[#8B6F47] block">Today's Rate</span>
                        <span className="font-heading font-bold text-2xl text-[#2D2D2D]">
                          ₹{item.price} <span className="text-xs font-normal text-[#8B6F47]">/qtl</span>
                        </span>
                      </div>

                      {/* Trend Arrow */}
                      <div
                        className={`flex items-center gap-1 text-xs font-bold px-2 py-1 rounded-xl ${
                          isUp
                            ? "bg-white text-[#4A7C59] border border-[#4A7C59]"
                            : "bg-white text-[#C0392B] border border-[#C0392B]"
                        }`}
                      >
                        {isUp ? <TrendingUp size={24} /> : <TrendingDown size={24} />}
                        <span>
                          {isUp ? "+" : ""}
                          {diffPercent.toFixed(1)}%
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="mt-3 pt-2 border-t border-[#ded8cb] flex items-center justify-between text-[11px] text-[#8B6F47]">
                    <span>7-Day Low: ₹{Math.min(...item.history)}</span>
                    <span>7-Day High: ₹{Math.max(...item.history)}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* 4. "Sell Now / Wait" Recommendation Button & Explanation */}
        <div className="mt-4 p-4 rounded-xl border border-[#ded8cb] bg-[#fcfaf7] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="font-heading font-bold text-base text-[#2D2D2D]">
                {t.recommendationTitle} ({selectedCrop}):
              </span>
              <span
                className={`text-xs px-2.5 py-1 rounded-xl font-bold uppercase ${
                  shouldWait ? "bg-[#D97706] text-white" : "bg-[#4A7C59] text-white"
                }`}
              >
                3-Day Trend: {change3DaysPercent >= 0 ? "+" : ""}{change3DaysPercent}%
              </span>
            </div>
            <p className="text-xs text-[#8B6F47]">
              {shouldWait ? t.waitReason : t.sellReason}
            </p>
          </div>

          <div className="shrink-0">
            {shouldWait ? (
              <button
                className="w-full sm:w-auto bg-[#D97706] text-white rounded-xl px-5 py-3 font-heading font-bold text-sm flex items-center justify-center gap-2 shadow-md cursor-default"
              >
                <Clock size={24} />
                <span>{t.waitRecommendation}</span>
              </button>
            ) : (
              <button
                className="w-full sm:w-auto bg-[#4A7C59] text-white rounded-xl px-5 py-3 font-heading font-bold text-sm flex items-center justify-center gap-2 shadow-md cursor-default"
              >
                <CheckCircle2 size={24} />
                <span>{t.sellRecommendation}</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* 5. Status Stepper: Listed → Matched → Picked Up → Paid */}
      <div className="bg-white rounded-xl shadow-md p-4 border border-[#e2dcd0]">
        <div className="flex items-center justify-between mb-4 pb-2 border-b border-[#F5F1E8]">
          <div className="flex items-center gap-2">
            <div className="text-[#4A7C59] flex items-center">
              <Layers size={24} />
            </div>
            <h2 className="font-heading font-bold text-lg text-[#2D2D2D] m-0">
              Produce Lot Lifecycle Stepper (स्थिति ट्रैकर)
            </h2>
          </div>
          <span className="text-xs text-[#8B6F47]">
            {myLots.length} Active Lots
          </span>
        </div>

        {myLots.length === 0 ? (
          <div className="text-center py-6 text-[#8B6F47] bg-[#F5F1E8] rounded-xl p-4">
            <p className="text-sm font-medium">No produce lots listed yet.</p>
            <p className="text-xs mt-1">Tap "{t.createLotBtn}" above to add your first harvest lot.</p>
          </div>
        ) : (
          <div className="space-y-4">
            {myLots.map((lot) => {
              // Map status to 1-4 step index
              const steps = [
                { id: "listed", label: t.stepperListed },
                { id: "matched", label: t.stepperMatched },
                { id: "pickedup", label: t.stepperPickedUp },
                { id: "paid", label: t.stepperPaid }
              ];
              const stepIndexMap = { listed: 0, matched: 1, pickedup: 2, paid: 3 };
              const currentStepIndex = stepIndexMap[lot.status] ?? 0;

              // Find associated transaction if any
              const matchedOffer = offers.find(
                (o) => o.lotId === lot.id && o.status === "accepted"
              );
              const matchedTxn = matchedOffer
                ? transactions.find((txn) => txn.offerId === matchedOffer.id)
                : null;

              return (
                <div
                  key={lot.id}
                  className="bg-[#F5F1E8] rounded-xl p-4 border border-[#ded8cb] space-y-4"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-heading font-bold text-lg text-[#2D2D2D]">
                          {lot.crop} ({lot.quantity} Quintals)
                        </span>
                        <span
                          className={`text-xs px-2.5 py-0.5 rounded-xl font-bold uppercase ${
                            lot.grade === "A"
                              ? "bg-[#4A7C59] text-white"
                              : lot.grade === "B"
                              ? "bg-[#8B6F47] text-white"
                              : "bg-[#D97706] text-white"
                          }`}
                        >
                          Grade {lot.grade}
                        </span>
                      </div>
                      <span className="text-xs text-[#8B6F47] font-mono">
                        Lot Ref: {lot.id}
                      </span>
                    </div>

                    {matchedTxn && (
                      <button
                        onClick={() => setGrievanceTxnId(matchedTxn.id)}
                        className="self-start sm:self-auto bg-white border border-[#C0392B] text-[#C0392B] hover:bg-[#fff5f5] text-xs font-semibold px-3 py-1.5 rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
                      >
                        <FileQuestion size={24} />
                        <span>{t.reportProblem}</span>
                      </button>
                    )}
                  </div>

                  {/* Visual 4-Step Stepper */}
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-2 pt-2">
                    {steps.map((st, idx) => {
                      const isComplete = idx <= currentStepIndex;
                      const isCurrent = idx === currentStepIndex;

                      return (
                        <div
                          key={st.id}
                          className={`p-3 rounded-xl border flex items-center gap-2.5 ${
                            isCurrent
                              ? "bg-[#4A7C59] text-white border-[#4A7C59] shadow-sm"
                              : isComplete
                              ? "bg-white text-[#2D2D2D] border-[#4A7C59]"
                              : "bg-[#ede8de] text-[#8B6F47] border-[#ded8cb] opacity-60"
                          }`}
                        >
                          <div
                            className={`w-7 h-7 rounded-xl flex items-center justify-center shrink-0 text-xs font-bold ${
                              isCurrent
                                ? "bg-white text-[#4A7C59]"
                                : isComplete
                                ? "bg-[#4A7C59] text-white"
                                : "bg-[#ded8cb] text-[#8B6F47]"
                            }`}
                          >
                            {isComplete ? <Check size={24} className="w-4 h-4" /> : idx + 1}
                          </div>
                          <div className="flex flex-col">
                            <span className="text-xs font-bold tracking-tight">
                              {st.label}
                            </span>
                            <span className="text-[10px] opacity-80">
                              {idx === 0 && "मंडी सूची"}
                              {idx === 1 && "खरीदार तय"}
                              {idx === 2 && "वाहन रवाना"}
                              {idx === 3 && "खाते में जमा"}
                            </span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* 5.5 Scheduled Mandi Arrival Slots & Tokens */}
      <div className="bg-white rounded-xl shadow-md p-4 border border-[#e2dcd0]">
        <div className="flex items-center justify-between mb-4 pb-2 border-b border-[#F5F1E8]">
          <div className="flex items-center gap-2">
            <div className="text-[#4A7C59] flex items-center">
              <Calendar size={20} />
            </div>
            <h2 className="font-heading font-bold text-lg text-[#2D2D2D] m-0">
              {t.scheduledSlotsTitle || "Scheduled Mandi Arrival Slots & Gate Tokens (मंडी अराइवल स्लॉट व टोकन)"}
            </h2>
          </div>
          <span className="text-xs text-[#8B6F47] font-semibold">
            {(slots || []).length} Active Bookings
          </span>
        </div>

        {(!slots || slots.length === 0) ? (
          <div className="text-center py-6 text-[#8B6F47] bg-[#F5F1E8] rounded-xl p-4">
            <p className="font-medium text-sm">No scheduled arrival slots.</p>
            <p className="text-xs mt-1">Book an arrival slot anytime using the AI Chatbot or IVRS hotline to skip queues at the Mandi gate!</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {slots.map((slot) => (
              <div
                key={slot.id || slot.token}
                className="bg-[#F5F1E8] border border-[#ded8cb] rounded-xl p-3.5 space-y-2 shadow-sm flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between pb-1.5 border-b border-[#ded8cb]">
                    <span className="font-mono font-bold text-xs text-[#4A7C59]">
                      {slot.token}
                    </span>
                    <span className="text-[10px] bg-[#4A7C59] text-white px-2 py-0.5 rounded-full font-bold uppercase">
                      {slot.gateStatus || "CONFIRMED"}
                    </span>
                  </div>
                  <div className="mt-2 space-y-1 text-xs">
                    <div className="flex items-center justify-between">
                      <span className="text-[#8B6F47]">Mandi:</span>
                      <span className="font-bold text-[#2D2D2D]">{slot.mandi}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-[#8B6F47]">Produce:</span>
                      <span className="font-bold text-[#2D2D2D]">{slot.crop} ({slot.quantity} Qtl)</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-[#8B6F47]">Date & Time:</span>
                      <span className="font-bold text-[#2D2D2D]">{slot.date} • {slot.timeSlot}</span>
                    </div>
                  </div>
                </div>
                <div className="pt-2 border-t border-[#ded8cb] flex items-center justify-between text-[11px] text-[#8B6F47]">
                  <span>Vehicle: {slot.vehicleType || "Tractor Trolley"}</span>
                  <span className="text-[#4A7C59] font-bold">Priority Entry Gate</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* 6. My Offers: List of Offers on Their Lots */}
      <div className="bg-white rounded-xl shadow-md p-4 border border-[#e2dcd0]">
        <div className="flex items-center justify-between mb-4 pb-2 border-b border-[#F5F1E8]">
          <div className="flex items-center gap-2">
            <div className="text-[#D97706] flex items-center">
              <Clock size={24} />
            </div>
            <h2 className="font-heading font-bold text-lg text-[#2D2D2D] m-0">
              {t.myOffersTitle}
            </h2>
          </div>
          <span className="text-xs text-[#8B6F47]">
            {myOffers.length} Total Offers
          </span>
        </div>

        {myOffers.length === 0 ? (
          <div className="text-center py-8 text-[#8B6F47] bg-[#F5F1E8] rounded-xl p-4">
            <p className="font-medium text-sm">No incoming buyer bids at the moment.</p>
            <p className="text-xs mt-1">Check the Mandi / Buyer Dashboard to simulate placing bids on your lots.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {myOffers.map((offer) => {
              const lot = lots.find((l) => l.id === offer.lotId);
              const buyer = buyers.find((b) => b.id === offer.buyerId);
              const mandi = mandis.find(
                (m) => lot && m.crop.toLowerCase() === lot.crop.toLowerCase()
              );
              const benchmark = mandi ? mandi.price : 2500;

              return (
                <div
                  key={offer.id}
                  className={`rounded-xl p-4 border flex flex-col justify-between ${
                    offer.status === "accepted"
                      ? "border-[#4A7C59] bg-[#F5F1E8]"
                      : offer.status === "rejected"
                      ? "border-[#ded8cb] bg-[#faf8f5] opacity-60"
                      : "border-[#e2dcd0] bg-white shadow-sm"
                  }`}
                >
                  <div>
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="font-heading font-bold text-base text-[#2D2D2D]">
                            {buyer ? buyer.name : "Agro Trader"}
                          </span>
                          {buyer?.verified && (
                            <span title="Verified" className="text-[#4A7C59] flex items-center">
                              <ShieldCheck size={24} />
                            </span>
                          )}
                        </div>
                        <div className="flex items-center gap-2 text-xs text-[#8B6F47] mt-0.5">
                          <span>{buyer?.type}</span>
                          <span>•</span>
                          <span className="flex items-center gap-0.5 text-[#D97706] font-semibold">
                            <Star size={24} className="fill-[#D97706]" />
                            {buyer?.rating} / 5.0
                          </span>
                        </div>
                      </div>

                      <span
                        className={`text-xs px-2.5 py-1 rounded-xl font-bold uppercase ${
                          offer.status === "accepted"
                            ? "bg-[#4A7C59] text-white"
                            : offer.status === "rejected"
                            ? "bg-[#C0392B] text-white"
                            : "bg-[#D97706] text-white"
                        }`}
                      >
                        {offer.status}
                      </span>
                    </div>

                    {/* Lot Detail Box */}
                    <div className="mt-3 p-3 bg-[#F5F1E8] rounded-xl flex items-center justify-between text-xs">
                      <div>
                        <span className="font-bold text-[#2D2D2D] block">
                          {lot?.crop} (Grade {lot?.grade})
                        </span>
                        <span className="text-[#8B6F47]">
                          Volume: {lot?.quantity} Quintals
                        </span>
                      </div>
                      <div className="text-right">
                        <span className="font-heading font-bold text-lg text-[#2D2D2D] block">
                          ₹{offer.price} <span className="text-xs font-normal">/qtl</span>
                        </span>
                        <span className="text-[11px] text-[#4A7C59] font-medium">
                          Mandi Avg: ₹{benchmark}/qtl
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Accept / Reject Buttons */}
                  <div className="mt-4 pt-3 border-t border-[#ded8cb]">
                    {offer.status === "pending" && (
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => acceptOffer(offer.id)}
                          className="flex-1 bg-[#4A7C59] text-white rounded-xl py-2.5 px-3 text-xs font-bold flex items-center justify-center gap-2 hover:bg-[#3d6749] shadow-sm cursor-pointer transition-colors"
                        >
                          <CheckCircle2 size={24} />
                          <span>{t.acceptOffer}</span>
                        </button>
                        <button
                          onClick={() => rejectOffer(offer.id)}
                          className="bg-white border border-[#C0392B] text-[#C0392B] rounded-xl py-2.5 px-3 text-xs font-bold flex items-center justify-center gap-2 hover:bg-[#fff5f5] cursor-pointer transition-colors"
                        >
                          <XCircle size={24} />
                          <span>{t.rejectOffer}</span>
                        </button>
                      </div>
                    )}

                    {offer.status === "accepted" && (
                      <div className="text-xs text-[#4A7C59] font-semibold flex items-center gap-2">
                        <CheckCircle2 size={24} />
                        <span>{t.dealConfirmed}</span>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* 7. Modal: 3-Step Create Lot Form (Crop → Quantity → Grade) */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl shadow-md p-6 max-w-lg w-full border border-[#ded8cb]">
            {/* Header */}
            <div className="flex items-center justify-between pb-3 border-b border-[#F5F1E8]">
              <div className="flex items-center gap-2">
                <div className="text-[#4A7C59] flex items-center">
                  <PlusCircle size={24} />
                </div>
                <h3 className="font-heading font-bold text-lg text-[#2D2D2D] m-0">
                  {t.createLotModalTitle}
                </h3>
              </div>
              <button
                onClick={() => setShowCreateModal(false)}
                className="text-[#8B6F47] hover:text-[#2D2D2D] cursor-pointer"
              >
                <XCircle size={24} />
              </button>
            </div>

            {/* Stepper Indicator */}
            <div className="grid grid-cols-3 gap-2 my-4">
              <div
                className={`p-2 rounded-xl text-center text-xs font-bold border ${
                  step === 1
                    ? "bg-[#4A7C59] text-white border-[#4A7C59]"
                    : step > 1
                    ? "bg-white text-[#4A7C59] border-[#4A7C59]"
                    : "bg-[#F5F1E8] text-[#8B6F47] border-[#ded8cb]"
                }`}
              >
                1. {t.step1Title.split(":")[1]}
              </div>
              <div
                className={`p-2 rounded-xl text-center text-xs font-bold border ${
                  step === 2
                    ? "bg-[#4A7C59] text-white border-[#4A7C59]"
                    : step > 2
                    ? "bg-white text-[#4A7C59] border-[#4A7C59]"
                    : "bg-[#F5F1E8] text-[#8B6F47] border-[#ded8cb]"
                }`}
              >
                2. {t.step2Title.split(":")[1]}
              </div>
              <div
                className={`p-2 rounded-xl text-center text-xs font-bold border ${
                  step === 3
                    ? "bg-[#4A7C59] text-white border-[#4A7C59]"
                    : "bg-[#F5F1E8] text-[#8B6F47] border-[#ded8cb]"
                }`}
              >
                3. {t.step3Title.split(":")[1]}
              </div>
            </div>

            {/* Step 1: Crop Selection (Icon based) */}
            {step === 1 && (
              <div className="space-y-4">
                <span className="text-sm font-semibold text-[#2D2D2D] block">
                  {t.step1Title}:
                </span>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  {cropList.map((c) => {
                    const IconComp = c.icon;
                    const isPicked = lotCrop === c.name;
                    return (
                      <button
                        key={c.name}
                        type="button"
                        onClick={() => setLotCrop(c.name)}
                        className={`p-3 rounded-xl border flex flex-col items-center gap-1.5 cursor-pointer transition-colors ${
                          isPicked
                            ? "bg-[#4A7C59] text-white border-[#4A7C59] shadow-sm"
                            : "bg-[#F5F1E8] text-[#2D2D2D] border-[#ded8cb] hover:bg-[#e8e2d5]"
                        }`}
                      >
                        <IconComp size={24} />
                        <span className="font-bold text-xs">{c.name}</span>
                        <span className="text-[10px] opacity-80">{c.hindiName}</span>
                      </button>
                    );
                  })}
                </div>

                <div className="pt-4 border-t border-[#F5F1E8] flex justify-end">
                  <button
                    type="button"
                    onClick={() => setStep(2)}
                    className="bg-[#4A7C59] text-white rounded-xl py-2.5 px-5 text-sm font-bold flex items-center gap-2 hover:bg-[#3d6749] shadow-md cursor-pointer"
                  >
                    <span>{t.nextStep}</span>
                    <ChevronRight size={24} />
                  </button>
                </div>
              </div>
            )}

            {/* Step 2: Quantity Input (Chips + numeric input) */}
            {step === 2 && (
              <div className="space-y-4">
                <span className="text-sm font-semibold text-[#2D2D2D] block">
                  {t.step2Title}:
                </span>

                {/* Preset Chips */}
                <div className="grid grid-cols-4 gap-2">
                  {[25, 50, 100, 200].map((qty) => (
                    <button
                      key={qty}
                      type="button"
                      onClick={() => setLotQuantity(qty)}
                      className={`py-3 rounded-xl font-heading font-bold text-sm border cursor-pointer ${
                        lotQuantity === qty
                          ? "bg-[#4A7C59] text-white border-[#4A7C59]"
                          : "bg-[#F5F1E8] text-[#2D2D2D] border-[#ded8cb]"
                      }`}
                    >
                      {qty} Qtl
                    </button>
                  ))}
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#8B6F47] mb-1">
                    Or Enter Exact Quantity (Quintals)
                  </label>
                  <input
                    type="number"
                    min="1"
                    value={lotQuantity}
                    onChange={(e) => setLotQuantity(e.target.value)}
                    className="w-full bg-[#F5F1E8] border border-[#ded8cb] rounded-xl px-4 py-3 text-lg font-bold text-[#2D2D2D] focus:outline-none focus:ring-1 focus:ring-[#4A7C59]"
                  />
                </div>

                <div className="pt-4 border-t border-[#F5F1E8] flex justify-between">
                  <button
                    type="button"
                    onClick={() => setStep(1)}
                    className="bg-white border border-[#ded8cb] text-[#2D2D2D] rounded-xl py-2.5 px-4 text-sm font-semibold flex items-center gap-2 cursor-pointer hover:bg-[#F5F1E8]"
                  >
                    <ChevronLeft size={24} />
                    <span>{t.prevStep}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setStep(3)}
                    className="bg-[#4A7C59] text-white rounded-xl py-2.5 px-5 text-sm font-bold flex items-center gap-2 hover:bg-[#3d6749] shadow-md cursor-pointer"
                  >
                    <span>{t.nextStep}</span>
                    <ChevronRight size={24} />
                  </button>
                </div>
              </div>
            )}

            {/* Step 3: Grade Selection (Large icon-based cards) */}
            {step === 3 && (
              <div className="space-y-4">
                <span className="text-sm font-semibold text-[#2D2D2D] block">
                  {t.step3Title}:
                </span>

                <div className="space-y-3">
                  {[
                    { grade: "A", title: t.gradeA, desc: "Highest APMC premium pricing benchmark" },
                    { grade: "B", title: t.gradeB, desc: "Standard fair average market quality" },
                    { grade: "C", title: t.gradeC, desc: "Commercial processing & feed quality" }
                  ].map((g) => (
                    <button
                      key={g.grade}
                      type="button"
                      onClick={() => setLotGrade(g.grade)}
                      className={`w-full p-4 rounded-xl border text-left flex items-start justify-between cursor-pointer transition-colors ${
                        lotGrade === g.grade
                          ? "bg-[#4A7C59] text-white border-[#4A7C59] shadow-sm"
                          : "bg-[#F5F1E8] text-[#2D2D2D] border-[#ded8cb] hover:bg-[#e8e2d5]"
                      }`}
                    >
                      <div>
                        <span className="font-heading font-bold text-base block">
                          Grade {g.grade}
                        </span>
                        <span className="text-xs block mt-0.5 font-medium opacity-90">
                          {g.title}
                        </span>
                        <span className="text-[11px] block mt-1 opacity-75">
                          {g.desc}
                        </span>
                      </div>
                      {lotGrade === g.grade && (
                        <div className="w-6 h-6 rounded-full bg-white text-[#4A7C59] flex items-center justify-center shrink-0">
                          <Check size={24} className="w-4 h-4" />
                        </div>
                      )}
                    </button>
                  ))}
                </div>

                <div className="pt-4 border-t border-[#F5F1E8] flex justify-between">
                  <button
                    type="button"
                    onClick={() => setStep(2)}
                    className="bg-white border border-[#ded8cb] text-[#2D2D2D] rounded-xl py-2.5 px-4 text-sm font-semibold flex items-center gap-2 cursor-pointer hover:bg-[#F5F1E8]"
                  >
                    <ChevronLeft size={24} />
                    <span>{t.prevStep}</span>
                  </button>
                  <button
                    type="button"
                    onClick={handleCreateLotSubmit}
                    className="bg-[#4A7C59] text-white rounded-xl py-2.5 px-5 text-sm font-bold flex items-center gap-2 hover:bg-[#3d6749] shadow-md cursor-pointer"
                  >
                    <CheckCircle2 size={24} />
                    <span>{t.publishLot}</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* 8. Modal: Report a Problem (Grievance Form) */}
      {grievanceTxnId && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl shadow-md p-6 max-w-md w-full border border-[#ded8cb]">
            <div className="flex items-center justify-between pb-3 border-b border-[#F5F1E8]">
              <div className="flex items-center gap-2">
                <div className="text-[#C0392B] flex items-center">
                  <FileQuestion size={24} />
                </div>
                <h3 className="font-heading font-bold text-lg text-[#2D2D2D] m-0">
                  {t.grievanceTitle}
                </h3>
              </div>
              <button
                onClick={() => setGrievanceTxnId(null)}
                className="text-[#8B6F47] hover:text-[#2D2D2D] cursor-pointer"
              >
                <XCircle size={24} />
              </button>
            </div>

            <form onSubmit={handleGrievanceSubmit} className="space-y-4 mt-4 text-sm">
              <div>
                <label className="block text-xs font-semibold text-[#8B6F47] mb-1">
                  Transaction Ref
                </label>
                <input
                  type="text"
                  disabled
                  value={grievanceTxnId}
                  className="w-full bg-[#F5F1E8] border border-[#ded8cb] rounded-xl px-3 py-2 text-[#2D2D2D] font-mono text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#2D2D2D] mb-1">
                  {t.grievanceDesc}
                </label>
                <textarea
                  rows={4}
                  required
                  placeholder="e.g. Weighing scale slip has discrepancy of 1.5 quintals..."
                  value={grievanceText}
                  onChange={(e) => setGrievanceText(e.target.value)}
                  className="w-full bg-[#F5F1E8] border border-[#ded8cb] rounded-xl p-3 text-[#2D2D2D] text-xs focus:outline-none focus:ring-1 focus:ring-[#4A7C59]"
                />
              </div>

              <div className="flex items-center gap-3 pt-3 border-t border-[#F5F1E8]">
                <button
                  type="button"
                  onClick={() => setGrievanceTxnId(null)}
                  className="flex-1 bg-white border border-[#ded8cb] text-[#2D2D2D] rounded-xl py-2.5 text-xs font-semibold hover:bg-[#F5F1E8] cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-[#4A7C59] text-white rounded-xl py-2.5 text-xs font-bold hover:bg-[#3d6749] shadow-md cursor-pointer"
                >
                  {t.submitGrievance}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
