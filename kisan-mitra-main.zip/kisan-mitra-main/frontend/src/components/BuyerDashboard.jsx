import React, { useState } from "react";
import {
  ShoppingBag,
  TrendingUp,
  TrendingDown,
  ShieldCheck,
  Star,
  Send,
  Layers,
  Filter,
  CheckCircle2,
  Package,
  Truck,
  MapPin,
  Clock,
  XCircle,
  FileCheck,
  PlusCircle,
  Search,
  Users
} from "lucide-react";
import { useApp } from "../context/AppContext";

export default function BuyerDashboard() {
  const {
    activeBuyerId,
    getBuyer,
    lots,
    farmers,
    mandis,
    offers,
    transactions,
    makeOffer,
    updateBuyerDemand,
    updateTransaction,
    t
  } = useApp();

  const buyer = getBuyer(activeBuyerId) || {
    name: "AgroHarvest Agri-Ventures",
    type: "Institutional Buyer",
    verified: true,
    rating: 4.8,
    demand: { crop: "Wheat", quantity: 500 }
  };

  // Form state for Posting Procurement Demand
  const [demandCrop, setDemandCrop] = useState(buyer.demand?.crop || "Wheat");
  const [demandQuantity, setDemandQuantity] = useState(buyer.demand?.quantity || 250);
  const [demandGrade, setDemandGrade] = useState("A");
  const [demandPrice, setDemandPrice] = useState(2500);
  const [demandSuccessMsg, setDemandSuccessMsg] = useState("");

  // Filter state for Browsing Lots
  const [filterCrop, setFilterCrop] = useState("all");
  const [filterGrade, setFilterGrade] = useState("all");
  const [filterLocation, setFilterLocation] = useState("all");

  // Send Digital Offer Modal state
  const [targetLot, setTargetLot] = useState(null);
  const [offerPriceInput, setOfferPriceInput] = useState("");

  // Handle Post Demand
  const handlePostDemand = (e) => {
    e.preventDefault();
    if (!demandQuantity || Number(demandQuantity) <= 0) return;
    updateBuyerDemand(activeBuyerId, {
      crop: demandCrop,
      quantity: Number(demandQuantity)
    });
    setDemandSuccessMsg(`Procurement demand for ${demandQuantity} Qtl ${demandCrop} updated successfully.`);
    setTimeout(() => setDemandSuccessMsg(""), 3500);
  };

  // Handle Digital Offer Submit
  const handleSendOfferSubmit = (e) => {
    e.preventDefault();
    if (!targetLot || !offerPriceInput || Number(offerPriceInput) <= 0) return;

    makeOffer({
      lotId: targetLot.id,
      buyerId: activeBuyerId,
      price: Number(offerPriceInput)
    });

    setTargetLot(null);
    setOfferPriceInput("");
  };

  // Filter available lots matching criteria
  const availableLots = lots.filter((lot) => {
    if (filterCrop !== "all" && lot.crop.toLowerCase() !== filterCrop.toLowerCase()) {
      return false;
    }
    if (filterGrade !== "all" && lot.grade !== filterGrade) {
      return false;
    }
    if (filterLocation !== "all") {
      const f = farmers.find((farm) => farm.id === lot.farmerId);
      if (!f || !f.village.toLowerCase().includes(filterLocation.toLowerCase())) {
        return false;
      }
    }
    return true;
  });

  // Aggregated View: Group nearby lots of same crop + grade into one consolidated batch
  const listedLots = lots.filter((l) => l.status === "listed");
  const lotBatchesMap = {};

  listedLots.forEach((lot) => {
    const key = `${lot.crop}_${lot.grade}`;
    if (!lotBatchesMap[key]) {
      lotBatchesMap[key] = {
        crop: lot.crop,
        grade: lot.grade,
        lots: [],
        totalQuantity: 0,
        farmersList: []
      };
    }
    lotBatchesMap[key].lots.push(lot);
    lotBatchesMap[key].totalQuantity += lot.quantity;
    const f = farmers.find((farm) => farm.id === lot.farmerId);
    if (f && !lotBatchesMap[key].farmersList.includes(f.name)) {
      lotBatchesMap[key].farmersList.push(`${f.name} (${f.village.split(",")[0]})`);
    }
  });

  const aggregatedBatches = Object.values(lotBatchesMap).filter((b) => b.lots.length >= 1);

  // My offers & active orders
  const myOffers = offers.filter((o) => o.buyerId === activeBuyerId);
  const myOfferIds = myOffers.map((o) => o.id);
  const myTxns = transactions.filter((t) => myOfferIds.includes(t.offerId));

  return (
    <div className="space-y-6">
      {/* 1. Verified Buyer Profile Card */}
      <div className="bg-white rounded-xl shadow-md p-4 border border-[#e2dcd0] flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="font-heading font-bold text-2xl text-[#2D2D2D] m-0">
              {buyer.name}
            </h1>
            {buyer.verified && (
              <span className="bg-[#4A7C59] text-white text-xs font-semibold px-2.5 py-1 rounded-xl flex items-center gap-1.5">
                <ShieldCheck size={24} />
                <span>{t.verifiedBuyer}</span>
              </span>
            )}
          </div>
          <div className="flex items-center gap-3 text-sm text-[#8B6F47] mt-1">
            <span>{t.category}: <strong className="text-[#2D2D2D]">{buyer.type}</strong></span>
            <span>•</span>
            <span className="flex items-center gap-1 text-[#D97706] font-bold">
              <Star size={24} className="fill-[#D97706]" />
              {buyer.rating} / 5.0
            </span>
          </div>
        </div>

        {/* Current Active Demand Pill */}
        <div className="bg-[#F5F1E8] border border-[#ded8cb] rounded-xl p-3 flex items-center gap-3">
          <div className="text-[#8B6F47] flex items-center">
            <ShoppingBag size={24} />
          </div>
          <div>
            <span className="text-xs text-[#8B6F47] block font-medium">
              {t.activeDemand}:
            </span>
            <span className="font-heading font-bold text-base text-[#2D2D2D]">
              {buyer.demand?.quantity} Quintals of {buyer.demand?.crop}
            </span>
          </div>
        </div>
      </div>

      {/* 2. Live Price Ticker Table for Tracked Crops (from Mandi priceHistory) */}
      <div className="bg-white rounded-xl shadow-md p-4 border border-[#e2dcd0]">
        <div className="flex items-center justify-between mb-3 pb-2 border-b border-[#F5F1E8]">
          <div className="flex items-center gap-2">
            <div className="text-[#4A7C59] flex items-center">
              <TrendingUp size={24} />
            </div>
            <h2 className="font-heading font-bold text-lg text-[#2D2D2D] m-0">
              {t.liveTickerTitle}
            </h2>
          </div>
          <span className="text-xs text-[#8B6F47]">
            Calculated from 7-Day APMC History
          </span>
        </div>

        {/* Dense Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-[#F5F1E8] text-[#2D2D2D] font-heading font-bold border-b border-[#ded8cb]">
                <th className="p-3 rounded-l-xl">Commodity</th>
                <th className="p-3">Reference APMC</th>
                <th className="p-3">Today's Price</th>
                <th className="p-3">24h Change</th>
                <th className="p-3">7-Day Range</th>
                <th className="p-3 rounded-r-xl">Trend Indicator</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#F5F1E8]">
              {mandis.map((m) => {
                const hist = m.priceHistory;
                const yesterday = hist[hist.length - 2];
                const changePct = Number((((m.price - yesterday) / yesterday) * 100).toFixed(1));
                const isUp = changePct >= 0;
                const min = Math.min(...hist);
                const max = Math.max(...hist);

                return (
                  <tr key={m.id} className="hover:bg-[#F5F1E8]/50 transition-colors">
                    <td className="p-3 font-heading font-bold text-sm text-[#2D2D2D]">
                      {m.crop}
                    </td>
                    <td className="p-3 text-[#8B6F47] font-medium">
                      {m.name} ({m.location.split(",")[0]})
                    </td>
                    <td className="p-3 font-heading font-bold text-sm text-[#4A7C59]">
                      ₹{m.price} <span className="text-xs font-normal text-[#8B6F47]">/qtl</span>
                    </td>
                    <td className="p-3 font-bold">
                      <span
                        className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-xl ${
                          isUp
                            ? "bg-[#4A7C59]/10 text-[#4A7C59]"
                            : "bg-[#C0392B]/10 text-[#C0392B]"
                        }`}
                      >
                        {isUp ? "+" : ""}{changePct}%
                      </span>
                    </td>
                    <td className="p-3 text-[#8B6F47]">
                      ₹{min} — ₹{max}
                    </td>
                    <td className="p-3">
                      <span className="inline-flex items-center gap-1 text-[#2D2D2D] font-medium">
                        {isUp ? (
                          <TrendingUp size={24} className="text-[#4A7C59]" />
                        ) : (
                          <TrendingDown size={24} className="text-[#C0392B]" />
                        )}
                        <span>{isUp ? "Bullish" : "Bearish"}</span>
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* 3. Post Procurement Demand Form */}
      <div className="bg-white rounded-xl shadow-md p-4 border border-[#e2dcd0]">
        <div className="flex items-center justify-between mb-3 pb-2 border-b border-[#F5F1E8]">
          <div className="flex items-center gap-2">
            <div className="text-[#4A7C59] flex items-center">
              <PlusCircle size={24} />
            </div>
            <h2 className="font-heading font-bold text-lg text-[#2D2D2D] m-0">
              {t.postDemandTitle}
            </h2>
          </div>
          {demandSuccessMsg && (
            <span className="text-xs text-[#4A7C59] font-bold bg-[#F5F1E8] px-3 py-1 rounded-xl border border-[#4A7C59]">
              {demandSuccessMsg}
            </span>
          )}
        </div>

        <form onSubmit={handlePostDemand} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 items-end">
          <div>
            <label className="block text-xs font-semibold text-[#2D2D2D] mb-1">
              {t.demandCrop}
            </label>
            <select
              value={demandCrop}
              onChange={(e) => setDemandCrop(e.target.value)}
              className="w-full bg-[#F5F1E8] border border-[#ded8cb] rounded-xl px-3 py-2 text-xs font-medium text-[#2D2D2D] focus:outline-none"
            >
              <option value="Wheat">Wheat</option>
              <option value="Soybean">Soybean</option>
              <option value="Mustard">Mustard</option>
              <option value="Chana">Chana</option>
              <option value="Onion">Onion</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#2D2D2D] mb-1">
              {t.demandQuantity}
            </label>
            <input
              type="number"
              min="10"
              required
              value={demandQuantity}
              onChange={(e) => setDemandQuantity(e.target.value)}
              className="w-full bg-[#F5F1E8] border border-[#ded8cb] rounded-xl px-3 py-2 text-xs font-medium text-[#2D2D2D] focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#2D2D2D] mb-1">
              {t.demandGrade}
            </label>
            <select
              value={demandGrade}
              onChange={(e) => setDemandGrade(e.target.value)}
              className="w-full bg-[#F5F1E8] border border-[#ded8cb] rounded-xl px-3 py-2 text-xs font-medium text-[#2D2D2D] focus:outline-none"
            >
              <option value="A">Grade A (Premium)</option>
              <option value="B">Grade B (Standard)</option>
              <option value="C">Grade C (Commercial)</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#2D2D2D] mb-1">
              {t.demandPrice}
            </label>
            <input
              type="number"
              min="500"
              required
              value={demandPrice}
              onChange={(e) => setDemandPrice(e.target.value)}
              className="w-full bg-[#F5F1E8] border border-[#ded8cb] rounded-xl px-3 py-2 text-xs font-bold text-[#4A7C59] focus:outline-none"
            />
          </div>

          <div>
            <button
              type="submit"
              className="w-full bg-[#4A7C59] text-white rounded-xl py-2 px-4 text-xs font-bold flex items-center justify-center gap-1.5 hover:bg-[#3d6749] shadow-sm cursor-pointer"
            >
              <Send size={24} />
              <span>{t.submitDemand}</span>
            </button>
          </div>
        </form>
      </div>

      {/* 4. Aggregated View: Group Nearby Lots of Same Crop+Grade into One Batch */}
      <div className="bg-white rounded-xl shadow-md p-4 border border-[#e2dcd0]">
        <div className="flex items-center justify-between mb-3 pb-2 border-b border-[#F5F1E8]">
          <div className="flex items-center gap-2">
            <div className="text-[#8B6F47] flex items-center">
              <Layers size={24} />
            </div>
            <div>
              <h2 className="font-heading font-bold text-lg text-[#2D2D2D] m-0">
                {t.aggregatedBatchesTitle}
              </h2>
              <span className="text-xs text-[#8B6F47]">
                Consolidated produce from neighboring farmers in same cluster
              </span>
            </div>
          </div>
          <span className="text-xs font-semibold text-[#4A7C59] bg-[#F5F1E8] px-3 py-1 rounded-xl">
            {aggregatedBatches.length} Available Batches
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {aggregatedBatches.map((batch, index) => (
            <div
              key={index}
              className="bg-[#F5F1E8] rounded-xl p-4 border border-[#ded8cb] flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between">
                  <span className="font-heading font-bold text-base text-[#2D2D2D]">
                    {batch.crop} Cluster Batch #{index + 1}
                  </span>
                  <span className="bg-[#4A7C59] text-white text-xs font-bold px-2 py-0.5 rounded-xl uppercase">
                    Grade {batch.grade}
                  </span>
                </div>

                <div className="mt-3 space-y-2 text-xs">
                  <div className="flex justify-between">
                    <span className="text-[#8B6F47]">Aggregated Quantity:</span>
                    <strong className="text-sm text-[#2D2D2D]">{batch.totalQuantity} Quintals</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#8B6F47]">Participating Lots:</span>
                    <span>{batch.lots.length} Farmer Lots</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#8B6F47]">Producers:</span>
                    <span className="text-right text-[#2D2D2D] font-medium truncate max-w-[170px]">
                      {batch.farmersList.join(", ")}
                    </span>
                  </div>

                  {/* Freight Savings Pill */}
                  <div className="p-2 bg-white rounded-xl border border-[#ded8cb] flex items-center justify-between text-[11px] text-[#4A7C59] font-bold">
                    <span>Estimated Freight Savings:</span>
                    <span>~18% Combined Dispatch</span>
                  </div>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-[#ded8cb]">
                <button
                  onClick={() => {
                    // Send offer to first lot as representative of batch
                    if (batch.lots[0]) {
                      setTargetLot(batch.lots[0]);
                      const mandi = mandis.find((m) => m.crop.toLowerCase() === batch.crop.toLowerCase());
                      setOfferPriceInput(mandi ? mandi.price.toString() : "2500");
                    }
                  }}
                  className="w-full bg-[#8B6F47] text-white rounded-xl py-2 px-3 text-xs font-bold flex items-center justify-center gap-1.5 hover:bg-[#755d3b] cursor-pointer"
                >
                  <Send size={24} />
                  <span>Bid on Aggregated Batch</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 5. Browse Lots Matching Demand (Data-dense table UI) */}
      <div className="bg-white rounded-xl shadow-md p-4 border border-[#e2dcd0]">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4 pb-3 border-b border-[#F5F1E8]">
          <div className="flex items-center gap-2">
            <div className="text-[#4A7C59] flex items-center">
              <Search size={24} />
            </div>
            <div>
              <h2 className="font-heading font-bold text-lg text-[#2D2D2D] m-0">
                {t.browseLotsTitle} ({availableLots.length})
              </h2>
              <span className="text-xs text-[#8B6F47]">
                Filter by commodity, quality grade, and origin village
              </span>
            </div>
          </div>

          {/* Filter Bar */}
          <div className="flex flex-wrap items-center gap-2 text-xs">
            <div className="flex items-center gap-1">
              <span className="text-[#8B6F47]">Crop:</span>
              <select
                value={filterCrop}
                onChange={(e) => setFilterCrop(e.target.value)}
                className="bg-[#F5F1E8] border border-[#ded8cb] rounded-xl px-2.5 py-1 text-xs text-[#2D2D2D] focus:outline-none"
              >
                <option value="all">All Crops</option>
                <option value="Wheat">Wheat</option>
                <option value="Soybean">Soybean</option>
                <option value="Mustard">Mustard</option>
                <option value="Chana">Chana</option>
                <option value="Onion">Onion</option>
              </select>
            </div>

            <div className="flex items-center gap-1">
              <span className="text-[#8B6F47]">Grade:</span>
              <select
                value={filterGrade}
                onChange={(e) => setFilterGrade(e.target.value)}
                className="bg-[#F5F1E8] border border-[#ded8cb] rounded-xl px-2.5 py-1 text-xs text-[#2D2D2D] focus:outline-none"
              >
                <option value="all">All Grades</option>
                <option value="A">Grade A</option>
                <option value="B">Grade B</option>
                <option value="C">Grade C</option>
              </select>
            </div>

            <div className="flex items-center gap-1">
              <span className="text-[#8B6F47]">Village:</span>
              <select
                value={filterLocation}
                onChange={(e) => setFilterLocation(e.target.value)}
                className="bg-[#F5F1E8] border border-[#ded8cb] rounded-xl px-2.5 py-1 text-xs text-[#2D2D2D] focus:outline-none"
              >
                <option value="all">All Regions</option>
                <option value="Pipliya">Pipliya</option>
                <option value="Kotra">Kotra</option>
                <option value="Barwaha">Barwaha</option>
                <option value="Shamgarh">Shamgarh</option>
              </select>
            </div>
          </div>
        </div>

        {/* Data-dense Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-[#F5F1E8] text-[#2D2D2D] font-heading font-bold border-b border-[#ded8cb]">
                <th className="p-3 rounded-l-xl">Lot Ref</th>
                <th className="p-3">Farmer & Location</th>
                <th className="p-3">Commodity</th>
                <th className="p-3">Quantity</th>
                <th className="p-3">Grade</th>
                <th className="p-3">Mandi Avg</th>
                <th className="p-3">Status</th>
                <th className="p-3 text-right rounded-r-xl">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#F5F1E8]">
              {availableLots.map((lot) => {
                const farmer = farmers.find((f) => f.id === lot.farmerId);
                const mandi = mandis.find(
                  (m) => m.crop.toLowerCase() === lot.crop.toLowerCase()
                );
                const benchmark = mandi ? mandi.price : 2500;
                const existingOffer = myOffers.find((o) => o.lotId === lot.id);

                return (
                  <tr key={lot.id} className="hover:bg-[#F5F1E8]/50 transition-colors">
                    <td className="p-3 font-mono font-bold text-[#2D2D2D]">
                      {lot.id}
                    </td>
                    <td className="p-3">
                      <div className="font-semibold text-[#2D2D2D]">
                        {farmer ? farmer.name : "Farmer"}
                      </div>
                      <div className="text-[11px] text-[#8B6F47]">
                        {farmer ? farmer.village : "Mandi Region"}
                      </div>
                    </td>
                    <td className="p-3 font-heading font-bold text-[#2D2D2D]">
                      {lot.crop}
                    </td>
                    <td className="p-3 font-bold text-[#2D2D2D]">
                      {lot.quantity} Quintals
                    </td>
                    <td className="p-3">
                      <span
                        className={`px-2 py-0.5 rounded-xl font-bold uppercase text-[11px] ${
                          lot.grade === "A"
                            ? "bg-[#4A7C59] text-white"
                            : lot.grade === "B"
                            ? "bg-[#8B6F47] text-white"
                            : "bg-[#D97706] text-white"
                        }`}
                      >
                        Grade {lot.grade}
                      </span>
                    </td>
                    <td className="p-3 font-semibold text-[#4A7C59]">
                      ₹{benchmark}/qtl
                    </td>
                    <td className="p-3 capitalize font-medium text-[#8B6F47]">
                      {lot.status}
                    </td>
                    <td className="p-3 text-right">
                      {lot.status === "listed" ? (
                        existingOffer ? (
                          <span
                            className={`text-xs px-2.5 py-1 rounded-xl font-semibold capitalize ${
                              existingOffer.status === "accepted"
                                ? "bg-[#4A7C59] text-white"
                                : existingOffer.status === "rejected"
                                ? "bg-[#C0392B] text-white"
                                : "bg-[#D97706] text-white"
                            }`}
                          >
                            Offer: ₹{existingOffer.price} ({existingOffer.status})
                          </span>
                        ) : (
                          <button
                            onClick={() => {
                              setTargetLot(lot);
                              setOfferPriceInput(benchmark.toString());
                            }}
                            className="bg-[#4A7C59] text-white rounded-xl py-1.5 px-3 text-xs font-bold flex items-center gap-1.5 ml-auto hover:bg-[#3d6749] shadow-sm cursor-pointer"
                          >
                            <Send size={24} />
                            <span>{t.sendOfferBtn}</span>
                          </button>
                        )
                      ) : (
                        <span className="text-[#8B6F47] text-xs font-medium">Closed</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* 6. Send Digital Offer Modal */}
      {targetLot && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl shadow-md p-6 max-w-md w-full border border-[#ded8cb]">
            <div className="flex items-center justify-between pb-3 border-b border-[#F5F1E8]">
              <div className="flex items-center gap-2">
                <div className="text-[#4A7C59] flex items-center">
                  <Send size={24} />
                </div>
                <h3 className="font-heading font-bold text-lg text-[#2D2D2D] m-0">
                  {t.sendOfferBtn}
                </h3>
              </div>
              <button
                onClick={() => setTargetLot(null)}
                className="text-[#8B6F47] hover:text-[#2D2D2D] cursor-pointer"
              >
                <XCircle size={24} />
              </button>
            </div>

            <form onSubmit={handleSendOfferSubmit} className="space-y-4 mt-4 text-sm">
              <div className="bg-[#F5F1E8] p-3 rounded-xl border border-[#ded8cb] text-xs space-y-1">
                <div className="flex justify-between">
                  <span className="text-[#8B6F47]">Lot:</span>
                  <strong className="text-[#2D2D2D]">
                    {targetLot.crop} (Grade {targetLot.grade})
                  </strong>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#8B6F47]">Quantity:</span>
                  <strong className="text-[#2D2D2D]">{targetLot.quantity} Quintals</strong>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#8B6F47]">Mandi Benchmark:</span>
                  <strong className="text-[#4A7C59]">
                    ₹
                    {
                      mandis.find(
                        (m) => m.crop.toLowerCase() === targetLot.crop.toLowerCase()
                      )?.price || 2500
                    }
                    /qtl
                  </strong>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#2D2D2D] mb-1">
                  Offer Price per Quintal (₹)
                </label>
                <input
                  type="number"
                  required
                  min="100"
                  step="10"
                  value={offerPriceInput}
                  onChange={(e) => setOfferPriceInput(e.target.value)}
                  className="w-full bg-[#F5F1E8] border border-[#ded8cb] rounded-xl px-4 py-3 text-xl font-bold text-[#2D2D2D] focus:outline-none focus:ring-1 focus:ring-[#4A7C59]"
                />
              </div>

              <div className="p-3 bg-[#fcfaf7] border border-[#ded8cb] rounded-xl text-xs flex justify-between">
                <span className="text-[#8B6F47]">Total Offer Value:</span>
                <strong className="font-heading text-sm text-[#2D2D2D]">
                  ₹{((Number(offerPriceInput) || 0) * targetLot.quantity).toLocaleString()}
                </strong>
              </div>

              <div className="flex items-center gap-3 pt-3 border-t border-[#F5F1E8]">
                <button
                  type="button"
                  onClick={() => setTargetLot(null)}
                  className="flex-1 bg-white border border-[#ded8cb] text-[#2D2D2D] rounded-xl py-2.5 text-xs font-semibold hover:bg-[#F5F1E8] cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-[#4A7C59] text-white rounded-xl py-2.5 text-xs font-bold hover:bg-[#3d6749] shadow-md cursor-pointer"
                >
                  Send Digital Offer
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
