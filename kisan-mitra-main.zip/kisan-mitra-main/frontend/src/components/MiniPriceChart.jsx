import React from "react";

/**
 * 7-day Price History visualizer using clean SVG bars.
 * Strictly adheres to design system: no gradients, solid colors, clean labels.
 */
export default function MiniPriceChart({ history = [], crop = "", currentPrice = 0 }) {
  if (!history || history.length === 0) return null;

  const min = Math.min(...history);
  const max = Math.max(...history);
  const range = max - min || 1;

  // Chart dimensions
  const height = 50;
  const barWidth = 14;
  const barGap = 8;
  const totalWidth = history.length * (barWidth + barGap);

  return (
    <div className="flex flex-col gap-1.5">
      <div className="flex items-center justify-between text-xs text-[#8B6F47] font-medium">
        <span>7-Day Trend</span>
        <span>Low: ₹{min} | High: ₹{max}</span>
      </div>
      <div className="flex items-end gap-2 h-[52px] bg-[#F5F1E8] px-3 py-2 rounded-xl border border-[#e2dcd0]">
        {history.map((val, idx) => {
          const normalized = (val - min) / range;
          const barHeight = Math.max(8, Math.round(normalized * 32));
          const isLatest = idx === history.length - 1;

          return (
            <div key={idx} className="flex-1 flex flex-col items-center justify-end h-full group relative">
              {/* Tooltip */}
              <div className="hidden group-hover:block absolute -top-7 bg-[#2D2D2D] text-white text-[11px] font-sans px-1.5 py-0.5 rounded shadow z-10 whitespace-nowrap">
                Day {idx + 1}: ₹{val}
              </div>
              <div
                style={{ height: `${barHeight}px` }}
                className={`w-full max-w-[16px] rounded-t ${
                  isLatest ? "bg-[#4A7C59]" : "bg-[#8B6F47]"
                }`}
              />
            </div>
          );
        })}
      </div>
      <div className="flex justify-between text-[11px] text-[#2D2D2D] font-medium px-1">
        <span>7d ago</span>
        <span>Today: ₹{currentPrice}</span>
      </div>
    </div>
  );
}
