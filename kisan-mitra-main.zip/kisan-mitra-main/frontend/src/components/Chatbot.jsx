import React, { useState, useRef, useEffect } from "react";
import {
  MessageSquare,
  X,
  Send,
  Calendar,
  Sparkles,
  Bot,
  User,
  Key,
  CheckCircle2,
  RefreshCw,
  Clock,
  MapPin,
  ChevronDown,
  Volume2,
  Mic,
  MicOff,
  Copy,
  Check
} from "lucide-react";
import { useApp } from "../context/AppContext";

export default function Chatbot() {
  const { lang, bookSlot, mandis } = useApp();
  const [isOpen, setIsOpen] = useState(false);
  const [inputMessage, setInputMessage] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [apiKey, setApiKey] = useState(
    () => localStorage.getItem("kisan_mitra_api_key") || "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"
  );
  const [showKeyModal, setShowKeyModal] = useState(false);
  const [tempKey, setTempKey] = useState(apiKey);
  const [isListening, setIsListening] = useState(false);
  const [copiedToken, setCopiedToken] = useState(null);

  const [messages, setMessages] = useState([
    {
      id: "welcome",
      role: "assistant",
      text: lang === "en"
        ? "🌾 **Namaste! I am Kisan Mitra AI.**\n\nI can help you check live mandi rates, find top verified buyers, and **schedule Mandi Entry Slots & Tokens**!\n\nTry asking: *\"Book slot for 50 qtl soybean in Neemuch Mandi\"* or *\"Today's wheat prices\"*."
        : "🌾 **नमस्ते किसान भाई! मैं आपका किसान मित्र AI सहायक हूँ।**\n\nमैं आपको ताज़ा मंडी भाव बताने, सर्वश्रेष्ठ खरीदार खोजने और **मंडी गेट एंट्री स्लॉट व टोकन बुक करने** में मदद कर सकता हूँ!\n\nआप पूछ सकते हैं: *\"नीमच मंडी में 50 क्विंटल सोयाबीन का स्लॉट बुक करें\"* या *\"आज के गेहूं के भाव\"*।",
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
    }
  ]);

  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    if (isOpen) {
      scrollToBottom();
    }
  }, [messages, isOpen]);

  // Voice recognition support (Speech-to-Text)
  const toggleListening = () => {
    if (!("webkitSpeechRecognition" in window || "SpeechRecognition" in window)) {
      alert("Speech recognition is not supported in this browser. Please use Chrome/Edge.");
      return;
    }
    if (isListening) {
      setIsListening(false);
      return;
    }

    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    const recognition = new SpeechRecognition();
    recognition.lang = lang === "en" ? "en-IN" : "hi-IN";
    recognition.continuous = false;
    recognition.interimResults = false;

    recognition.onstart = () => setIsListening(true);
    recognition.onend = () => setIsListening(false);
    recognition.onerror = () => setIsListening(false);

    recognition.onresult = (event) => {
      const transcript = event.results[0][0].transcript;
      setInputMessage(transcript);
      setIsListening(false);
    };

    recognition.start();
  };

  // Text-to-speech helper
  const speakMessage = (text) => {
    if (!("speechSynthesis" in window)) return;
    window.speechSynthesis.cancel();
    const cleanText = text.replace(/[*_#`]/g, "");
    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.lang = lang === "en" ? "en-IN" : "hi-IN";
    utterance.rate = 0.95;
    window.speechSynthesis.speak(utterance);
  };

  const handleSaveKey = () => {
    setApiKey(tempKey);
    localStorage.setItem("kisan_mitra_api_key", tempKey);
    setShowKeyModal(false);
  };

  const handleSend = async (userText = inputMessage) => {
    const textToSend = userText.trim();
    if (!textToSend || isLoading) return;

    const userMsg = {
      id: `user-${Date.now()}`,
      role: "user",
      text: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputMessage("");
    setIsLoading(true);

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: textToSend,
          apiKey,
          language: lang,
          history: messages.slice(-4).map((m) => ({
            role: m.role,
            content: m.text
          }))
        })
      });

      if (!response.ok) {
        throw new Error("Chat request failed");
      }

      const data = await response.json();
      let slotData = data.slotBooked;

      // If backend created a slot, also add to AppContext
      if (slotData) {
        bookSlot(slotData);
      } else {
        // Client-side intent check fallback
        const lower = textToSend.toLowerCase();
        if (
          lower.includes("slot") ||
          lower.includes("स्लॉट") ||
          lower.includes("token") ||
          lower.includes("टोकन") ||
          lower.includes("book") ||
          lower.includes("बुक")
        ) {
          let crop = "Soybean";
          if (lower.includes("wheat") || lower.includes("गेहूं")) crop = "Wheat";
          else if (lower.includes("mustard") || lower.includes("सरसों")) crop = "Mustard";
          else if (lower.includes("chana") || lower.includes("चना")) crop = "Chana";

          let targetMandi = mandis[0]?.name || "Neemuch Mandi";
          if (lower.includes("indore") || lower.includes("इंदौर")) targetMandi = "Indore APMC";
          else if (lower.includes("ujjain") || lower.includes("उज्जैन")) targetMandi = "Ujjain Grain Market";
          else if (lower.includes("mandsaur") || lower.includes("मंदसौर")) targetMandi = "Mandsaur Krishi Mandi";

          const qtyMatch = textToSend.match(/(\d+)/);
          const qty = qtyMatch ? parseInt(qtyMatch[1], 10) : 50;

          slotData = bookSlot({
            mandi: targetMandi,
            crop,
            quantity: qty,
            date: new Date(Date.now() + 86400000).toISOString().split("T")[0],
            timeSlot: "09:00 AM - 12:00 PM"
          });
        }
      }

      const assistantMsg = {
        id: `bot-${Date.now()}`,
        role: "assistant",
        text: data.reply,
        slot: slotData,
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
      };

      setMessages((prev) => [...prev, assistantMsg]);
    } catch {
      // Local fallback on any network error
      const lower = textToSend.toLowerCase();
      let fallbackSlot = null;

      if (
        lower.includes("slot") ||
        lower.includes("स्लॉट") ||
        lower.includes("token") ||
        lower.includes("टोकन") ||
        lower.includes("book") ||
        lower.includes("बुक")
      ) {
        fallbackSlot = bookSlot({
          mandi: "Neemuch Mandi",
          crop: "Soybean",
          quantity: 50,
          date: new Date(Date.now() + 86400000).toISOString().split("T")[0],
          timeSlot: "09:00 AM - 12:00 PM"
        });
      }

      const fallbackMsg = {
        id: `bot-${Date.now()}`,
        role: "assistant",
        text: fallbackSlot
          ? (lang === "en"
            ? `✅ **Mandi Arrival Slot Confirmed!**\n\n- **Token:** \`${fallbackSlot.token}\`\n- **Mandi:** ${fallbackSlot.mandi}\n- **Produce:** ${fallbackSlot.crop} (${fallbackSlot.quantity} Qtl)\n- **Date:** ${fallbackSlot.date} (${fallbackSlot.timeSlot})\n\nPresent this token at the entry gate scale for priority weighing.`
            : `✅ **मंडी अराइवल स्लॉट और टोकन सफलतापूर्वक बुक हो गया है!**\n\n- **टोकन:** \`${fallbackSlot.token}\`\n- **मंडी:** ${fallbackSlot.mandi}\n- **उपज:** ${fallbackSlot.crop} (${fallbackSlot.quantity} क्विंटल)\n- **दिनांक:** ${fallbackSlot.date} (${fallbackSlot.timeSlot})\n\nधर्मकांटा प्रवेश द्वार पर यह टोकन दिखाकर बिना कतार के प्रवेश करें।`)
          : (lang === "en"
            ? `🌾 **Kisan Mitra Support:** Today's live benchmark: Neemuch Soybean ₹4,720/Qtl, Indore Wheat ₹2,480/Qtl. Best Buyer: AgroHarvest @ ₹2,490/Qtl. To book a Mandi slot, type: *"Book slot for 50 qtl wheat"*`
            : `🌾 **किसान मित्र सहायता:** आज के प्रमुख भाव: नीमच मंडी सोयाबीन ₹4,720/क्विंटल, इंदौर गेहूं ₹2,480/क्विंटल। सर्वश्रेष्ठ खरीदार: मालवा ऑयल मिल्स @ ₹4,750/क्विंटल। मंडी स्लॉट बुक करने के लिए लिखें: *"50 क्विंटल गेहूं का स्लॉट बुक करें"*`),
        slot: fallbackSlot,
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
      };

      setMessages((prev) => [...prev, fallbackMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const copyTokenToClipboard = (token) => {
    navigator.clipboard.writeText(token);
    setCopiedToken(token);
    setTimeout(() => setCopiedToken(null), 2000);
  };

  const quickPrompts = lang === "en" ? [
    "📅 Book 50 Qtl Soybean slot for Neemuch Mandi",
    "📊 Today's live mandi prices",
    "🌾 Best buyer for wheat",
    "🛡️ How does escrow payment work?"
  ] : [
    "📅 नीमच मंडी में 50 क्विंटल सोयाबीन का स्लॉट बुक करें",
    "📊 आज के सभी मंडियों के ताज़ा भाव",
    "🌾 गेहूं के लिए सर्वश्रेष्ठ खरीदार कौन है?",
    "🛡️ एस्क्रो पेमेंट सुरक्षा कैसे काम करती है?"
  ];

  return (
    <>
      {/* Floating Launcher Button */}
      <div className="fixed bottom-6 right-6 z-50 flex items-center gap-2">
        {!isOpen && (
          <button
            onClick={() => setIsOpen(true)}
            className="flex items-center gap-2.5 bg-[#4A7C59] hover:bg-[#3d6749] text-white px-4 py-3 rounded-full shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:scale-105 cursor-pointer border-2 border-white/20"
          >
            <div className="relative">
              <Bot size={22} />
              <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-[#D97706] rounded-full animate-ping" />
              <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-[#D97706] rounded-full" />
            </div>
            <div className="text-left hidden sm:block">
              <span className="block font-heading font-bold text-xs leading-none">
                {lang === "en" ? "Kisan Mitra AI" : "किसान मित्र AI"}
              </span>
              <span className="text-[10px] text-white/80 font-medium">
                {lang === "en" ? "Ask prices & book slot" : "भाव पूछें व स्लॉट बुक करें"}
              </span>
            </div>
          </button>
        )}
      </div>

      {/* Main Chat Window */}
      {isOpen && (
        <div className="fixed bottom-5 right-4 sm:right-6 w-[95vw] sm:w-[420px] h-[580px] max-h-[85vh] bg-white rounded-2xl shadow-2xl border border-[#ded8cb] z-50 flex flex-col overflow-hidden animate-in fade-in slide-in-from-bottom-5 duration-200">
          {/* Header */}
          <div className="bg-[#4A7C59] text-white p-3.5 flex items-center justify-between shadow-sm">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-white/15 flex items-center justify-center text-white border border-white/20">
                <Bot size={20} />
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <h3 className="font-heading font-bold text-sm leading-tight m-0">
                    {lang === "en" ? "Kisan Mitra AI Assistant" : "किसान मित्र AI सहायक"}
                  </h3>
                  <span className="w-2 h-2 rounded-full bg-emerald-400" />
                </div>
                <span className="text-[11px] text-white/80 block">
                  {lang === "en" ? "Slot Booking • Prices • Advisory" : "स्लॉट बुकिंग • मंडी भाव • फसल सलाह"}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-1">
              <button
                onClick={() => setShowKeyModal(!showKeyModal)}
                title="Configure Free API Key"
                className="p-1.5 rounded-lg hover:bg-white/20 text-white/90 hover:text-white transition-colors cursor-pointer"
              >
                <Key size={16} />
              </button>
              <button
                onClick={() => setIsOpen(false)}
                className="p-1.5 rounded-lg hover:bg-white/20 text-white/90 hover:text-white transition-colors cursor-pointer"
              >
                <X size={18} />
              </button>
            </div>
          </div>

          {/* API Key Modal / Dropdown */}
          {showKeyModal && (
            <div className="p-3 bg-[#F5F1E8] border-b border-[#ded8cb] text-xs space-y-2 animate-in fade-in duration-150">
              <div className="flex items-center justify-between">
                <span className="font-bold text-[#2D2D2D] flex items-center gap-1.5">
                  <Key size={14} className="text-[#4A7C59]" />
                  {lang === "en" ? "AI Provider API Key" : "AI API की (Key)"}
                </span>
                <span className="text-[10px] text-[#4A7C59] font-semibold bg-[#4A7C59]/10 px-2 py-0.5 rounded-full">
                  Free Tier Ready
                </span>
              </div>
              <input
                type="password"
                placeholder="sk-or-v1-..."
                value={tempKey}
                onChange={(e) => setTempKey(e.target.value)}
                className="w-full bg-white border border-[#ded8cb] rounded-lg px-2.5 py-1.5 font-mono text-xs text-[#2D2D2D]"
              />
              <div className="flex items-center justify-between pt-1">
                <span className="text-[10px] text-[#8B6F47]">
                  Supports OpenRouter, Gemini, or Groq
                </span>
                <button
                  onClick={handleSaveKey}
                  className="bg-[#4A7C59] text-white px-3 py-1 rounded-lg font-bold text-xs hover:bg-[#3d6749] cursor-pointer"
                >
                  Save Key
                </button>
              </div>
            </div>
          )}

          {/* Chat Messages Body */}
          <div className="flex-1 overflow-y-auto p-3.5 space-y-3 bg-[#fbf9f5]">
            {messages.map((msg) => {
              const isBot = msg.role === "assistant";
              return (
                <div
                  key={msg.id}
                  className={`flex flex-col ${isBot ? "items-start" : "items-end"}`}
                >
                  <div className="flex items-center gap-1 mb-1 px-1 text-[10px] text-[#8B6F47]">
                    {isBot ? (
                      <>
                        <Sparkles size={11} className="text-[#4A7C59]" />
                        <span>Kisan Mitra AI</span>
                      </>
                    ) : (
                      <span>You</span>
                    )}
                    <span>• {msg.timestamp}</span>
                  </div>

                  <div
                    className={`max-w-[88%] rounded-2xl p-3 text-xs leading-relaxed shadow-sm ${
                      isBot
                        ? "bg-white text-[#2D2D2D] border border-[#ded8cb]"
                        : "bg-[#4A7C59] text-white font-medium rounded-br-sm"
                    }`}
                  >
                    <p className="whitespace-pre-line m-0">{msg.text}</p>

                    {/* Verified Mandi Gate Entry Pass Card */}
                    {msg.slot && (
                      <div className="mt-3 bg-[#F5F1E8] border-2 border-[#4A7C59] rounded-xl p-3 text-[#2D2D2D] space-y-2 shadow-sm">
                        <div className="flex items-center justify-between border-b border-[#ded8cb] pb-1.5">
                          <div className="flex items-center gap-1.5 text-[#4A7C59] font-heading font-bold text-xs">
                            <CheckCircle2 size={16} />
                            <span>Mandi Entry Pass Confirmed</span>
                          </div>
                          <span className="text-[10px] bg-[#4A7C59] text-white px-2 py-0.5 rounded-full font-bold uppercase">
                            Active
                          </span>
                        </div>

                        <div className="grid grid-cols-2 gap-2 text-[11px]">
                          <div>
                            <span className="text-[#8B6F47] block text-[10px]">Token Number</span>
                            <span className="font-mono font-bold text-[#2D2D2D] text-xs">
                              {msg.slot.token}
                            </span>
                          </div>
                          <div>
                            <span className="text-[#8B6F47] block text-[10px]">Mandi Gate</span>
                            <span className="font-bold text-[#2D2D2D]">
                              {msg.slot.mandi}
                            </span>
                          </div>
                          <div>
                            <span className="text-[#8B6F47] block text-[10px]">Crop & Quantity</span>
                            <span className="font-bold text-[#2D2D2D]">
                              {msg.slot.crop} • {msg.slot.quantity} Qtl
                            </span>
                          </div>
                          <div>
                            <span className="text-[#8B6F47] block text-[10px]">Arrival Window</span>
                            <span className="font-bold text-[#2D2D2D]">
                              {msg.slot.date}
                            </span>
                          </div>
                        </div>

                        <div className="pt-1 flex items-center justify-between gap-2 border-t border-[#ded8cb]">
                          <span className="text-[10px] text-[#8B6F47]">
                            Time: {msg.slot.timeSlot || "09:00 AM - 12:00 PM"}
                          </span>
                          <button
                            onClick={() => copyTokenToClipboard(msg.slot.token)}
                            className="flex items-center gap-1 bg-white border border-[#ded8cb] hover:bg-[#F5F1E8] text-[#2D2D2D] px-2 py-0.5 rounded text-[10px] font-bold cursor-pointer"
                          >
                            {copiedToken === msg.slot.token ? (
                              <>
                                <Check size={11} className="text-[#4A7C59]" />
                                <span>Copied</span>
                              </>
                            ) : (
                              <>
                                <Copy size={11} />
                                <span>Copy Token</span>
                              </>
                            )}
                          </button>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Audio Readout Button */}
                  {isBot && (
                    <button
                      onClick={() => speakMessage(msg.text)}
                      title="Listen"
                      className="mt-1 text-[#8B6F47] hover:text-[#4A7C59] flex items-center gap-1 text-[10px] px-1 transition-colors cursor-pointer"
                    >
                      <Volume2 size={12} />
                      <span>{lang === "en" ? "Listen" : "सुनें"}</span>
                    </button>
                  )}
                </div>
              );
            })}

            {isLoading && (
              <div className="flex items-center gap-2 text-xs text-[#8B6F47] bg-white border border-[#ded8cb] p-2.5 rounded-xl w-fit">
                <RefreshCw size={14} className="animate-spin text-[#4A7C59]" />
                <span>{lang === "en" ? "Kisan Mitra is thinking..." : "किसान मित्र जानकारी खोज रहा है..."}</span>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Quick Prompts Carousel */}
          <div className="px-3 py-2 bg-white border-t border-[#ded8cb] flex gap-1.5 overflow-x-auto no-scrollbar">
            {quickPrompts.map((prompt, i) => (
              <button
                key={i}
                onClick={() => handleSend(prompt)}
                className="shrink-0 bg-[#F5F1E8] hover:bg-[#4A7C59] hover:text-white text-[#2D2D2D] text-[11px] font-medium px-2.5 py-1 rounded-full border border-[#ded8cb] transition-colors cursor-pointer"
              >
                {prompt}
              </button>
            ))}
          </div>

          {/* Input Box & Mic */}
          <div className="p-3 bg-white border-t border-[#ded8cb] flex items-center gap-2">
            <button
              onClick={toggleListening}
              className={`p-2.5 rounded-xl transition-all cursor-pointer ${
                isListening
                  ? "bg-red-500 text-white animate-pulse"
                  : "bg-[#F5F1E8] text-[#8B6F47] hover:text-[#4A7C59] border border-[#ded8cb]"
              }`}
              title={isListening ? "Listening... Click to stop" : "Speak (Hindi/English)"}
            >
              {isListening ? <MicOff size={16} /> : <Mic size={16} />}
            </button>

            <input
              type="text"
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") handleSend();
              }}
              placeholder={
                lang === "en"
                  ? "Ask rates or 'Book slot for 50 qtl wheat'..."
                  : "भाव पूछें या '50 क्विंटल गेहूं का स्लॉट बुक करें'..."
              }
              className="flex-1 bg-[#F5F1E8] border border-[#ded8cb] rounded-xl px-3 py-2 text-xs text-[#2D2D2D] focus:outline-none focus:ring-1 focus:ring-[#4A7C59]"
            />

            <button
              onClick={() => handleSend()}
              disabled={!inputMessage.trim() || isLoading}
              className={`p-2.5 rounded-xl transition-colors cursor-pointer ${
                inputMessage.trim() && !isLoading
                  ? "bg-[#4A7C59] hover:bg-[#3d6749] text-white shadow-sm"
                  : "bg-gray-100 text-gray-400 cursor-not-allowed"
              }`}
            >
              <Send size={16} />
            </button>
          </div>
        </div>
      )}
    </>
  );
}
