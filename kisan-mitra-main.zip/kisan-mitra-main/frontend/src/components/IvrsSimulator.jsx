import React, { useState, useEffect, useRef } from "react";
import {
  PhoneCall,
  PhoneOff,
  Mic,
  Volume2,
  VolumeX,
  Hash,
  CheckCircle2,
  AlertTriangle,
  RotateCcw,
  Sparkles,
  Radio,
  FileCheck,
  Send,
  Info,
  Calendar,
  Building2,
  UserCheck
} from "lucide-react";
import { useApp } from "../context/AppContext";

export default function IvrsSimulator() {
  const {
    activeFarmerId,
    getFarmer,
    mandis,
    buyers,
    priceAlerts,
    addLot,
    bookSlot,
    makeOffer,
    acceptOffer,
    t
  } = useApp();

  const farmer = getFarmer(activeFarmerId) || {
    name: "Ramesh Patel",
    village: "Pipliya Mandi",
    phone: "+91 98261 45120"
  };

  // Call session states: 'idle' | 'calling' | 'connected' | 'completed'
  const [callState, setCallState] = useState("idle");
  const [callDuration, setCallDuration] = useState(0);

  // Audio Voice Synth state
  const [voiceMuted, setVoiceMuted] = useState(false);

  // IVR Flow Steps:
  // 1: Language Selection (Hindi=1, English=2)
  // 2: Crop Selection (Wheat=1, Soybean=2, Mustard=3, Chana=4)
  // 3: Quantity & Batch Selection
  // 4: Live Mandi Price & Buyer Comparison Readout
  // 5: Choice: (1) Choose Best Buyer, (2) Schedule Mandi Gate Entry Token, (3) Open Batch
  // 6: Confirmation Ticket & Batch Scheduled
  const [ivrStep, setIvrStep] = useState(1);

  // Farmer's IVR Responses
  const [selectedLang, setSelectedLang] = useState("Hindi");
  const [selectedCrop, setSelectedCrop] = useState("Soybean");
  const [inputQuantity, setInputQuantity] = useState("50");
  const [selectedActionType, setSelectedActionType] = useState("");
  const [refNumber, setRefNumber] = useState("");
  const [createdLotRef, setCreatedLotRef] = useState(null);
  const [createdSlotRef, setCreatedSlotRef] = useState(null);
  const [chosenBuyer, setChosenBuyer] = useState(null);

  // Transcript log history
  const [transcript, setTranscript] = useState([]);
  const transcriptEndRef = useRef(null);

  // Helper: Audio readout via Web Speech API
  const speakText = (text, language = selectedLang) => {
    if (voiceMuted || !("speechSynthesis" in window)) return;
    try {
      window.speechSynthesis.cancel();
      // Remove symbols and clean text
      const clean = text.replace(/[*_#`\n]/g, " ").replace(/₹/g, "rupees ");
      const utterance = new SpeechSynthesisUtterance(clean);
      utterance.lang = language === "English" ? "en-IN" : "hi-IN";
      utterance.rate = 0.95;
      window.speechSynthesis.speak(utterance);
    } catch {
      // Speech fallback
    }
  };

  // Call timer simulation
  useEffect(() => {
    let interval = null;
    if (callState === "connected") {
      interval = setInterval(() => {
        setCallDuration((prev) => prev + 1);
      }, 1000);
    } else {
      clearInterval(interval);
    }
    return () => clearInterval(interval);
  }, [callState]);

  useEffect(() => {
    transcriptEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [transcript]);

  // Format call duration MM:SS
  const formatTime = (secs) => {
    const mins = Math.floor(secs / 60);
    const rem = secs % 60;
    return `${mins.toString().padStart(2, "0")}:${rem.toString().padStart(2, "0")}`;
  };

  // Start Call
  const handleStartCall = () => {
    setCallState("calling");
    setCallDuration(0);
    setIvrStep(1);
    setInputQuantity("50");
    setTranscript([]);
    setCreatedLotRef(null);
    setCreatedSlotRef(null);
    setSelectedActionType("");

    setTimeout(() => {
      setCallState("connected");
      const greetingHi = "नमस्ते! किसान मित्र टेलीफोन सेवा में आपका स्वागत है। हिंदी के लिए 1 दबाएं।";
      const greetingEn = "Welcome to Kisan Mitra IVR helpline. For English press 2.";

      setTranscript([
        {
          speaker: "ivr",
          text: `${greetingHi}\n\n${greetingEn}`,
          step: 1
        }
      ]);

      speakText("नमस्ते! किसान मित्र सेवा में आपका स्वागत है। हिंदी के लिए 1 दबाएं। For English press 2.", "Hindi");
    }, 1500);
  };

  // End Call
  const handleEndCall = () => {
    if ("speechSynthesis" in window) {
      window.speechSynthesis.cancel();
    }
    setCallState("idle");
    setIvrStep(1);
  };

  // Helper: Get prices
  const cropMandis = mandis.filter(
    (m) => m.crop?.toLowerCase() === selectedCrop.toLowerCase()
  );
  const benchmarkMandi = cropMandis[0] || mandis[0];
  const price1 = benchmarkMandi ? benchmarkMandi.price : 4720;
  const price2 = Math.round(price1 * 1.015);
  const price3 = Math.round(price1 * 0.985);

  const bestBuyer = buyers.find(
    (b) => b.demand?.crop?.toLowerCase() === selectedCrop.toLowerCase()
  ) || buyers[0];
  const buyerPrice = Math.round(price1 * 1.02);

  const activeAlert = priceAlerts.find(
    (a) => a.crop?.toLowerCase() === selectedCrop.toLowerCase()
  );

  // Keypad Press Handler
  const handleKeypadPress = (digit) => {
    if (callState !== "connected") return;

    if (ivrStep === 1) {
      // Step 1: Language selection
      const langChoice = digit === "2" ? "English" : "Hindi";
      setSelectedLang(langChoice);

      const promptText = langChoice === "English"
        ? "Please select your crop: Press 1 for Wheat, Press 2 for Soybean, Press 3 for Mustard, Press 4 for Chana."
        : "कृपया अपनी फसल चुनें: 1 दबाएं गेहूं हेतु, 2 दबाएं सोयाबीन हेतु, 3 दबाएं सरसों हेतु, 4 दबाएं चना हेतु।";

      setTranscript((prev) => [
        ...prev,
        { speaker: "farmer", text: `Pressed [${digit}] — ${langChoice}` },
        { speaker: "ivr", text: promptText, step: 2 }
      ]);

      speakText(promptText, langChoice);
      setIvrStep(2);
    } else if (ivrStep === 2) {
      // Step 2: Crop selection
      const cropMap = { "1": "Wheat", "2": "Soybean", "3": "Mustard", "4": "Chana" };
      const chosen = cropMap[digit] || "Soybean";
      setSelectedCrop(chosen);

      const promptText = selectedLang === "English"
        ? `You selected ${chosen}. Please enter quantity in quintals and press hash (#) or Confirm below. (Example: 50 quintals)`
        : `आपने ${chosen} चुना है। कृपया अपनी उपज की मात्रा (क्विंटल में) दर्ज करें और नीचे Confirm [#] दबाएं।`;

      setTranscript((prev) => [
        ...prev,
        { speaker: "farmer", text: `Pressed [${digit}] — ${chosen}` },
        { speaker: "ivr", text: promptText, step: 3 }
      ]);

      speakText(promptText, selectedLang);
      setIvrStep(3);
    } else if (ivrStep === 3) {
      // Quantity typing via keypad
      if (digit !== "#") {
        setInputQuantity((prev) => (prev === "50" ? digit : `${prev}${digit}`));
      } else {
        handleConfirmQuantity();
      }
    } else if (ivrStep === 5) {
      // Step 5: Choose Buyer or Mandi Token
      if (digit === "1") {
        // CHOICE 1: Choose Top Buyer
        const generatedToken = `IVR-BUYER-${Math.floor(1000 + Math.random() * 9000)}`;
        setRefNumber(generatedToken);
        setSelectedActionType("Direct Buyer Dispatch");
        setChosenBuyer(bestBuyer);

        // Add lot & accepted offer in state
        const created = addLot({
          crop: selectedCrop,
          quantity: Number(inputQuantity) || 50,
          grade: "A",
          farmerId: activeFarmerId
        });
        setCreatedLotRef(created);

        const promptText = selectedLang === "English"
          ? `Congratulations! Your batch of ${inputQuantity} Quintals ${selectedCrop} is booked with ${bestBuyer.name} at ₹${buyerPrice} per quintal. Reference Token: ${generatedToken}. Payment is escrow protected. An SMS has been sent to ${farmer.phone}. Thank you!`
          : `बधाई हो! आपका ${inputQuantity} क्विंटल ${selectedCrop} का बैच खरीदार ${bestBuyer.name} को ₹${buyerPrice} प्रति क्विंटल में बुक हो गया है। संदर्भ टोकन: ${generatedToken}। भुगतान एस्क्रो में सुरक्षित है। एसएमएस आपके नंबर ${farmer.phone} पर भेज दिया गया है। धन्यवाद!`;

        setTranscript((prev) => [
          ...prev,
          { speaker: "farmer", text: `Pressed [1] — Choose Top Buyer (${bestBuyer.name})` },
          { speaker: "ivr", text: promptText, step: 6 }
        ]);

        speakText(promptText, selectedLang);
        setIvrStep(6);
      } else if (digit === "2") {
        // CHOICE 2: Schedule Mandi Gate Entry Token
        const generatedToken = `KM-IVR-${Math.floor(1000 + Math.random() * 9000)}`;
        setRefNumber(generatedToken);
        setSelectedActionType("Mandi Arrival Gate Pass");

        const slot = bookSlot({
          mandi: benchmarkMandi.name || "Neemuch Mandi",
          crop: selectedCrop,
          quantity: Number(inputQuantity) || 50,
          farmerName: farmer.name,
          phone: farmer.phone,
          date: new Date(Date.now() + 86400000).toISOString().split("T")[0],
          timeSlot: "09:00 AM - 12:00 PM"
        });
        setCreatedSlotRef(slot);

        const promptText = selectedLang === "English"
          ? `Success! Your Mandi Arrival Gate Entry Slot at ${benchmarkMandi.name || "Neemuch Mandi"} is confirmed for tomorrow morning. Your Token is: ${generatedToken}. Show this token at the weighbridge. SMS sent to ${farmer.phone}.`
          : `सफलतापूर्वक दर्ज! ${benchmarkMandi.name || "नीमच मंडी"} के लिए आपका अराइवल स्लॉट व गेट पास बुक हो गया है। आपका टोकन नंबर है: ${generatedToken}। धर्मकांटे पर यह टोकन दिखाएं। एसएमएस ${farmer.phone} पर भेजा गया है।`;

        setTranscript((prev) => [
          ...prev,
          { speaker: "farmer", text: `Pressed [2] — Schedule Mandi Arrival Slot` },
          { speaker: "ivr", text: promptText, step: 6 }
        ]);

        speakText(promptText, selectedLang);
        setIvrStep(6);
      } else {
        // CHOICE 3: Open Batch for Competitive Bidding
        const generatedToken = `IVR-LOT-${Math.floor(1000 + Math.random() * 9000)}`;
        setRefNumber(generatedToken);
        setSelectedActionType("Open Competitive Bidding");

        const created = addLot({
          crop: selectedCrop,
          quantity: Number(inputQuantity) || 50,
          grade: "A",
          farmerId: activeFarmerId
        });
        setCreatedLotRef(created);

        const promptText = selectedLang === "English"
          ? `Your lot of ${inputQuantity} Quintals ${selectedCrop} is listed for all verified buyers to bid. Token: ${generatedToken}. You will receive SMS alerts as bids arrive.`
          : `आपका ${inputQuantity} क्विंटल ${selectedCrop} का लॉट सभी सत्यापित खरीदारों के लिए सूचीबद्ध हो गया है। टोकन: ${generatedToken}। बोलियां आने पर आपको एसएमएस मिलेगा।`;

        setTranscript((prev) => [
          ...prev,
          { speaker: "farmer", text: `Pressed [3] — Open Bidding Batch` },
          { speaker: "ivr", text: promptText, step: 6 }
        ]);

        speakText(promptText, selectedLang);
        setIvrStep(6);
      }
    }
  };

  // Submit Quantity in Step 3
  const handleConfirmQuantity = () => {
    const qty = Number(inputQuantity) || 50;

    let pricesText = "";
    let optionsText = "";

    if (selectedLang === "English") {
      pricesText = `Please listen carefully to today's live prices for ${selectedCrop}:
1. Neemuch Mandi: ₹${price1} per quintal.
2. Indore APMC: ₹${price2} per quintal.
3. Ujjain Mandi: ₹${price3} per quintal.

Top Buyer Bid: ${bestBuyer.name} offers ₹${buyerPrice} per quintal with direct pickup.`;

      optionsText = `To choose your option:
- Press 1 to sell directly to Top Buyer (${bestBuyer.name}) at ₹${buyerPrice}/Qtl.
- Press 2 to schedule a Mandi Arrival Gate Entry Token for tomorrow.
- Press 3 to list as an open competitive batch.`;
    } else {
      pricesText = `कृपया ध्यान से सुनें। आपके क्षेत्र में ${selectedCrop} के आज के भाव इस प्रकार हैं:
1. नीमच मंडी: ₹${price1} प्रति क्विंटल।
2. इंदौर APMC: ₹${price2} प्रति क्विंटल।
3. उज्जैन मंडी: ₹${price3} प्रति क्विंटल।

शीर्ष खरीदार ऑफर: ${bestBuyer.name} द्वारा ₹${buyerPrice} प्रति क्विंटल का सीधा ऑफर।`;

      optionsText = `कृपया अपना विकल्प चुनें:
- शीर्ष खरीदार (${bestBuyer.name}) को ₹${buyerPrice} में बेचने हेतु 1 दबाएं।
- कल के लिए मंडी अराइवल गेट पास टोकन बुक करने हेतु 2 दबाएं।
- खुली बोली हेतु ओपन लॉट रजिस्टर करने के लिए 3 दबाएं।`;
    }

    setTranscript((prev) => [
      ...prev,
      { speaker: "farmer", text: `Entered Quantity: ${qty} Quintals [#]` },
      { speaker: "ivr", text: pricesText, step: 4 },
      { speaker: "ivr", text: optionsText, step: 5 }
    ]);

    speakText(`${pricesText} ${optionsText}`, selectedLang);
    setIvrStep(5);
  };

  return (
    <div className="space-y-6">
      {/* 1. Header Banner & Telecom Production Note */}
      <div className="bg-white rounded-xl shadow-md p-4 border border-[#e2dcd0] flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-xl bg-[#4A7C59] text-white flex items-center justify-center shadow-sm">
              <PhoneCall size={22} />
            </div>
            <div>
              <h1 className="font-heading font-bold text-xl text-[#2D2D2D] m-0">
                {selectedLang === "English"
                  ? "Interactive Voice Helpline (IVRS)"
                  : "इंटरएक्टिव वॉयस हेल्पलाइन (IVRS)"}
              </h1>
              <span className="text-xs text-[#8B6F47]">
                Voice portal for keypad phones • Hindi & English Speech Engine • Live Mandi Rates
              </span>
            </div>
          </div>
        </div>

        {/* Audio Toggle & Telecom Note */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              setVoiceMuted(!voiceMuted);
              if (!voiceMuted && "speechSynthesis" in window) {
                window.speechSynthesis.cancel();
              }
            }}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs font-bold transition-colors cursor-pointer ${
              voiceMuted
                ? "bg-red-50 text-red-700 border-red-200"
                : "bg-emerald-50 text-[#4A7C59] border-emerald-200"
            }`}
          >
            {voiceMuted ? <VolumeX size={15} /> : <Volume2 size={15} />}
            <span>{voiceMuted ? "Voice: Muted" : "Voice: Speaking"}</span>
          </button>

          <div className="bg-[#F5F1E8] border border-[#ded8cb] rounded-xl px-3 py-1.5 text-xs text-[#8B6F47] font-mono">
            Toll-Free: 1800-KISAN-MITRA
          </div>
        </div>
      </div>

      {/* 2. Main Phone Call Interactive Screen */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left Side: Call Controller & Keypad (5 Cols) */}
        <div className="lg:col-span-5 bg-white rounded-xl shadow-md p-4 border border-[#e2dcd0] flex flex-col justify-between space-y-4">
          <div>
            {/* Call Status Header */}
            <div className="bg-[#F5F1E8] rounded-xl p-4 border border-[#ded8cb] text-center space-y-2">
              <div className="flex items-center justify-center gap-2">
                <span className="font-mono text-xs text-[#8B6F47]">
                  Telecom DTMF + Speech Integration
                </span>
              </div>

              {callState === "idle" && (
                <div className="py-4">
                  <div className="w-16 h-16 rounded-xl bg-white border border-[#ded8cb] mx-auto flex items-center justify-center text-[#8B6F47] mb-2 shadow-sm">
                    <PhoneCall size={26} />
                  </div>
                  <h3 className="font-heading font-bold text-base text-[#2D2D2D] m-0">
                    Kisan Mitra IVRS Ready
                  </h3>
                  <p className="text-xs text-[#8B6F47] mt-1">
                    Caller: {farmer.name} ({farmer.phone})
                  </p>
                </div>
              )}

              {callState === "calling" && (
                <div className="py-4 animate-pulse">
                  <div className="w-16 h-16 rounded-xl bg-[#4A7C59] text-white mx-auto flex items-center justify-center mb-2 shadow-md">
                    <Radio size={26} />
                  </div>
                  <h3 className="font-heading font-bold text-base text-[#4A7C59] m-0">
                    Connecting Helpline...
                  </h3>
                  <span className="text-xs text-[#8B6F47]">Initiating Telecom Voice Engine</span>
                </div>
              )}

              {(callState === "connected" || callState === "completed") && (
                <div className="py-2">
                  <div className="flex items-center justify-center gap-2 text-[#4A7C59]">
                    <div className="w-2.5 h-2.5 rounded-full bg-[#4A7C59] animate-ping" />
                    <span className="font-bold text-xs uppercase tracking-wider">
                      Call In Progress
                    </span>
                  </div>
                  <div className="font-mono font-bold text-2xl text-[#2D2D2D] mt-1">
                    {formatTime(callDuration)}
                  </div>
                  <span className="text-xs text-[#8B6F47]">
                    Language: {selectedLang} • Step {ivrStep} of 5
                  </span>
                </div>
              )}
            </div>

            {/* Call Action Button */}
            <div className="mt-4">
              {callState === "idle" ? (
                <button
                  onClick={handleStartCall}
                  className="w-full bg-[#4A7C59] hover:bg-[#3d6749] text-white rounded-xl py-3 text-sm font-bold flex items-center justify-center gap-2 shadow-md transition-colors cursor-pointer"
                >
                  <PhoneCall size={18} />
                  <span>Start IVR Voice Call</span>
                </button>
              ) : (
                <button
                  onClick={handleEndCall}
                  className="w-full bg-[#C0392B] hover:bg-[#a02c20] text-white rounded-xl py-3 text-sm font-bold flex items-center justify-center gap-2 shadow-md transition-colors cursor-pointer"
                >
                  <PhoneOff size={18} />
                  <span>End Call</span>
                </button>
              )}
            </div>

            {/* Interactive Phone Keypad */}
            <div className="mt-4 pt-4 border-t border-[#F5F1E8]">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-semibold text-[#8B6F47]">
                  DTMF Interactive Dialpad
                </span>
                <span className="text-[11px] font-mono text-[#4A7C59]">
                  {callState === "connected" ? `Active (Step ${ivrStep})` : "Offline"}
                </span>
              </div>

              <div className="grid grid-cols-3 gap-2">
                {["1", "2", "3", "4", "5", "6", "7", "8", "9", "*", "0", "#"].map((key) => (
                  <button
                    key={key}
                    disabled={callState !== "connected"}
                    onClick={() => handleKeypadPress(key)}
                    className={`py-3 rounded-xl font-heading font-bold text-lg border transition-all ${
                      callState === "connected"
                        ? "bg-[#F5F1E8] text-[#2D2D2D] border-[#ded8cb] hover:bg-[#4A7C59] hover:text-white cursor-pointer active:scale-95"
                        : "bg-[#f5f1e8]/50 text-[#8B6F47] border-[#ded8cb]/40 cursor-not-allowed opacity-50"
                    }`}
                  >
                    {key}
                  </button>
                ))}
              </div>
            </div>

            {/* In-Call Quantity Entry Form for Step 3 */}
            {callState === "connected" && ivrStep === 3 && (
              <div className="mt-4 p-3 bg-[#fff8eb] border border-[#D97706] rounded-xl space-y-2 animate-in fade-in">
                <span className="text-xs font-bold text-[#2D2D2D] block">
                  Quantity (Quintals):
                </span>
                <div className="flex gap-2">
                  <input
                    type="number"
                    min="1"
                    value={inputQuantity}
                    onChange={(e) => setInputQuantity(e.target.value)}
                    className="flex-1 bg-white border border-[#ded8cb] rounded-xl px-3 py-1.5 text-sm font-bold text-[#2D2D2D]"
                  />
                  <button
                    onClick={handleConfirmQuantity}
                    className="bg-[#4A7C59] text-white rounded-xl px-4 py-1.5 text-xs font-bold hover:bg-[#3d6749] cursor-pointer"
                  >
                    Confirm [#]
                  </button>
                </div>
              </div>
            )}
          </div>

          <div className="text-[11px] text-[#8B6F47] text-center pt-2">
            Works on 2G feature phones with no internet. Automated voice speech synthesizer enabled.
          </div>
        </div>

        {/* Right Side: Chat-Bubble Voice Transcript (7 Cols) */}
        <div className="lg:col-span-7 bg-white rounded-xl shadow-md p-4 border border-[#e2dcd0] flex flex-col h-[580px]">
          <div className="flex items-center justify-between pb-3 border-b border-[#F5F1E8]">
            <div className="flex items-center gap-2">
              <div className="text-[#4A7C59] flex items-center">
                <Volume2 size={20} />
              </div>
              <h2 className="font-heading font-bold text-base text-[#2D2D2D] m-0">
                Live Bilingual Voice & DTMF Transcript
              </h2>
            </div>
            <span className="text-xs text-[#8B6F47]">
              TTS / Audio Active
            </span>
          </div>

          {/* Transcript Scroll Area */}
          <div className="flex-1 overflow-y-auto p-3 space-y-3 bg-[#F5F1E8] rounded-xl mt-3 border border-[#ded8cb]">
            {transcript.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-[#8B6F47] text-center p-6">
                <Mic size={32} className="mb-2 text-[#8B6F47]/70" />
                <p className="font-medium text-sm">Call has not been initiated yet.</p>
                <p className="text-xs mt-1 max-w-sm">
                  Click "Start IVR Voice Call" on the left to experience the interactive Hindi/English audio flow.
                </p>
              </div>
            ) : (
              transcript.map((item, idx) => {
                const isIvr = item.speaker === "ivr";
                return (
                  <div
                    key={idx}
                    className={`flex flex-col ${isIvr ? "items-start" : "items-end"}`}
                  >
                    <div className="flex items-center gap-1.5 mb-1 px-1">
                      <span className="text-[11px] font-bold text-[#8B6F47]">
                        {isIvr ? "Kisan Mitra Voice Engine" : `${farmer.name} (Keypad)`}
                      </span>
                    </div>

                    <div
                      className={`max-w-[88%] rounded-xl p-3 text-xs leading-relaxed shadow-sm ${
                        isIvr
                          ? "bg-white text-[#2D2D2D] border border-[#ded8cb]"
                          : "bg-[#4A7C59] text-white font-medium"
                      }`}
                    >
                      <p className="whitespace-pre-line m-0">{item.text}</p>
                    </div>
                  </div>
                );
              })
            )}
            <div ref={transcriptEndRef} />
          </div>

          {/* Result Ticket Card */}
          {(createdLotRef || createdSlotRef) && (
            <div className="mt-3 p-3 bg-white border-2 border-[#4A7C59] rounded-xl flex items-center justify-between gap-3 shadow-sm animate-in fade-in">
              <div className="flex items-center gap-2.5">
                <div className="text-[#4A7C59]">
                  <CheckCircle2 size={24} />
                </div>
                <div>
                  <span className="font-heading font-bold text-sm text-[#2D2D2D] block">
                    {selectedActionType}: {selectedCrop} ({inputQuantity} Qtl)
                  </span>
                  <span className="text-xs text-[#8B6F47] font-mono">
                    Token Ref: {refNumber} • Status: CONFIRMED
                  </span>
                </div>
              </div>
              <span className="bg-[#4A7C59] text-white text-xs font-bold px-3 py-1.5 rounded-xl shrink-0">
                Synced in Database
              </span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
