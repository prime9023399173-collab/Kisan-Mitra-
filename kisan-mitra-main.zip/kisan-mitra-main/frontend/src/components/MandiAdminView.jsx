import React, { useState } from "react";
import {
  Landmark,
  TrendingUp,
  AlertCircle,
  CheckCircle2,
  Clock,
  Edit3,
  Check,
  XCircle,
  FileQuestion,
  Layers,
  MapPin,
  Calendar
} from "lucide-react";
import { useApp } from "../context/AppContext";
import MiniPriceChart from "./MiniPriceChart";

export default function MandiAdminView() {
  const {
    mandis,
    grievances,
    transactions,
    lots,
    farmers,
    buyers,
    offers,
    updateMandiPrice,
    updateGrievanceStatus
  } = useApp();

  // Price editing state
  const [editingMandiId, setEditingMandiId] = useState(null);
  const [editPriceInput, setEditPriceInput] = useState("");

  const handleStartEdit = (mandi) => {
    setEditingMandiId(mandi.id);
    setEditPriceInput(mandi.price.toString());
  };

  const handleSavePrice = (mandiId) => {
    if (!editPriceInput || Number(editPriceInput) <= 0) return;
    updateMandiPrice(mandiId, Number(editPriceInput));
    setEditingMandiId(null);
  };

  return (
    <div className="space-y-6">
      {/* Header Profile */}
      <div className="bg-white rounded-xl shadow-md p-4 flex flex-col md:flex-row md:items-center justify-between gap-4 border border-[#e2dcd0]">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-[#8B6F47] text-white flex items-center justify-center shadow-md">
            <Landmark size={24} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="font-heading font-bold text-2xl text-[#2D2D2D] m-0">
                APMC Mandi Administration Portal
              </h2>
              <span className="bg-[#4A7C59] text-white text-xs font-semibold px-2.5 py-0.5 rounded-xl">
                Official APMC Desk
              </span>
            </div>
            <p className="text-sm text-[#8B6F47] mt-0.5">
              Agricultural Produce Market Committee Daily MSP & Dispute Resolution Board
            </p>
          </div>
        </div>
      </div>

      {/* KPI Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl shadow-md p-4 border border-[#e2dcd0]">
          <div className="flex items-center justify-between">
            <span className="text-sm text-[#8B6F47] font-medium">Monitored Mandis</span>
            <div className="text-[#4A7C59] flex items-center">
              <Landmark size={24} />
            </div>
          </div>
          <div className="font-heading font-bold text-2xl text-[#2D2D2D] mt-2">
            {mandis.length} APMCs
          </div>
          <p className="text-xs text-[#8B6F47] mt-1">Across MP, MH, RJ & HR</p>
        </div>

        <div className="bg-white rounded-xl shadow-md p-4 border border-[#e2dcd0]">
          <div className="flex items-center justify-between">
            <span className="text-sm text-[#8B6F47] font-medium">Active Grievances</span>
            <div className="text-[#D97706] flex items-center">
              <AlertCircle size={24} />
            </div>
          </div>
          <div className="font-heading font-bold text-2xl text-[#2D2D2D] mt-2">
            {grievances.filter((g) => g.status !== "resolved").length} Pending
          </div>
          <p className="text-xs text-[#8B6F47] mt-1">Requiring APMC intervention</p>
        </div>

        <div className="bg-white rounded-xl shadow-md p-4 border border-[#e2dcd0]">
          <div className="flex items-center justify-between">
            <span className="text-sm text-[#8B6F47] font-medium">Platform Lots</span>
            <div className="text-[#8B6F47] flex items-center">
              <Layers size={24} />
            </div>
          </div>
          <div className="font-heading font-bold text-2xl text-[#2D2D2D] mt-2">
            {lots.length} Lots
          </div>
          <p className="text-xs text-[#8B6F47] mt-1">
            {lots.reduce((acc, curr) => acc + curr.quantity, 0)} Total Quintals
          </p>
        </div>

        <div className="bg-white rounded-xl shadow-md p-4 border border-[#e2dcd0]">
          <div className="flex items-center justify-between">
            <span className="text-sm text-[#8B6F47] font-medium">Resolved Disputes</span>
            <div className="text-[#4A7C59] flex items-center">
              <CheckCircle2 size={24} />
            </div>
          </div>
          <div className="font-heading font-bold text-2xl text-[#2D2D2D] mt-2">
            {grievances.filter((g) => g.status === "resolved").length} Settled
          </div>
          <p className="text-xs text-[#8B6F47] mt-1">Full resolution recorded</p>
        </div>
      </div>

      {/* APMC Mandi Daily Rates Table & Price Update Board */}
      <div className="bg-white rounded-xl shadow-md p-4 border border-[#e2dcd0]">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4 pb-2 border-b border-[#F5F1E8]">
          <div className="flex items-center gap-2">
            <div className="text-[#4A7C59] flex items-center">
              <TrendingUp size={24} />
            </div>
            <div>
              <h3 className="font-heading font-semibold text-lg text-[#2D2D2D] m-0">
                APMC Mandi Rate Board & 7-Day History
              </h3>
              <span className="text-xs text-[#8B6F47]">
                Click "Update Rate" to broadcast rate adjustments and publish automated price alerts.
              </span>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {mandis.map((mandi) => {
            const isEditing = editingMandiId === mandi.id;

            return (
              <div
                key={mandi.id}
                className="bg-[#F5F1E8] rounded-xl p-4 border border-[#e2dcd0] flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between">
                    <div>
                      <h4 className="font-heading font-bold text-base text-[#2D2D2D] m-0">
                        {mandi.name}
                      </h4>
                      <div className="flex items-center gap-1.5 text-xs text-[#8B6F47] mt-1">
                        <MapPin size={24} className="text-[#8B6F47]" />
                        <span>{mandi.location}</span>
                      </div>
                    </div>
                    <span className="bg-white border border-[#ded8cb] text-[#2D2D2D] font-heading font-bold text-xs px-2.5 py-1 rounded-xl">
                      {mandi.crop}
                    </span>
                  </div>

                  {/* Price display or edit mode */}
                  <div className="mt-4 p-3 bg-white rounded-xl border border-[#ded8cb]">
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-[#8B6F47]">Today's Benchmark:</span>
                      <span className="text-xs text-[#8B6F47]">{mandi.lastUpdated}</span>
                    </div>

                    {isEditing ? (
                      <div className="flex items-center gap-2 mt-2">
                        <input
                          type="number"
                          value={editPriceInput}
                          onChange={(e) => setEditPriceInput(e.target.value)}
                          className="w-full bg-[#F5F1E8] border border-[#ded8cb] rounded-xl px-2 py-1 text-sm font-bold text-[#2D2D2D] focus:outline-none"
                        />
                        <button
                          onClick={() => handleSavePrice(mandi.id)}
                          className="bg-[#4A7C59] text-white p-2 rounded-xl hover:bg-[#3d6749] cursor-pointer flex items-center justify-center"
                          title="Save price"
                        >
                          <Check size={24} />
                        </button>
                        <button
                          onClick={() => setEditingMandiId(null)}
                          className="bg-[#C0392B] text-white p-2 rounded-xl hover:bg-[#a02c20] cursor-pointer flex items-center justify-center"
                          title="Cancel"
                        >
                          <XCircle size={24} />
                        </button>
                      </div>
                    ) : (
                      <div className="flex items-center justify-between mt-2">
                        <span className="font-heading font-bold text-xl text-[#4A7C59]">
                          ₹{mandi.price} <span className="text-xs font-normal text-[#2D2D2D]">/qtl</span>
                        </span>
                        <button
                          onClick={() => handleStartEdit(mandi)}
                          className="text-xs text-[#8B6F47] hover:text-[#4A7C59] font-medium flex items-center gap-1.5 cursor-pointer bg-[#F5F1E8] px-2.5 py-1 rounded-xl border border-[#ded8cb]"
                        >
                          <Edit3 size={24} />
                          <span>Update</span>
                        </button>
                      </div>
                    )}
                  </div>

                  {/* 7-Day Trend Chart */}
                  <div className="mt-4">
                    <MiniPriceChart
                      history={mandi.priceHistory}
                      crop={mandi.crop}
                      currentPrice={mandi.price}
                    />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Grievance Redressal Desk */}
      <div className="bg-white rounded-xl shadow-md p-4 border border-[#e2dcd0]">
        <div className="flex items-center justify-between mb-4 pb-2 border-b border-[#F5F1E8]">
          <div className="flex items-center gap-2">
            <div className="text-[#D97706] flex items-center">
              <FileQuestion size={24} />
            </div>
            <div>
              <h3 className="font-heading font-semibold text-lg text-[#2D2D2D] m-0">
                Grievance & Dispute Resolution Desk
              </h3>
              <span className="text-xs text-[#8B6F47]">
                Official APMC tribunal adjudication for transaction disputes
              </span>
            </div>
          </div>
          <span className="text-xs text-[#8B6F47] bg-[#F5F1E8] px-2.5 py-1 rounded-xl font-medium">
            {grievances.length} Total Complaints
          </span>
        </div>

        <div className="space-y-3">
          {grievances.map((g) => {
            const txn = transactions.find((t) => t.id === g.transactionId);
            const offer = txn ? offers.find((o) => o.id === txn.offerId) : null;
            const lot = offer ? lots.find((l) => l.id === offer.lotId) : null;
            const farmer = lot ? farmers.find((f) => f.id === lot.farmerId) : null;
            const buyer = offer ? buyers.find((b) => b.id === offer.buyerId) : null;

            return (
              <div
                key={g.id}
                className="bg-[#F5F1E8] rounded-xl p-4 border border-[#ded8cb] flex flex-col md:flex-row md:items-center justify-between gap-4"
              >
                <div className="space-y-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-mono text-xs font-bold text-[#2D2D2D]">
                      Ticket #{g.id}
                    </span>
                    <span className="text-xs text-[#8B6F47]">
                      Linked to Transaction: <span className="font-mono">{g.transactionId}</span>
                    </span>
                    <span
                      className={`text-xs px-2.5 py-0.5 rounded-xl font-bold uppercase ${
                        g.status === "resolved"
                          ? "bg-[#4A7C59] text-white"
                          : g.status === "in_review"
                          ? "bg-[#D97706] text-white"
                          : "bg-[#8B6F47] text-white"
                      }`}
                    >
                      {g.status.replace("_", " ")}
                    </span>
                  </div>

                  <p className="text-xs font-medium text-[#2D2D2D] mt-1">
                    "{g.message}"
                  </p>

                  <div className="text-[11px] text-[#8B6F47] flex flex-wrap gap-2 pt-1">
                    <span>
                      Farmer: <strong className="text-[#2D2D2D]">{farmer?.name || "Farmer"}</strong>
                    </span>
                    <span>•</span>
                    <span>
                      Buyer: <strong className="text-[#2D2D2D]">{buyer?.name || "Buyer"}</strong>
                    </span>
                    <span>•</span>
                    <span>
                      Commodity: <strong className="text-[#2D2D2D]">{lot?.crop} ({lot?.quantity} Qtl)</strong>
                    </span>
                  </div>
                </div>

                {/* Status Update Buttons */}
                <div className="flex items-center gap-2 shrink-0">
                  {g.status !== "in_review" && g.status !== "resolved" && (
                    <button
                      onClick={() => updateGrievanceStatus(g.id, "in_review")}
                      className="bg-[#D97706] text-white text-xs font-semibold px-3 py-2 rounded-xl flex items-center gap-2 hover:bg-[#b86505] cursor-pointer"
                    >
                      <Clock size={24} />
                      <span>Start Review</span>
                    </button>
                  )}

                  {g.status !== "resolved" && (
                    <button
                      onClick={() => updateGrievanceStatus(g.id, "resolved")}
                      className="bg-[#4A7C59] text-white text-xs font-semibold px-3 py-2 rounded-xl flex items-center gap-2 hover:bg-[#3d6749] shadow-sm cursor-pointer"
                    >
                      <CheckCircle2 size={24} />
                      <span>Mark Resolved</span>
                    </button>
                  )}

                  {g.status === "resolved" && (
                    <span className="text-xs text-[#4A7C59] font-semibold bg-white border border-[#4A7C59] px-3 py-1.5 rounded-xl flex items-center gap-1.5">
                      <CheckCircle2 size={24} />
                      <span>Dispute Closed</span>
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
