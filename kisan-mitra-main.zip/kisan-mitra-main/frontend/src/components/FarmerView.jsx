import React, { useState } from "react";
import {
  PlusCircle,
  Package,
  Clock,
  Truck,
  CheckCircle2,
  XCircle,
  AlertCircle,
  ShieldCheck,
  Star,
  ArrowRight,
  FileQuestion,
  Info
} from "lucide-react";
import { useApp } from "../context/AppContext";

export default function FarmerView() {
  const {
    activeFarmerId,
    getFarmer,
    lots,
    offers,
    transactions,
    grievances,
    mandis,
    buyers,
    addLot,
    acceptOffer,
    rejectOffer,
    addGrievance
  } = useApp();

  const farmer = getFarmer(activeFarmerId) || { name: "Farmer", village: "Mandi Region", phone: "" };

  // Filter farmer specific items
  const farmerLots = lots.filter((l) => l.farmerId === activeFarmerId);
  const farmerLotIds = farmerLots.map((l) => l.id);

  // Incoming offers on this farmer's lots
  const incomingOffers = offers.filter((o) => farmerLotIds.includes(o.lotId));

  // Transactions on this farmer's offers
  const farmerTransactions = transactions.filter((t) => {
    const offer = offers.find((o) => o.id === t.offerId);
    return offer && farmerLotIds.includes(offer.lotId);
  });

  // Grievances for farmer's transactions
  const farmerTxnIds = farmerTransactions.map((t) => t.id);
  const farmerGrievances = grievances.filter((g) => farmerTxnIds.includes(g.transactionId));

  // Modal / Form state for listing new lot
  const [showAddLotModal, setShowAddLotModal] = useState(false);
  const [newCrop, setNewCrop] = useState("Wheat");
  const [newQuantity, setNewQuantity] = useState("");
  const [newGrade, setNewGrade] = useState("A");

  // Grievance form modal
  const [grievanceModalTxnId, setGrievanceModalTxnId] = useState(null);
  const [grievanceMessage, setGrievanceMessage] = useState("");

  const handleCreateLot = (e) => {
    e.preventDefault();
    if (!newQuantity || Number(newQuantity) <= 0) return;
    addLot({
      crop: newCrop,
      quantity: newQuantity,
      grade: newGrade,
      farmerId: activeFarmerId
    });
    setNewQuantity("");
    setShowAddLotModal(false);
  };

  const handleFileGrievance = (e) => {
    e.preventDefault();
    if (!grievanceMessage.trim()) return;
    addGrievance({
      transactionId: grievanceModalTxnId,
      message: grievanceMessage
    });
    setGrievanceMessage("");
    setGrievanceModalTxnId(null);
  };

  // Helper to find benchmark mandi price for a crop
  const getBenchmarkMandiPrice = (crop) => {
    const mandi = mandis.find((m) => m.crop.toLowerCase() === crop.toLowerCase());
    return mandi ? mandi.price : 2500;
  };

  return (
    <div className="space-y-6">
      {/* Header Profile & Summary */}
      <div className="bg-white rounded-xl shadow-md p-4 flex flex-col md:flex-row md:items-center justify-between gap-4 border border-[#e2dcd0]">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="font-heading font-bold text-2xl text-[#2D2D2D] m-0">
              {farmer.name}'s Produce Portal
            </h2>
            <span className="bg-[#4A7C59] text-white text-xs font-medium px-2.5 py-0.5 rounded-xl">
              Verified Farmer
            </span>
          </div>
          <p className="text-sm text-[#8B6F47] mt-1 font-sans">
            Village: <span className="font-medium text-[#2D2D2D]">{farmer.village}</span> | Phone:{" "}
            <span className="font-medium text-[#2D2D2D]">{farmer.phone}</span>
          </p>
        </div>

        <button
          onClick={() => setShowAddLotModal(true)}
          className="bg-[#4A7C59] text-white rounded-xl px-4 py-2.5 text-sm font-semibold flex items-center justify-center gap-2 shadow-md hover:bg-[#3d6749] transition-colors cursor-pointer"
        >
          <PlusCircle size={24} />
          <span>List New Produce Lot</span>
        </button>
      </div>

      {/* KPI Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl shadow-md p-4 border border-[#e2dcd0]">
          <div className="flex items-center justify-between">
            <span className="text-sm text-[#8B6F47] font-medium">Active Lots Listed</span>
            <div className="text-[#4A7C59]">
              <Package size={24} />
            </div>
          </div>
          <div className="font-heading font-bold text-2xl text-[#2D2D2D] mt-2">
            {farmerLots.length} Lots
          </div>
          <p className="text-xs text-[#8B6F47] mt-1">Available for buyer bids</p>
        </div>

        <div className="bg-white rounded-xl shadow-md p-4 border border-[#e2dcd0]">
          <div className="flex items-center justify-between">
            <span className="text-sm text-[#8B6F47] font-medium">Pending Buyer Offers</span>
            <div className="text-[#D97706]">
              <Clock size={24} />
            </div>
          </div>
          <div className="font-heading font-bold text-2xl text-[#2D2D2D] mt-2">
            {incomingOffers.filter((o) => o.status === "pending").length} Offers
          </div>
          <p className="text-xs text-[#8B6F47] mt-1">Requires your acceptance</p>
        </div>

        <div className="bg-white rounded-xl shadow-md p-4 border border-[#e2dcd0]">
          <div className="flex items-center justify-between">
            <span className="text-sm text-[#8B6F47] font-medium">In-Transit Shipments</span>
            <div className="text-[#8B6F47]">
              <Truck size={24} />
            </div>
          </div>
          <div className="font-heading font-bold text-2xl text-[#2D2D2D] mt-2">
            {farmerTransactions.filter((t) => t.logisticsStatus !== "delivered").length} Orders
          </div>
          <p className="text-xs text-[#8B6F47] mt-1">Escrow payment protected</p>
        </div>

        <div className="bg-white rounded-xl shadow-md p-4 border border-[#e2dcd0]">
          <div className="flex items-center justify-between">
            <span className="text-sm text-[#8B6F47] font-medium">Settled & Paid</span>
            <div className="text-[#4A7C59]">
              <CheckCircle2 size={24} />
            </div>
          </div>
          <div className="font-heading font-bold text-2xl text-[#2D2D2D] mt-2">
            {farmerLots.filter((l) => l.status === "paid").length} Deals
          </div>
          <p className="text-xs text-[#8B6F47] mt-1">Directly credited to farmer</p>
        </div>
      </div>

      {/* Incoming Offers Section */}
      <div className="bg-white rounded-xl shadow-md p-4 border border-[#e2dcd0]">
        <div className="flex items-center justify-between mb-4 pb-2 border-b border-[#F5F1E8]">
          <div className="flex items-center gap-2">
            <div className="text-[#D97706]">
              <Clock size={24} />
            </div>
            <h3 className="font-heading font-semibold text-lg text-[#2D2D2D] m-0">
              Incoming Buyer Bids & Offers
            </h3>
          </div>
          <span className="text-xs text-[#8B6F47] bg-[#F5F1E8] px-2.5 py-1 rounded-xl font-medium">
            {incomingOffers.length} Total Received
          </span>
        </div>

        {incomingOffers.length === 0 ? (
          <div className="text-center py-8 text-[#8B6F47] bg-[#F5F1E8] rounded-xl p-4">
            <Info size={24} className="mx-auto mb-2 text-[#8B6F47]" />
            <p className="font-medium text-sm">No offers received yet.</p>
            <p className="text-xs mt-1">Switch to the "Buyer" tab to submit offers on your produce lots.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {incomingOffers.map((offer) => {
              const lot = lots.find((l) => l.id === offer.lotId);
              const buyer = buyers.find((b) => b.id === offer.buyerId);
              const benchmark = lot ? getBenchmarkMandiPrice(lot.crop) : 2500;
              const isAboveMandi = offer.price >= benchmark;

              return (
                <div
                  key={offer.id}
                  className={`rounded-xl p-4 border ${
                    offer.status === "accepted"
                      ? "border-[#4A7C59] bg-[#F5F1E8]"
                      : offer.status === "rejected"
                      ? "border-[#ded8cb] bg-[#fcfaf7] opacity-60"
                      : "border-[#e2dcd0] bg-white shadow-sm"
                  }`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="font-heading font-bold text-base text-[#2D2D2D]">
                          {buyer ? buyer.name : "Agro Buyer"}
                        </span>
                        {buyer?.verified && (
                          <span title="Verified Buyer" className="text-[#4A7C59]">
                            <ShieldCheck size={24} />
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-2 text-xs text-[#8B6F47] mt-0.5">
                        <span>{buyer?.type}</span>
                        <span>•</span>
                        <span className="flex items-center gap-0.5 text-[#D97706] font-medium">
                          <Star size={24} className="fill-[#D97706]" />
                          {buyer?.rating} / 5.0
                        </span>
                      </div>
                    </div>

                    {/* Status Badge */}
                    <span
                      className={`text-xs px-2.5 py-1 rounded-xl font-semibold capitalize ${
                        offer.status === "accepted"
                          ? "bg-[#4A7C59] text-white"
                          : offer.status === "rejected"
                          ? "bg-[#C0392B] text-white"
                          : "bg-[#D97706] text-white"
                      }`}
                    >
                      {offer.status}
                    </span>
                  </div>

                  {/* Lot Details & Pricing */}
                  <div className="mt-3 p-3 bg-[#F5F1E8] rounded-xl flex items-center justify-between text-xs">
                    <div>
                      <span className="font-semibold text-[#2D2D2D] block">
                        Crop: {lot?.crop} (Grade {lot?.grade})
                      </span>
                      <span className="text-[#8B6F47]">
                        Quantity: {lot?.quantity} Quintals
                      </span>
                    </div>

                    <div className="text-right">
                      <span className="font-heading font-bold text-base text-[#2D2D2D] block">
                        ₹{offer.price} <span className="text-xs font-normal">/qtl</span>
                      </span>
                      <span
                        className={`text-[11px] font-medium ${
                          isAboveMandi ? "text-[#4A7C59]" : "text-[#D97706]"
                        }`}
                      >
                        {isAboveMandi ? "Above Mandi APMC" : "Slightly below APMC"} (₹{benchmark})
                      </span>
                    </div>
                  </div>

                  {/* Action Buttons */}
                  {offer.status === "pending" && (
                    <div className="flex items-center gap-2 mt-4">
                      <button
                        onClick={() => acceptOffer(offer.id)}
                        className="flex-1 bg-[#4A7C59] text-white rounded-xl py-2 px-3 text-xs font-semibold flex items-center justify-center gap-1.5 shadow-sm hover:bg-[#3d6749] transition-colors cursor-pointer"
                      >
                        <CheckCircle2 size={24} />
                        <span>Accept Offer</span>
                      </button>
                      <button
                        onClick={() => rejectOffer(offer.id)}
                        className="bg-white border border-[#C0392B] text-[#C0392B] rounded-xl py-2 px-3 text-xs font-semibold flex items-center justify-center gap-1.5 hover:bg-[#F5F1E8] transition-colors cursor-pointer"
                      >
                        <XCircle size={24} />
                        <span>Decline</span>
                      </button>
                    </div>
                  )}

                  {offer.status === "accepted" && (
                    <div className="mt-3 text-xs text-[#4A7C59] font-medium flex items-center gap-1">
                      <CheckCircle2 size={24} />
                      <span>Deal confirmed! Transaction created & payment moved to Escrow.</span>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Farmer's Produce Lots Section */}
      <div className="bg-white rounded-xl shadow-md p-4 border border-[#e2dcd0]">
        <div className="flex items-center justify-between mb-4 pb-2 border-b border-[#F5F1E8]">
          <div className="flex items-center gap-2">
            <div className="text-[#4A7C59]">
              <Package size={24} />
            </div>
            <h3 className="font-heading font-semibold text-lg text-[#2D2D2D] m-0">
              My Produce Lots ({farmerLots.length})
            </h3>
          </div>
          <span className="text-xs text-[#8B6F47]">
            Showing lots owned by {farmer.name}
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {farmerLots.map((lot) => {
            const benchmark = getBenchmarkMandiPrice(lot.crop);
            return (
              <div
                key={lot.id}
                className="bg-[#F5F1E8] rounded-xl p-4 border border-[#e2dcd0] flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between">
                    <span className="font-heading font-bold text-lg text-[#2D2D2D]">
                      {lot.crop}
                    </span>
                    <span
                      className={`text-xs px-2.5 py-1 rounded-xl font-bold uppercase ${
                        lot.grade === "A"
                          ? "bg-[#4A7C59] text-white"
                          : lot.grade === "B"
                          ? "bg-[#8B6F47] text-white"
                          : "bg-[#D97706] text-white"
                      }`}
                    >
                      Grade {lot.grade}
                    </span>
                  </div>

                  <div className="mt-3 space-y-1 text-xs text-[#2D2D2D]">
                    <div className="flex justify-between">
                      <span className="text-[#8B6F47]">Lot ID:</span>
                      <span className="font-mono font-medium">{lot.id}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-[#8B6F47]">Quantity:</span>
                      <span className="font-bold">{lot.quantity} Quintals</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-[#8B6F47]">Mandi Benchmark:</span>
                      <span className="font-semibold text-[#4A7C59]">₹{benchmark} /qtl</span>
                    </div>
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-[#ded8cb] flex items-center justify-between">
                  <span className="text-xs text-[#8B6F47]">Status:</span>
                  <span
                    className={`text-xs px-2.5 py-0.5 rounded-xl font-semibold capitalize ${
                      lot.status === "paid"
                        ? "bg-[#4A7C59] text-white"
                        : lot.status === "matched"
                        ? "bg-[#D97706] text-white"
                        : lot.status === "pickedup"
                        ? "bg-[#8B6F47] text-white"
                        : "bg-white text-[#2D2D2D] border border-[#ded8cb]"
                    }`}
                  >
                    {lot.status}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Active Transactions & Logistics Tracking */}
      <div className="bg-white rounded-xl shadow-md p-4 border border-[#e2dcd0]">
        <div className="flex items-center justify-between mb-4 pb-2 border-b border-[#F5F1E8]">
          <div className="flex items-center gap-2">
            <div className="text-[#8B6F47]">
              <Truck size={24} />
            </div>
            <h3 className="font-heading font-semibold text-lg text-[#2D2D2D] m-0">
              Orders, Logistics & Payment Escrow Tracking
            </h3>
          </div>
          <span className="text-xs text-[#8B6F47]">
            {farmerTransactions.length} Active Orders
          </span>
        </div>

        {farmerTransactions.length === 0 ? (
          <div className="text-center py-6 text-[#8B6F47] bg-[#F5F1E8] rounded-xl p-4">
            <p className="text-sm font-medium">No confirmed transactions currently.</p>
            <p className="text-xs mt-1">Accept an incoming offer above to initiate an escrow order.</p>
          </div>
        ) : (
          <div className="space-y-4">
            {farmerTransactions.map((txn) => {
              const offer = offers.find((o) => o.id === txn.offerId);
              const lot = offer ? lots.find((l) => l.id === offer.lotId) : null;
              const buyer = offer ? buyers.find((b) => b.id === offer.buyerId) : null;
              const totalAmount = offer && lot ? offer.price * lot.quantity : 0;

              return (
                <div
                  key={txn.id}
                  className="bg-[#F5F1E8] rounded-xl p-4 border border-[#e2dcd0] space-y-3"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div>
                      <span className="font-mono text-xs text-[#8B6F47] block">
                        Transaction Ref: {txn.id}
                      </span>
                      <h4 className="font-heading font-bold text-base text-[#2D2D2D] m-0">
                        {lot?.crop} ({lot?.quantity} Qtl) • Buyer: {buyer?.name}
                      </h4>
                    </div>

                    <div className="text-right">
                      <span className="font-heading font-bold text-lg text-[#4A7C59] block">
                        ₹{totalAmount.toLocaleString()}
                      </span>
                      <span className="text-xs text-[#8B6F47]">
                        ₹{offer?.price}/qtl in Escrow
                      </span>
                    </div>
                  </div>

                  {/* Status Badges & Flow */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-[#ded8cb]">
                    <div className="flex items-center gap-2">
                      <Truck size={24} className="text-[#8B6F47]" />
                      <div>
                        <span className="text-xs text-[#8B6F47] block">Logistics Status:</span>
                        <span className="text-xs font-semibold text-[#2D2D2D] capitalize">
                          {txn.logisticsStatus.replace("_", " ")}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <ShieldCheck size={24} className="text-[#4A7C59]" />
                      <div>
                        <span className="text-xs text-[#8B6F47] block">Payment Status:</span>
                        <span className="text-xs font-semibold text-[#4A7C59] capitalize">
                          {txn.paymentStatus.replace("_", " ")}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Grievance Action */}
                  <div className="pt-2 flex justify-end">
                    <button
                      onClick={() => setGrievanceModalTxnId(txn.id)}
                      className="text-xs font-semibold text-[#C0392B] bg-white border border-[#C0392B] px-3 py-1.5 rounded-xl hover:bg-[#fcf5f5] flex items-center gap-1.5 transition-colors cursor-pointer"
                    >
                      <FileQuestion size={24} />
                      <span>Report Issue / Grievance</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Grievance History */}
      {farmerGrievances.length > 0 && (
        <div className="bg-white rounded-xl shadow-md p-4 border border-[#e2dcd0]">
          <div className="flex items-center gap-2 mb-3 pb-2 border-b border-[#F5F1E8]">
            <AlertCircle size={24} className="text-[#D97706]" />
            <h3 className="font-heading font-semibold text-lg text-[#2D2D2D] m-0">
              Submitted Grievances & Resolution Desk
            </h3>
          </div>
          <div className="space-y-3">
            {farmerGrievances.map((g) => (
              <div
                key={g.id}
                className="bg-[#F5F1E8] rounded-xl p-3 border border-[#ded8cb] flex flex-col sm:flex-row sm:items-center justify-between gap-3"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs font-semibold text-[#8B6F47]">
                      {g.id} (Txn: {g.transactionId})
                    </span>
                    <span
                      className={`text-xs px-2 py-0.5 rounded-xl font-bold uppercase ${
                        g.status === "resolved"
                          ? "bg-[#4A7C59] text-white"
                          : g.status === "in_review"
                          ? "bg-[#D97706] text-white"
                          : "bg-[#8B6F47] text-white"
                      }`}
                    >
                      {g.status.replace("_", " ")}
                    </span>
                  </div>
                  <p className="text-xs text-[#2D2D2D] mt-1 font-medium">{g.message}</p>
                </div>
                <div className="text-xs text-[#8B6F47]">
                  Handled by Mandi APMC Inspector
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Modal: List New Produce Lot */}
      {showAddLotModal && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl shadow-md p-6 max-w-md w-full border border-[#ded8cb]">
            <div className="flex items-center justify-between pb-3 border-b border-[#F5F1E8]">
              <div className="flex items-center gap-2">
                <div className="text-[#4A7C59]">
                  <PlusCircle size={24} />
                </div>
                <h3 className="font-heading font-bold text-lg text-[#2D2D2D] m-0">
                  List New Produce Lot
                </h3>
              </div>
              <button
                onClick={() => setShowAddLotModal(false)}
                className="text-[#8B6F47] hover:text-[#2D2D2D] cursor-pointer"
              >
                <XCircle size={24} />
              </button>
            </div>

            <form onSubmit={handleCreateLot} className="space-y-4 mt-4 text-sm">
              <div>
                <label className="block text-xs font-semibold text-[#2D2D2D] mb-1">
                  Crop Commodity
                </label>
                <select
                  value={newCrop}
                  onChange={(e) => setNewCrop(e.target.value)}
                  className="w-full bg-[#F5F1E8] border border-[#ded8cb] rounded-xl px-3 py-2 text-[#2D2D2D] focus:outline-none focus:ring-1 focus:ring-[#4A7C59]"
                >
                  <option value="Wheat">Wheat (गेहूं)</option>
                  <option value="Soybean">Soybean (सोयाबीन)</option>
                  <option value="Mustard">Mustard (सरसों)</option>
                  <option value="Chana">Chana / Gram (चना)</option>
                  <option value="Onion">Onion (प्याज)</option>
                  <option value="Paddy">Paddy / Rice (धान)</option>
                  <option value="Cotton">Cotton (कपास)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#2D2D2D] mb-1">
                  Quantity (in Quintals)
                </label>
                <input
                  type="number"
                  min="1"
                  required
                  placeholder="e.g. 50"
                  value={newQuantity}
                  onChange={(e) => setNewQuantity(e.target.value)}
                  className="w-full bg-[#F5F1E8] border border-[#ded8cb] rounded-xl px-3 py-2 text-[#2D2D2D] focus:outline-none focus:ring-1 focus:ring-[#4A7C59]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#2D2D2D] mb-1">
                  Quality Grade
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {["A", "B", "C"].map((grade) => (
                    <button
                      type="button"
                      key={grade}
                      onClick={() => setNewGrade(grade)}
                      className={`py-2 text-xs font-bold rounded-xl border cursor-pointer transition-colors ${
                        newGrade === grade
                          ? "bg-[#4A7C59] text-white border-[#4A7C59]"
                          : "bg-[#F5F1E8] text-[#2D2D2D] border-[#ded8cb]"
                      }`}
                    >
                      Grade {grade}
                    </button>
                  ))}
                </div>
                <span className="text-[11px] text-[#8B6F47] mt-1 block">
                  Grade A: Premium moisture & purity (&gt;98%). Grade B: Standard fair. Grade C: Commercial.
                </span>
              </div>

              <div className="flex items-center gap-3 pt-4 border-t border-[#F5F1E8]">
                <button
                  type="button"
                  onClick={() => setShowAddLotModal(false)}
                  className="flex-1 bg-white border border-[#ded8cb] text-[#2D2D2D] rounded-xl py-2.5 text-xs font-semibold hover:bg-[#F5F1E8] cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-[#4A7C59] text-white rounded-xl py-2.5 text-xs font-semibold hover:bg-[#3d6749] shadow-md cursor-pointer"
                >
                  Publish Lot
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Report Grievance */}
      {grievanceModalTxnId && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl shadow-md p-6 max-w-md w-full border border-[#ded8cb]">
            <div className="flex items-center justify-between pb-3 border-b border-[#F5F1E8]">
              <div className="flex items-center gap-2">
                <div className="text-[#C0392B]">
                  <FileQuestion size={24} />
                </div>
                <h3 className="font-heading font-bold text-lg text-[#2D2D2D] m-0">
                  File Mandi Grievance
                </h3>
              </div>
              <button
                onClick={() => setGrievanceModalTxnId(null)}
                className="text-[#8B6F47] hover:text-[#2D2D2D] cursor-pointer"
              >
                <XCircle size={24} />
              </button>
            </div>

            <form onSubmit={handleFileGrievance} className="space-y-4 mt-4 text-sm">
              <div>
                <label className="block text-xs font-semibold text-[#8B6F47] mb-1">
                  Transaction ID
                </label>
                <input
                  type="text"
                  disabled
                  value={grievanceModalTxnId}
                  className="w-full bg-[#F5F1E8] border border-[#ded8cb] rounded-xl px-3 py-2 text-[#2D2D2D] font-mono text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#2D2D2D] mb-1">
                  Describe Dispute / Issue
                </label>
                <textarea
                  rows={4}
                  required
                  placeholder="Detail discrepancies in weighing, payment delays, or transport scheduling..."
                  value={grievanceMessage}
                  onChange={(e) => setGrievanceMessage(e.target.value)}
                  className="w-full bg-[#F5F1E8] border border-[#ded8cb] rounded-xl p-3 text-[#2D2D2D] focus:outline-none focus:ring-1 focus:ring-[#4A7C59] text-xs"
                />
              </div>

              <div className="flex items-center gap-3 pt-3 border-t border-[#F5F1E8]">
                <button
                  type="button"
                  onClick={() => setGrievanceModalTxnId(null)}
                  className="flex-1 bg-white border border-[#ded8cb] text-[#2D2D2D] rounded-xl py-2.5 text-xs font-semibold hover:bg-[#F5F1E8] cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-[#4A7C59] text-white rounded-xl py-2.5 text-xs font-semibold hover:bg-[#3d6749] shadow-md cursor-pointer"
                >
                  Submit to APMC
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
