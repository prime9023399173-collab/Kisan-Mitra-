import React, { useState } from "react";
import {
  ShoppingBag,
  Search,
  Truck,
  CheckCircle2,
  Clock,
  Send,
  Building2,
  MapPin,
  TrendingUp,
  XCircle,
  FileCheck,
  ShieldCheck,
  AlertTriangle
} from "lucide-react";
import { useApp } from "../context/AppContext";

export default function BuyerView() {
  const {
    activeBuyerId,
    getBuyer,
    lots,
    farmers,
    offers,
    transactions,
    mandis,
    makeOffer,
    updateTransaction
  } = useApp();

  const buyer = getBuyer(activeBuyerId) || {
    name: "Trader",
    type: "Wholesaler",
    verified: true,
    rating: 4.5,
    demand: { crop: "Wheat", quantity: 200 }
  };

  // Filter state for marketplace
  const [selectedCrop, setSelectedCrop] = useState("all");
  const [selectedGrade, setSelectedGrade] = useState("all");

  // Offer modal state
  const [offerModalLot, setOfferModalLot] = useState(null);
  const [offerPriceInput, setOfferPriceInput] = useState("");

  // Filtered market lots
  const availableLots = lots.filter((lot) => {
    if (selectedCrop !== "all" && lot.crop.toLowerCase() !== selectedCrop.toLowerCase()) {
      return false;
    }
    if (selectedGrade !== "all" && lot.grade !== selectedGrade) {
      return false;
    }
    return true;
  });

  // Buyer's submitted offers
  const myOffers = offers.filter((o) => o.buyerId === activeBuyerId);

  // Buyer's active transactions
  const myOfferIds = myOffers.map((o) => o.id);
  const myTransactions = transactions.filter((t) => myOfferIds.includes(t.offerId));

  const handleOpenOfferModal = (lot) => {
    setOfferModalLot(lot);
    const benchmark = getBenchmarkPrice(lot.crop);
    setOfferPriceInput(benchmark ? benchmark.toString() : "2500");
  };

  const handleSubmitOffer = (e) => {
    e.preventDefault();
    if (!offerPriceInput || Number(offerPriceInput) <= 0 || !offerModalLot) return;

    makeOffer({
      lotId: offerModalLot.id,
      buyerId: activeBuyerId,
      price: Number(offerPriceInput)
    });

    setOfferModalLot(null);
    setOfferPriceInput("");
  };

  const getBenchmarkPrice = (crop) => {
    const mandi = mandis.find((m) => m.crop.toLowerCase() === crop.toLowerCase());
    return mandi ? mandi.price : 2500;
  };

  return (
    <div className="space-y-6">
      {/* Header Profile & Procurement Demand */}
      <div className="bg-white rounded-xl shadow-md p-4 flex flex-col md:flex-row md:items-center justify-between gap-4 border border-[#e2dcd0]">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="font-heading font-bold text-2xl text-[#2D2D2D] m-0">
              {buyer.name}
            </h2>
            {buyer.verified && (
              <span className="bg-[#4A7C59] text-white text-xs font-semibold px-2.5 py-1 rounded-xl flex items-center gap-1.5">
                <ShieldCheck size={24} />
                <span>Verified Buyer</span>
              </span>
            )}
          </div>
          <p className="text-sm text-[#8B6F47] mt-1">
            Category: <span className="font-medium text-[#2D2D2D]">{buyer.type}</span> | Rating:{" "}
            <span className="font-medium text-[#2D2D2D]">{buyer.rating} / 5.0</span>
          </p>
        </div>

        {/* Current Sourcing Demand Pill */}
        <div className="bg-[#F5F1E8] border border-[#ded8cb] rounded-xl p-3 flex items-center gap-3">
          <div className="text-[#8B6F47] flex items-center">
            <ShoppingBag size={24} />
          </div>
          <div className="text-xs">
            <span className="text-[#8B6F47] block font-medium">Active Procurement Target:</span>
            <span className="font-heading font-bold text-sm text-[#2D2D2D]">
              {buyer.demand?.quantity} Quintals of {buyer.demand?.crop}
            </span>
          </div>
        </div>
      </div>

      {/* KPI Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl shadow-md p-4 border border-[#e2dcd0]">
          <div className="flex items-center justify-between">
            <span className="text-sm text-[#8B6F47] font-medium">Market Lots</span>
            <div className="text-[#4A7C59] flex items-center">
              <Search size={24} />
            </div>
          </div>
          <div className="font-heading font-bold text-2xl text-[#2D2D2D] mt-2">
            {lots.filter((l) => l.status === "listed").length} Available
          </div>
          <p className="text-xs text-[#8B6F47] mt-1">Ready for immediate bidding</p>
        </div>

        <div className="bg-white rounded-xl shadow-md p-4 border border-[#e2dcd0]">
          <div className="flex items-center justify-between">
            <span className="text-sm text-[#8B6F47] font-medium">My Placed Bids</span>
            <div className="text-[#D97706] flex items-center">
              <Clock size={24} />
            </div>
          </div>
          <div className="font-heading font-bold text-2xl text-[#2D2D2D] mt-2">
            {myOffers.length} Offers
          </div>
          <p className="text-xs text-[#8B6F47] mt-1">
            {myOffers.filter((o) => o.status === "pending").length} pending farmer review
          </p>
        </div>

        <div className="bg-white rounded-xl shadow-md p-4 border border-[#e2dcd0]">
          <div className="flex items-center justify-between">
            <span className="text-sm text-[#8B6F47] font-medium">Active Contracts</span>
            <div className="text-[#8B6F47] flex items-center">
              <Truck size={24} />
            </div>
          </div>
          <div className="font-heading font-bold text-2xl text-[#2D2D2D] mt-2">
            {myTransactions.length} Orders
          </div>
          <p className="text-xs text-[#8B6F47] mt-1">In-transit & logistics tracking</p>
        </div>

        <div className="bg-white rounded-xl shadow-md p-4 border border-[#e2dcd0]">
          <div className="flex items-center justify-between">
            <span className="text-sm text-[#8B6F47] font-medium">Settled Procurements</span>
            <div className="text-[#4A7C59] flex items-center">
              <CheckCircle2 size={24} />
            </div>
          </div>
          <div className="font-heading font-bold text-2xl text-[#2D2D2D] mt-2">
            {myTransactions.filter((t) => t.paymentStatus === "paid").length} Completed
          </div>
          <p className="text-xs text-[#8B6F47] mt-1">Payment released to farmers</p>
        </div>
      </div>

      {/* Marketplace: Browse Farmer Lots */}
      <div className="bg-white rounded-xl shadow-md p-4 border border-[#e2dcd0]">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4 pb-3 border-b border-[#F5F1E8]">
          <div className="flex items-center gap-2">
            <div className="text-[#4A7C59] flex items-center">
              <ShoppingBag size={24} />
            </div>
            <div>
              <h3 className="font-heading font-semibold text-lg text-[#2D2D2D] m-0">
                Farmer Produce Marketplace
              </h3>
              <span className="text-xs text-[#8B6F47]">
                Verified lot listings directly from local farmers
              </span>
            </div>
          </div>

          {/* Filters */}
          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-1.5 text-xs text-[#2D2D2D]">
              <span className="font-medium text-[#8B6F47]">Crop:</span>
              <select
                value={selectedCrop}
                onChange={(e) => setSelectedCrop(e.target.value)}
                className="bg-[#F5F1E8] border border-[#ded8cb] rounded-xl px-2.5 py-1 text-xs text-[#2D2D2D] focus:outline-none"
              >
                <option value="all">All Crops</option>
                <option value="Wheat">Wheat</option>
                <option value="Soybean">Soybean</option>
                <option value="Mustard">Mustard</option>
                <option value="Chana">Chana</option>
              </select>
            </div>

            <div className="flex items-center gap-1.5 text-xs text-[#2D2D2D]">
              <span className="font-medium text-[#8B6F47]">Grade:</span>
              <select
                value={selectedGrade}
                onChange={(e) => setSelectedGrade(e.target.value)}
                className="bg-[#F5F1E8] border border-[#ded8cb] rounded-xl px-2.5 py-1 text-xs text-[#2D2D2D] focus:outline-none"
              >
                <option value="all">All Grades</option>
                <option value="A">Grade A (Premium)</option>
                <option value="B">Grade B (Standard)</option>
                <option value="C">Grade C (Commercial)</option>
              </select>
            </div>
          </div>
        </div>

        {/* Lots Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {availableLots.map((lot) => {
            const farmer = farmers.find((f) => f.id === lot.farmerId);
            const benchmark = getBenchmarkPrice(lot.crop);
            const isListed = lot.status === "listed";
            const existingOffer = myOffers.find((o) => o.lotId === lot.id);

            return (
              <div
                key={lot.id}
                className="bg-[#F5F1E8] rounded-xl p-4 border border-[#e2dcd0] flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="font-heading font-bold text-lg text-[#2D2D2D] block">
                        {lot.crop}
                      </span>
                      <span className="text-xs text-[#8B6F47] font-mono">Lot #{lot.id}</span>
                    </div>
                    <span
                      className={`text-xs px-2.5 py-1 rounded-xl font-bold uppercase ${
                        lot.grade === "A"
                          ? "bg-[#4A7C59] text-white"
                          : lot.grade === "B"
                          ? "bg-[#8B6F47] text-white"
                          : "bg-[#D97706] text-white"
                      }`}
                    >
                      Grade {lot.grade}
                    </span>
                  </div>

                  <div className="mt-3 space-y-1.5 text-xs text-[#2D2D2D]">
                    <div className="flex items-center justify-between">
                      <span className="text-[#8B6F47]">Quantity:</span>
                      <span className="font-bold text-sm text-[#2D2D2D]">
                        {lot.quantity} Quintals
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-[#8B6F47]">Farmer:</span>
                      <span className="font-medium text-[#2D2D2D]">
                        {farmer ? farmer.name : "Local Producer"}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-[#8B6F47]">Location:</span>
                      <span className="text-[#2D2D2D] truncate max-w-[160px]">
                        {farmer ? farmer.village : "Mandi Region"}
                      </span>
                    </div>
                    <div className="flex items-center justify-between pt-1 border-t border-[#ded8cb]">
                      <span className="text-[#8B6F47]">APMC Mandi Rate:</span>
                      <span className="font-semibold text-[#4A7C59]">
                        ₹{benchmark} /qtl
                      </span>
                    </div>
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-[#ded8cb]">
                  {isListed ? (
                    existingOffer ? (
                      <div className="text-xs bg-white border border-[#ded8cb] p-2.5 rounded-xl flex items-center justify-between">
                        <span className="text-[#8B6F47]">Your Offer: ₹{existingOffer.price}/qtl</span>
                        <span
                          className={`font-semibold capitalize px-2 py-0.5 rounded-xl text-[11px] ${
                            existingOffer.status === "accepted"
                              ? "bg-[#4A7C59] text-white"
                              : existingOffer.status === "rejected"
                              ? "bg-[#C0392B] text-white"
                              : "bg-[#D97706] text-white"
                          }`}
                        >
                          {existingOffer.status}
                        </span>
                      </div>
                    ) : (
                      <button
                        onClick={() => handleOpenOfferModal(lot)}
                        className="w-full bg-[#4A7C59] text-white rounded-xl py-2 px-3 text-xs font-semibold flex items-center justify-center gap-2 shadow-sm hover:bg-[#3d6749] transition-colors cursor-pointer"
                      >
                        <Send size={24} />
                        <span>Place Price Offer</span>
                      </button>
                    )
                  ) : (
                    <div className="flex items-center justify-between text-xs text-[#8B6F47] bg-[#e8e2d5] p-2 rounded-xl">
                      <span>Listing Closed</span>
                      <span className="font-semibold capitalize text-[#2D2D2D]">{lot.status}</span>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Active Buyer Orders & Logistics Management */}
      <div className="bg-white rounded-xl shadow-md p-4 border border-[#e2dcd0]">
        <div className="flex items-center justify-between mb-4 pb-2 border-b border-[#F5F1E8]">
          <div className="flex items-center gap-2">
            <div className="text-[#8B6F47] flex items-center">
              <Truck size={24} />
            </div>
            <h3 className="font-heading font-semibold text-lg text-[#2D2D2D] m-0">
              Procurement Orders & Logistics Management
            </h3>
          </div>
          <span className="text-xs text-[#8B6F47]">
            {myTransactions.length} Orders
          </span>
        </div>

        {myTransactions.length === 0 ? (
          <div className="text-center py-6 text-[#8B6F47] bg-[#F5F1E8] rounded-xl p-4">
            <p className="text-sm font-medium">No confirmed orders currently.</p>
            <p className="text-xs mt-1">
              When a farmer accepts your offer, the escrow order and logistics milestones will appear here.
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {myTransactions.map((txn) => {
              const offer = offers.find((o) => o.id === txn.offerId);
              const lot = offer ? lots.find((l) => l.id === offer.lotId) : null;
              const farmer = lot ? farmers.find((f) => f.id === lot.farmerId) : null;
              const totalAmount = offer && lot ? offer.price * lot.quantity : 0;

              return (
                <div
                  key={txn.id}
                  className="bg-[#F5F1E8] rounded-xl p-4 border border-[#e2dcd0] space-y-3"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div>
                      <span className="font-mono text-xs text-[#8B6F47]">
                        Order Ref: {txn.id}
                      </span>
                      <h4 className="font-heading font-bold text-base text-[#2D2D2D] m-0">
                        {lot?.crop} ({lot?.quantity} Qtl) from {farmer?.name} ({farmer?.village})
                      </h4>
                    </div>

                    <div className="text-right">
                      <span className="font-heading font-bold text-lg text-[#4A7C59] block">
                        ₹{totalAmount.toLocaleString()}
                      </span>
                      <span className="text-xs text-[#8B6F47]">
                        Agreed Rate: ₹{offer?.price}/qtl
                      </span>
                    </div>
                  </div>

                  {/* Status Badges */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-[#ded8cb] text-xs">
                    <div>
                      <span className="text-[#8B6F47] block">Logistics Status:</span>
                      <span className="font-semibold text-[#2D2D2D] capitalize">
                        {txn.logisticsStatus.replace("_", " ")}
                      </span>
                    </div>
                    <div>
                      <span className="text-[#8B6F47] block">Escrow Payment Status:</span>
                      <span className="font-semibold text-[#4A7C59] capitalize">
                        {txn.paymentStatus.replace("_", " ")}
                      </span>
                    </div>
                  </div>

                  {/* Buyer Logistics Actions */}
                  <div className="pt-2 border-t border-[#ded8cb] flex flex-wrap items-center justify-end gap-2">
                    {txn.logisticsStatus === "pickup_scheduled" && (
                      <button
                        onClick={() =>
                          updateTransaction(txn.id, {
                            logisticsStatus: "in_transit"
                          })
                        }
                        className="bg-[#8B6F47] text-white rounded-xl py-2 px-3 text-xs font-semibold flex items-center gap-2 hover:bg-[#755d3b] cursor-pointer"
                      >
                        <Truck size={24} />
                        <span>Confirm Pickup & Dispatch</span>
                      </button>
                    )}

                    {txn.logisticsStatus === "in_transit" && (
                      <button
                        onClick={() =>
                          updateTransaction(txn.id, {
                            logisticsStatus: "delivered"
                          })
                        }
                        className="bg-[#4A7C59] text-white rounded-xl py-2 px-3 text-xs font-semibold flex items-center gap-2 hover:bg-[#3d6749] cursor-pointer"
                      >
                        <CheckCircle2 size={24} />
                        <span>Confirm Warehouse Delivery</span>
                      </button>
                    )}

                    {txn.logisticsStatus === "delivered" && txn.paymentStatus !== "paid" && (
                      <button
                        onClick={() =>
                          updateTransaction(txn.id, {
                            paymentStatus: "paid"
                          })
                        }
                        className="bg-[#4A7C59] text-white rounded-xl py-2 px-3 text-xs font-semibold flex items-center gap-2 hover:bg-[#3d6749] shadow-md cursor-pointer"
                      >
                        <FileCheck size={24} />
                        <span>Release Escrow Payment to Farmer</span>
                      </button>
                    )}

                    {txn.paymentStatus === "paid" && (
                      <span className="text-xs text-[#4A7C59] font-bold flex items-center gap-1.5 bg-white px-3 py-1.5 rounded-xl border border-[#4A7C59]">
                        <CheckCircle2 size={24} />
                        <span>Full Settlement Completed</span>
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Modal: Place Offer */}
      {offerModalLot && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl shadow-md p-6 max-w-md w-full border border-[#ded8cb]">
            <div className="flex items-center justify-between pb-3 border-b border-[#F5F1E8]">
              <div className="flex items-center gap-2">
                <div className="text-[#4A7C59] flex items-center">
                  <Send size={24} />
                </div>
                <h3 className="font-heading font-bold text-lg text-[#2D2D2D] m-0">
                  Submit Price Offer
                </h3>
              </div>
              <button
                onClick={() => setOfferModalLot(null)}
                className="text-[#8B6F47] hover:text-[#2D2D2D] cursor-pointer"
              >
                <XCircle size={24} />
              </button>
            </div>

            <form onSubmit={handleSubmitOffer} className="space-y-4 mt-4 text-sm">
              <div className="bg-[#F5F1E8] p-3 rounded-xl border border-[#ded8cb] text-xs space-y-1">
                <div className="flex justify-between">
                  <span className="text-[#8B6F47]">Lot:</span>
                  <span className="font-bold text-[#2D2D2D]">
                    {offerModalLot.crop} (Grade {offerModalLot.grade})
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#8B6F47]">Quantity:</span>
                  <span className="font-bold text-[#2D2D2D]">
                    {offerModalLot.quantity} Quintals
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#8B6F47]">Current Mandi Benchmark:</span>
                  <span className="font-semibold text-[#4A7C59]">
                    ₹{getBenchmarkPrice(offerModalLot.crop)} /qtl
                  </span>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#2D2D2D] mb-1">
                  Your Bid Price (₹ per Quintal)
                </label>
                <input
                  type="number"
                  required
                  min="100"
                  step="10"
                  value={offerPriceInput}
                  onChange={(e) => setOfferPriceInput(e.target.value)}
                  className="w-full bg-[#F5F1E8] border border-[#ded8cb] rounded-xl px-3 py-2 text-[#2D2D2D] font-bold text-base focus:outline-none focus:ring-1 focus:ring-[#4A7C59]"
                />
              </div>

              <div className="bg-[#fcfaf7] p-2.5 rounded-xl border border-[#ded8cb] text-xs flex justify-between">
                <span className="text-[#8B6F47]">Estimated Total Value:</span>
                <span className="font-heading font-bold text-[#2D2D2D]">
                  ₹{((Number(offerPriceInput) || 0) * offerModalLot.quantity).toLocaleString()}
                </span>
              </div>

              <div className="flex items-center gap-3 pt-3 border-t border-[#F5F1E8]">
                <button
                  type="button"
                  onClick={() => setOfferModalLot(null)}
                  className="flex-1 bg-white border border-[#ded8cb] text-[#2D2D2D] rounded-xl py-2.5 text-xs font-semibold hover:bg-[#F5F1E8] cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-[#4A7C59] text-white rounded-xl py-2.5 text-xs font-semibold hover:bg-[#3d6749] shadow-md cursor-pointer"
                >
                  Confirm & Send Bid
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
