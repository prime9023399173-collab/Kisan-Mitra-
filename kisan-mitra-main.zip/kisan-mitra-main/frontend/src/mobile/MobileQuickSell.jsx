import React, { useState } from "react";
import {
  Wheat,
  Sprout,
  Flower2,
  Sparkles,
  Apple,
  Layers,
  ChevronRight,
  ChevronLeft,
  CheckCircle2,
  XCircle,
  Check
} from "lucide-react";
import { useApp } from "../context/AppContext";

export default function MobileQuickSell({ onClose, onSuccess }) {
  const { activeFarmerId, addLot, t } = useApp();

  const [step, setStep] = useState(1);
  const [crop, setCrop] = useState("Wheat");
  const [quantity, setQuantity] = useState(50);
  const [grade, setGrade] = useState("A");

  const cropOptions = [
    { name: "Wheat", hindi: "गेहूं", icon: Wheat },
    { name: "Soybean", hindi: "सोयाबीन", icon: Sprout },
    { name: "Mustard", hindi: "सरसों", icon: Flower2 },
    { name: "Chana", hindi: "चना", icon: Sparkles },
    { name: "Onion", hindi: "प्याज", icon: Apple },
    { name: "Cotton", hindi: "कपास", icon: Layers }
  ];

  const handleSubmit = () => {
    if (!quantity || Number(quantity) <= 0) return;
    addLot({
      crop,
      quantity: Number(quantity),
      grade,
      farmerId: activeFarmerId
    });
    if (onSuccess) onSuccess();
    if (onClose) onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-end sm:items-center justify-center z-50 p-0 sm:p-4">
      <div className="bg-white rounded-t-2xl sm:rounded-xl shadow-md p-4 w-full max-w-md border border-[#ded8cb] space-y-4 max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-2 border-b border-[#F5F1E8]">
          <div>
            <h3 className="font-heading font-bold text-base text-[#2D2D2D] m-0">
              {t.createLotBtn}
            </h3>
            <span className="text-[11px] text-[#8B6F47]">Step {step} of 3</span>
          </div>
          {onClose && (
            <button onClick={onClose} className="text-[#8B6F47] hover:text-[#2D2D2D] cursor-pointer">
              <XCircle size={24} />
            </button>
          )}
        </div>

        {/* Step 1: Crop */}
        {step === 1 && (
          <div className="space-y-3">
            <span className="text-xs font-bold text-[#2D2D2D] block">
              1. Choose Produce Commodity:
            </span>
            <div className="grid grid-cols-2 gap-2">
              {cropOptions.map((c) => {
                const IconComponent = c.icon;
                const isSelected = crop === c.name;
                return (
                  <button
                    key={c.name}
                    type="button"
                    onClick={() => setCrop(c.name)}
                    className={`p-3 rounded-xl border flex items-center gap-2 cursor-pointer transition-colors ${
                      isSelected
                        ? "bg-[#4A7C59] text-white border-[#4A7C59] shadow-sm"
                        : "bg-[#F5F1E8] text-[#2D2D2D] border-[#ded8cb]"
                    }`}
                  >
                    <IconComponent size={24} />
                    <div className="text-left">
                      <span className="text-xs font-bold block">{c.name}</span>
                      <span className={`text-[10px] ${isSelected ? "text-white/80" : "text-[#8B6F47]"}`}>
                        {c.hindi}
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>
            <button
              onClick={() => setStep(2)}
              className="w-full bg-[#4A7C59] text-white py-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 shadow-sm mt-2"
            >
              <span>{t.nextStep}</span>
              <ChevronRight size={24} />
            </button>
          </div>
        )}

        {/* Step 2: Quantity */}
        {step === 2 && (
          <div className="space-y-3">
            <span className="text-xs font-bold text-[#2D2D2D] block">
              2. Quantity in Quintals:
            </span>
            <div className="grid grid-cols-4 gap-2">
              {[25, 50, 100, 200].map((qty) => (
                <button
                  key={qty}
                  type="button"
                  onClick={() => setQuantity(qty)}
                  className={`py-3 rounded-xl font-heading font-bold text-xs border ${
                    quantity === qty
                      ? "bg-[#4A7C59] text-white border-[#4A7C59]"
                      : "bg-[#F5F1E8] text-[#2D2D2D] border-[#ded8cb]"
                  }`}
                >
                  {qty} Qtl
                </button>
              ))}
            </div>

            <div>
              <label className="text-[11px] text-[#8B6F47] font-semibold block mb-1">
                Custom Quintals:
              </label>
              <input
                type="number"
                min="1"
                value={quantity}
                onChange={(e) => setQuantity(e.target.value)}
                className="w-full bg-[#F5F1E8] border border-[#ded8cb] rounded-xl px-3 py-2 text-base font-bold text-[#2D2D2D]"
              />
            </div>

            <div className="flex gap-2 pt-2">
              <button
                onClick={() => setStep(1)}
                className="flex-1 bg-white border border-[#ded8cb] text-[#2D2D2D] py-2 rounded-xl text-xs font-semibold"
              >
                Back
              </button>
              <button
                onClick={() => setStep(3)}
                className="flex-1 bg-[#4A7C59] text-white py-2 rounded-xl text-xs font-bold"
              >
                Next Step
              </button>
            </div>
          </div>
        )}

        {/* Step 3: Grade */}
        {step === 3 && (
          <div className="space-y-3">
            <span className="text-xs font-bold text-[#2D2D2D] block">
              3. Quality Grade:
            </span>
            <div className="space-y-2">
              {[
                { g: "A", title: "Grade A", desc: "Moisture <10%, Purity >98% (Premium)" },
                { g: "B", title: "Grade B", desc: "Standard fair average quality" },
                { g: "C", title: "Grade C", desc: "Commercial processing grade" }
              ].map((item) => (
                <button
                  key={item.g}
                  type="button"
                  onClick={() => setGrade(item.g)}
                  className={`w-full p-3 rounded-xl border text-left flex items-center justify-between ${
                    grade === item.g
                      ? "bg-[#4A7C59] text-white border-[#4A7C59] shadow-sm"
                      : "bg-[#F5F1E8] text-[#2D2D2D] border-[#ded8cb]"
                  }`}
                >
                  <div>
                    <span className="font-heading font-bold text-xs block">{item.title}</span>
                    <span className="text-[11px] opacity-80">{item.desc}</span>
                  </div>
                  {grade === item.g && (
                    <div className="w-5 h-5 rounded-full bg-white text-[#4A7C59] flex items-center justify-center">
                      <Check size={24} className="w-3.5 h-3.5" />
                    </div>
                  )}
                </button>
              ))}
            </div>

            <div className="flex gap-2 pt-2">
              <button
                onClick={() => setStep(2)}
                className="flex-1 bg-white border border-[#ded8cb] text-[#2D2D2D] py-2 rounded-xl text-xs font-semibold"
              >
                Back
              </button>
              <button
                onClick={handleSubmit}
                className="flex-1 bg-[#4A7C59] text-white py-2 rounded-xl text-xs font-bold shadow-md"
              >
                Publish Lot
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
