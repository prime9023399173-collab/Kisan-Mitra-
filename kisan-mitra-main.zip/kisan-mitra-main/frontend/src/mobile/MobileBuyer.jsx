import React, { useState } from "react";
import {
  ShoppingBag,
  ShieldCheck,
  Star,
  Layers,
  Send,
  PlusCircle,
  XCircle,
  Truck
} from "lucide-react";
import { useApp } from "../context/AppContext";

export default function MobileBuyer() {
  const {
    activeBuyerId,
    getBuyer,
    lots,
    farmers,
    mandis,
    makeOffer,
    updateBuyerDemand,
    t
  } = useApp();

  const buyer = getBuyer(activeBuyerId) || {
    name: "AgroHarvest Agri-Ventures",
    type: "Institutional Buyer",
    verified: true,
    rating: 4.8,
    demand: { crop: "Wheat", quantity: 500 }
  };

  const [showDemandModal, setShowDemandModal] = useState(false);
  const [demandCrop, setDemandCrop] = useState("Wheat");
  const [demandQty, setDemandQty] = useState(300);

  const [offerLot, setOfferLot] = useState(null);
  const [offerPrice, setOfferPrice] = useState("2500");

  const listedLots = lots.filter((l) => l.status === "listed");

  // Aggregated Batches Map
  const lotBatchesMap = {};
  listedLots.forEach((lot) => {
    const key = `${lot.crop}_${lot.grade}`;
    if (!lotBatchesMap[key]) {
      lotBatchesMap[key] = {
        crop: lot.crop,
        grade: lot.grade,
        lots: [],
        totalQuantity: 0
      };
    }
    lotBatchesMap[key].lots.push(lot);
    lotBatchesMap[key].totalQuantity += lot.quantity;
  });
  const batches = Object.values(lotBatchesMap);

  const handleSaveDemand = (e) => {
    e.preventDefault();
    updateBuyerDemand(activeBuyerId, {
      crop: demandCrop,
      quantity: Number(demandQty)
    });
    setShowDemandModal(false);
  };

  const handleSendOffer = (e) => {
    e.preventDefault();
    if (!offerLot || !offerPrice) return;
    makeOffer({
      lotId: offerLot.id,
      buyerId: activeBuyerId,
      price: Number(offerPrice)
    });
    setOfferLot(null);
  };

  return (
    <div className="space-y-4 pb-20">
      {/* Profile Card */}
      <div className="bg-white rounded-xl shadow-md p-4 border border-[#e2dcd0] space-y-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <h2 className="font-heading font-bold text-base text-[#2D2D2D] m-0">
              {buyer.name}
            </h2>
            {buyer.verified && (
              <span className="text-[#4A7C59]">
                <ShieldCheck size={24} />
              </span>
            )}
          </div>
          <div className="flex items-center gap-1 text-xs text-[#D97706] font-bold">
            <Star size={24} className="fill-[#D97706] w-4 h-4" />
            <span>{buyer.rating} / 5.0</span>
          </div>
        </div>

        <div className="bg-[#F5F1E8] p-2.5 rounded-xl border border-[#ded8cb] flex items-center justify-between text-xs">
          <div>
            <span className="text-[#8B6F47] block text-[11px]">Sourcing Target:</span>
            <strong className="text-[#2D2D2D]">
              {buyer.demand?.quantity} Qtl {buyer.demand?.crop}
            </strong>
          </div>
          <button
            onClick={() => setShowDemandModal(true)}
            className="bg-[#4A7C59] text-white px-2.5 py-1 rounded-xl font-bold text-[11px]"
          >
            Update Demand
          </button>
        </div>
      </div>

      {/* Aggregated Batches */}
      <div className="bg-white rounded-xl shadow-md p-4 border border-[#e2dcd0] space-y-3">
        <div className="flex items-center gap-1.5">
          <Layers size={24} className="text-[#8B6F47]" />
          <span className="font-heading font-bold text-sm text-[#2D2D2D]">
            Aggregated Regional Batches
          </span>
        </div>

        <div className="space-y-2">
          {batches.map((b, idx) => (
            <div key={idx} className="bg-[#F5F1E8] p-3 rounded-xl border border-[#ded8cb] flex items-center justify-between">
              <div>
                <span className="font-heading font-bold text-xs text-[#2D2D2D] block">
                  {b.crop} (Grade {b.grade})
                </span>
                <span className="text-[11px] text-[#8B6F47]">
                  {b.totalQuantity} Qtl across {b.lots.length} lots
                </span>
              </div>
              <button
                onClick={() => {
                  setOfferLot(b.lots[0]);
                  setOfferPrice("2500");
                }}
                className="bg-[#8B6F47] text-white px-3 py-1.5 rounded-xl text-xs font-bold hover:bg-[#755d3b]"
              >
                Bid Batch
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Browse Available Lots */}
      <div className="bg-white rounded-xl shadow-md p-4 border border-[#e2dcd0] space-y-3">
        <span className="font-heading font-bold text-sm text-[#2D2D2D] block">
          Available Produce Lots ({listedLots.length})
        </span>

        <div className="space-y-2.5">
          {listedLots.map((lot) => {
            const farmer = farmers.find((f) => f.id === lot.farmerId);
            return (
              <div key={lot.id} className="bg-[#F5F1E8] p-3 rounded-xl border border-[#ded8cb] flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-heading font-bold text-xs text-[#2D2D2D]">
                      {lot.crop} ({lot.quantity} Qtl)
                    </span>
                    <span className="bg-white text-[#2D2D2D] text-[10px] font-bold px-1.5 py-0.5 rounded-xl border border-[#ded8cb]">
                      Grade {lot.grade}
                    </span>
                  </div>
                  <span className="text-[11px] text-[#8B6F47] block mt-0.5">
                    {farmer?.name} ({farmer?.village.split(",")[0]})
                  </span>
                </div>

                <button
                  onClick={() => {
                    setOfferLot(lot);
                    setOfferPrice("2500");
                  }}
                  className="bg-[#4A7C59] text-white px-3 py-1.5 rounded-xl text-xs font-bold hover:bg-[#3d6749]"
                >
                  Place Offer
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* Modal: Post Demand */}
      {showDemandModal && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl shadow-md p-4 max-w-sm w-full border border-[#ded8cb] space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-heading font-bold text-sm text-[#2D2D2D]">
                Update Sourcing Target
              </span>
              <button onClick={() => setShowDemandModal(false)} className="text-[#8B6F47]">
                <XCircle size={24} />
              </button>
            </div>
            <form onSubmit={handleSaveDemand} className="space-y-3">
              <div>
                <label className="text-xs font-semibold block text-[#2D2D2D] mb-1">Crop</label>
                <select
                  value={demandCrop}
                  onChange={(e) => setDemandCrop(e.target.value)}
                  className="w-full bg-[#F5F1E8] border border-[#ded8cb] rounded-xl p-2 text-xs"
                >
                  <option value="Wheat">Wheat</option>
                  <option value="Soybean">Soybean</option>
                  <option value="Mustard">Mustard</option>
                  <option value="Chana">Chana</option>
                </select>
              </div>
              <div>
                <label className="text-xs font-semibold block text-[#2D2D2D] mb-1">Target Quantity (Qtl)</label>
                <input
                  type="number"
                  min="10"
                  value={demandQty}
                  onChange={(e) => setDemandQty(e.target.value)}
                  className="w-full bg-[#F5F1E8] border border-[#ded8cb] rounded-xl p-2 text-xs"
                />
              </div>
              <button
                type="submit"
                className="w-full bg-[#4A7C59] text-white py-2 rounded-xl text-xs font-bold"
              >
                Save Target
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Place Offer */}
      {offerLot && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl shadow-md p-4 max-w-sm w-full border border-[#ded8cb] space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-heading font-bold text-sm text-[#2D2D2D]">
                Offer on Lot #{offerLot.id}
              </span>
              <button onClick={() => setOfferLot(null)} className="text-[#8B6F47]">
                <XCircle size={24} />
              </button>
            </div>
            <form onSubmit={handleSendOffer} className="space-y-3">
              <div className="bg-[#F5F1E8] p-2.5 rounded-xl text-xs space-y-1">
                <div className="flex justify-between">
                  <span>Commodity:</span>
                  <strong>{offerLot.crop} (Grade {offerLot.grade})</strong>
                </div>
                <div className="flex justify-between">
                  <span>Quantity:</span>
                  <strong>{offerLot.quantity} Qtl</strong>
                </div>
              </div>
              <div>
                <label className="text-xs font-semibold block text-[#2D2D2D] mb-1">Bid Price (₹/Qtl)</label>
                <input
                  type="number"
                  required
                  min="500"
                  value={offerPrice}
                  onChange={(e) => setOfferPrice(e.target.value)}
                  className="w-full bg-[#F5F1E8] border border-[#ded8cb] rounded-xl p-2 text-sm font-bold text-[#2D2D2D]"
                />
              </div>
              <button
                type="submit"
                className="w-full bg-[#4A7C59] text-white py-2 rounded-xl text-xs font-bold"
              >
                Confirm & Send Offer
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
