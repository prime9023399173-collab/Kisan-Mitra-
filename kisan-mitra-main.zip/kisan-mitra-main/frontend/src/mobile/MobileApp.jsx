import React, { useState } from "react";
import {
  Sprout,
  TrendingUp,
  PlusCircle,
  PhoneCall,
  ShoppingBag,
  Languages,
  Wifi,
  Battery,
  Signal
} from "lucide-react";
import { useApp } from "../context/AppContext";
import MobileHome from "./MobileHome";
import MobileMandi from "./MobileMandi";
import MobileQuickSell from "./MobileQuickSell";
import MobileBuyer from "./MobileBuyer";
import IvrsSimulator from "../components/IvrsSimulator";

export default function MobileApp() {
  const { lang, setLang, t, pendingOffersCount } = useApp();

  // Active mobile tab: 'home' | 'mandi' | 'ivrs' | 'buyer'
  const [activeTab, setActiveTab] = useState("home");
  const [showQuickSell, setShowQuickSell] = useState(false);

  return (
    <div className="w-full max-w-md mx-auto bg-[#F5F1E8] min-h-[780px] shadow-2xl rounded-2xl overflow-hidden border-4 border-[#ded8cb] flex flex-col relative font-sans">
      {/* 1. Mobile Status Bar (Simulated Native Android/iOS Bar) */}
      <div className="bg-white px-4 py-1.5 flex items-center justify-between text-xs text-[#8B6F47] border-b border-[#F5F1E8]">
        <span className="font-semibold text-[#2D2D2D]">15:10</span>
        <div className="flex items-center gap-2">
          <Signal size={24} className="w-3.5 h-3.5" />
          <Wifi size={24} className="w-3.5 h-3.5" />
          <Battery size={24} className="w-4 h-4" />
        </div>
      </div>

      {/* 2. Mobile App Header */}
      <header className="bg-white px-4 py-3 border-b border-[#ded8cb] flex items-center justify-between sticky top-0 z-20 shadow-sm">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-[#4A7C59] text-white flex items-center justify-center shadow-sm">
            <Sprout size={24} />
          </div>
          <div>
            <span className="font-heading font-bold text-base text-[#2D2D2D] block leading-tight">
              {t.appTitle}
            </span>
            <span className="text-[10px] text-[#8B6F47] font-medium block">
              मोबाइल ऐप • Kisan Seva
            </span>
          </div>
        </div>

        {/* Vernacular Language Selector Chip */}
        <div className="flex items-center bg-[#F5F1E8] border border-[#ded8cb] rounded-xl px-2 py-1 gap-1">
          <Languages size={24} className="text-[#8B6F47] w-4 h-4" />
          <select
            value={lang}
            onChange={(e) => setLang(e.target.value)}
            className="bg-transparent text-[11px] font-bold text-[#2D2D2D] focus:outline-none cursor-pointer"
          >
            <option value="hi">हिन्दी</option>
            <option value="en">English</option>
            <option value="mr">मराठी</option>
          </select>
        </div>
      </header>

      {/* 3. Mobile Content Area */}
      <main className="flex-1 p-3 overflow-y-auto">
        {activeTab === "home" && (
          <MobileHome onOpenQuickSell={() => setShowQuickSell(true)} />
        )}
        {activeTab === "mandi" && <MobileMandi />}
        {activeTab === "ivrs" && <IvrsSimulator />}
        {activeTab === "buyer" && <MobileBuyer />}
      </main>

      {/* 4. Quick Sell Modal / Bottom Sheet */}
      {showQuickSell && (
        <MobileQuickSell
          onClose={() => setShowQuickSell(false)}
          onSuccess={() => setActiveTab("home")}
        />
      )}

      {/* 5. Mobile Native Bottom Navigation Bar (5 Primary Tabs) */}
      <nav className="bg-white border-t border-[#ded8cb] py-2 px-2 flex items-center justify-around fixed bottom-0 max-w-md w-full z-30 shadow-md">
        {/* Tab 1: Home (Kisan) */}
        <button
          onClick={() => setActiveTab("home")}
          className={`flex flex-col items-center gap-0.5 cursor-pointer py-1 px-2 rounded-xl transition-colors ${
            activeTab === "home"
              ? "text-[#4A7C59] font-bold"
              : "text-[#8B6F47] hover:text-[#2D2D2D]"
          }`}
        >
          <Sprout size={24} />
          <span className="text-[10px]">किसान</span>
        </button>

        {/* Tab 2: Mandi (Rates) */}
        <button
          onClick={() => setActiveTab("mandi")}
          className={`flex flex-col items-center gap-0.5 cursor-pointer py-1 px-2 rounded-xl transition-colors ${
            activeTab === "mandi"
              ? "text-[#4A7C59] font-bold"
              : "text-[#8B6F47] hover:text-[#2D2D2D]"
          }`}
        >
          <TrendingUp size={24} />
          <span className="text-[10px]">मंडी भाव</span>
        </button>

        {/* Tab 3: Center Becho Action (Quick Sell) */}
        <button
          onClick={() => setShowQuickSell(true)}
          className="flex flex-col items-center -mt-5 cursor-pointer group"
        >
          <div className="w-12 h-12 rounded-full bg-[#4A7C59] text-white flex items-center justify-center shadow-lg group-hover:bg-[#3d6749] transition-transform active:scale-95">
            <PlusCircle size={24} />
          </div>
          <span className="text-[10px] font-bold text-[#4A7C59] mt-0.5">बेचें</span>
        </button>

        {/* Tab 4: IVRS Helpline */}
        <button
          onClick={() => setActiveTab("ivrs")}
          className={`flex flex-col items-center gap-0.5 cursor-pointer py-1 px-2 rounded-xl transition-colors ${
            activeTab === "ivrs"
              ? "text-[#4A7C59] font-bold"
              : "text-[#8B6F47] hover:text-[#2D2D2D]"
          }`}
        >
          <PhoneCall size={24} />
          <span className="text-[10px]">IVRS कॉल</span>
        </button>

        {/* Tab 5: Vyapari (Buyer) */}
        <button
          onClick={() => setActiveTab("buyer")}
          className={`flex flex-col items-center gap-0.5 cursor-pointer py-1 px-2 rounded-xl transition-colors ${
            activeTab === "buyer"
              ? "text-[#4A7C59] font-bold"
              : "text-[#8B6F47] hover:text-[#2D2D2D]"
          }`}
        >
          <ShoppingBag size={24} />
          <span className="text-[10px]">व्यापारी</span>
        </button>
      </nav>
    </div>
  );
}
