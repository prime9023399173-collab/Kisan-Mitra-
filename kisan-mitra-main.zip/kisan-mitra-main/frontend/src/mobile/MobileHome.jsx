import React, { useState } from "react";
import {
  Wheat,
  Sprout,
  Flower2,
  Apple,
  Carrot,
  Layers,
  Sparkles,
  TrendingUp,
  TrendingDown,
  AlertTriangle,
  Clock,
  CheckCircle2,
  XCircle,
  FileQuestion,
  PlusCircle,
  ShieldCheck,
  Star,
  MapPin,
  Check
} from "lucide-react";
import { useApp } from "../context/AppContext";

export default function MobileHome({ onOpenQuickSell }) {
  const {
    activeFarmerId,
    getFarmer,
    lots,
    offers,
    transactions,
    mandis,
    buyers,
    priceAlerts,
    acceptOffer,
    rejectOffer,
    addGrievance,
    t
  } = useApp();

  const farmer = getFarmer(activeFarmerId) || {
    name: "Ramesh Patel",
    village: "Pipliya Mandi",
    phone: "+91 98261 45120"
  };

  const cropList = [
    { name: "Wheat", hindiName: "गेहूं", icon: Wheat },
    { name: "Soybean", hindiName: "सोयाबीन", icon: Sprout },
    { name: "Mustard", hindiName: "सरसों", icon: Flower2 },
    { name: "Chana", hindiName: "चना", icon: Sparkles },
    { name: "Onion", hindiName: "प्याज", icon: Apple },
    { name: "Cotton", hindiName: "कपास", icon: Layers },
    { name: "Paddy", hindiName: "धान", icon: Carrot }
  ];

  const [selectedCrop, setSelectedCrop] = useState("Soybean");
  const [grievanceTxnId, setGrievanceTxnId] = useState(null);
  const [grievanceText, setGrievanceText] = useState("");

  const myLots = lots.filter((l) => l.farmerId === activeFarmerId);
  const myLotIds = myLots.map((l) => l.id);
  const myOffers = offers.filter((o) => myLotIds.includes(o.lotId));

  // Active price alerts
  const activeAlerts = priceAlerts.filter(
    (a) => a.crop.toLowerCase() === selectedCrop.toLowerCase() || myLots.some((l) => l.crop === a.crop)
  );

  // 3-Mandi Price Comparison for selected crop
  const cropMandis = mandis.filter(
    (m) => m.crop.toLowerCase() === selectedCrop.toLowerCase()
  );
  const primaryMandi = cropMandis[0] || mandis[0];
  const mandiComparisons = [
    {
      name: primaryMandi ? primaryMandi.name : "Neemuch Mandi",
      location: "MP",
      price: primaryMandi ? primaryMandi.price : 4720,
      history: primaryMandi ? primaryMandi.priceHistory : [4500, 4550, 4610, 4580, 4650, 4700, 4720]
    },
    {
      name: "Indore APMC",
      location: "MP",
      price: primaryMandi ? Math.round(primaryMandi.price * 1.015) : 4790,
      history: primaryMandi
        ? primaryMandi.priceHistory.map((p) => Math.round(p * 1.012))
        : [4540, 4590, 4650, 4620, 4690, 4740, 4790]
    },
    {
      name: "Ujjain Mandi",
      location: "MP",
      price: primaryMandi ? Math.round(primaryMandi.price * 0.985) : 4650,
      history: primaryMandi
        ? primaryMandi.priceHistory.map((p) => Math.round(p * 0.99))
        : [4480, 4510, 4570, 4530, 4610, 4640, 4650]
    }
  ];

  // "Sell Now / Wait" recommendation (rule: if priceHistory rising >5% in 3 days, show Wait)
  const hist = primaryMandi ? primaryMandi.priceHistory : [4500, 4550, 4610, 4580, 4650, 4700, 4720];
  const currentPrice = hist[hist.length - 1];
  const price3DaysAgo = hist[Math.max(0, hist.length - 4)];
  const change3DaysPercent = Number((((currentPrice - price3DaysAgo) / price3DaysAgo) * 100).toFixed(1));
  const shouldWait = change3DaysPercent > 5.0;

  const handleGrievanceSubmit = (e) => {
    e.preventDefault();
    if (!grievanceText.trim() || !grievanceTxnId) return;
    addGrievance({
      transactionId: grievanceTxnId,
      message: grievanceText
    });
    setGrievanceText("");
    setGrievanceTxnId(null);
  };

  return (
    <div className="space-y-4 pb-20">
      {/* 1. Mobile Active Alert Banner */}
      {activeAlerts.length > 0 && (
        <div className="bg-[#fff8eb] border-2 border-[#D97706] rounded-xl shadow-md p-3 flex items-start gap-2.5">
          <div className="text-[#D97706] shrink-0 mt-0.5">
            <AlertTriangle size={24} />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-heading font-bold text-xs text-[#2D2D2D]">
                Mandi Price Alert
              </span>
              <span className="bg-[#D97706] text-white text-[10px] font-bold px-1.5 py-0.2 rounded-xl">
                {activeAlerts[0].direction === "up" ? "+" : "-"}{activeAlerts[0].changePercent}%
              </span>
            </div>
            <p className="text-xs text-[#2D2D2D] mt-0.5 font-medium leading-tight">
              {activeAlerts[0].crop} prices surged at regional APMC. High volatility today!
            </p>
          </div>
        </div>
      )}

      {/* 2. Farmer Mobile Welcome Card */}
      <div className="bg-white rounded-xl shadow-md p-4 border border-[#e2dcd0] flex items-center justify-between">
        <div>
          <div className="flex items-center gap-1.5">
            <h2 className="font-heading font-bold text-lg text-[#2D2D2D] m-0">
              {farmer.name}
            </h2>
            <span className="text-[#4A7C59]">
              <ShieldCheck size={24} />
            </span>
          </div>
          <span className="text-xs text-[#8B6F47]">
            {farmer.village} • {farmer.phone}
          </span>
        </div>

        <button
          onClick={onOpenQuickSell}
          className="bg-[#4A7C59] text-white rounded-xl px-3 py-2 text-xs font-bold flex items-center gap-1.5 shadow-sm hover:bg-[#3d6749] cursor-pointer"
        >
          <PlusCircle size={24} />
          <span>{t.createLotBtn.split(" ")[0]}</span>
        </button>
      </div>

      {/* 3. Crop Selection: Horizontal Scroll / Chips (Large Icon Cards) */}
      <div className="bg-white rounded-xl shadow-md p-4 border border-[#e2dcd0] space-y-3">
        <div className="flex items-center justify-between">
          <span className="font-heading font-bold text-sm text-[#2D2D2D]">
            Select Crop (फसल चुनें)
          </span>
          <span className="text-[11px] text-[#4A7C59] font-bold bg-[#F5F1E8] px-2 py-0.5 rounded-xl">
            Selected: {selectedCrop}
          </span>
        </div>

        <div className="flex gap-2.5 overflow-x-auto pb-1 scrollbar-none">
          {cropList.map((c) => {
            const IconC = c.icon;
            const isPicked = selectedCrop.toLowerCase() === c.name.toLowerCase();
            return (
              <button
                key={c.name}
                onClick={() => setSelectedCrop(c.name)}
                className={`shrink-0 w-20 py-2.5 px-1 rounded-xl flex flex-col items-center gap-1 border transition-colors cursor-pointer ${
                  isPicked
                    ? "bg-[#4A7C59] text-white border-[#4A7C59] shadow-sm"
                    : "bg-[#F5F1E8] text-[#2D2D2D] border-[#ded8cb]"
                }`}
              >
                <IconC size={24} />
                <span className="text-xs font-bold tracking-tight">{c.name}</span>
                <span className={`text-[10px] ${isPicked ? "text-white/80" : "text-[#8B6F47]"}`}>
                  {c.hindiName}
                </span>
              </button>
            );
          })}
        </div>

        {/* 3 Mandi Price Comparison for Selected Crop */}
        <div className="space-y-2 pt-2 border-t border-[#F5F1E8]">
          <span className="text-xs font-bold text-[#8B6F47] block">
            Today's Price Across 3 Mandis ({selectedCrop})
          </span>
          <div className="grid grid-cols-3 gap-2 text-center">
            {mandiComparisons.map((m, idx) => {
              const diff = ((m.price - m.history[m.history.length - 2]) / m.history[m.history.length - 2]) * 100;
              const isUp = diff >= 0;
              return (
                <div key={idx} className="bg-[#F5F1E8] p-2 rounded-xl border border-[#ded8cb]">
                  <span className="text-[11px] font-bold text-[#2D2D2D] block truncate">
                    {m.name.split(" ")[0]}
                  </span>
                  <span className="font-heading font-bold text-sm text-[#4A7C59] block mt-0.5">
                    ₹{m.price}
                  </span>
                  <span
                    className={`inline-flex items-center text-[10px] font-bold mt-0.5 ${
                      isUp ? "text-[#4A7C59]" : "text-[#C0392B]"
                    }`}
                  >
                    {isUp ? "+" : ""}{diff.toFixed(1)}%
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* 4. "Sell Now / Wait" Recommendation Button */}
        <div className="pt-2">
          {shouldWait ? (
            <div className="bg-[#fff8eb] border border-[#D97706] rounded-xl p-3 flex items-center justify-between">
              <div>
                <span className="font-heading font-bold text-xs text-[#D97706] block">
                  {t.waitRecommendation}
                </span>
                <span className="text-[11px] text-[#8B6F47]">
                  Prices surging +{change3DaysPercent}% in 3 days. Hold for higher return.
                </span>
              </div>
              <div className="bg-[#D97706] text-white p-2 rounded-xl shrink-0">
                <Clock size={24} />
              </div>
            </div>
          ) : (
            <div className="bg-[#F5F1E8] border border-[#4A7C59] rounded-xl p-3 flex items-center justify-between">
              <div>
                <span className="font-heading font-bold text-xs text-[#4A7C59] block">
                  {t.sellRecommendation}
                </span>
                <span className="text-[11px] text-[#8B6F47]">
                  Strong buyer liquidity and steady APMC benchmark. Sell now.
                </span>
              </div>
              <div className="bg-[#4A7C59] text-white p-2 rounded-xl shrink-0">
                <CheckCircle2 size={24} />
              </div>
            </div>
          )}
        </div>
      </div>

      {/* 5. Status Stepper: Listed → Matched → Picked Up → Paid */}
      <div className="bg-white rounded-xl shadow-md p-4 border border-[#e2dcd0] space-y-3">
        <div className="flex items-center justify-between">
          <span className="font-heading font-bold text-sm text-[#2D2D2D]">
            My Produce Lots ({myLots.length})
          </span>
          <span className="text-xs text-[#8B6F47]">Lifecycle Stepper</span>
        </div>

        {myLots.length === 0 ? (
          <div className="text-center py-4 text-xs text-[#8B6F47] bg-[#F5F1E8] rounded-xl p-3">
            No active lots. Tap "Create Lot" to list produce.
          </div>
        ) : (
          <div className="space-y-3">
            {myLots.map((lot) => {
              const stepMap = { listed: 0, matched: 1, pickedup: 2, paid: 3 };
              const currentStep = stepMap[lot.status] ?? 0;
              const stepLabels = ["Listed", "Matched", "Picked Up", "Paid"];

              const matchedOffer = offers.find(
                (o) => o.lotId === lot.id && o.status === "accepted"
              );
              const matchedTxn = matchedOffer
                ? transactions.find((txn) => txn.offerId === matchedOffer.id)
                : null;

              return (
                <div key={lot.id} className="bg-[#F5F1E8] p-3 rounded-xl border border-[#ded8cb] space-y-2">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="font-heading font-bold text-sm text-[#2D2D2D]">
                        {lot.crop} ({lot.quantity} Qtl)
                      </span>
                      <span className="text-[11px] text-[#8B6F47] block font-mono">
                        #{lot.id} • Grade {lot.grade}
                      </span>
                    </div>

                    {matchedTxn && (
                      <button
                        onClick={() => setGrievanceTxnId(matchedTxn.id)}
                        className="bg-white border border-[#C0392B] text-[#C0392B] text-[11px] font-bold px-2 py-1 rounded-xl flex items-center gap-1 cursor-pointer"
                      >
                        <FileQuestion size={24} className="w-3.5 h-3.5" />
                        <span>Problem?</span>
                      </button>
                    )}
                  </div>

                  {/* 4-Step Stepper Bar */}
                  <div className="grid grid-cols-4 gap-1 pt-1">
                    {stepLabels.map((lbl, idx) => {
                      const isDone = idx <= currentStep;
                      return (
                        <div
                          key={lbl}
                          className={`p-1.5 rounded-xl text-center border text-[10px] font-bold ${
                            idx === currentStep
                              ? "bg-[#4A7C59] text-white border-[#4A7C59]"
                              : isDone
                              ? "bg-white text-[#4A7C59] border-[#4A7C59]"
                              : "bg-[#ded8cb]/40 text-[#8B6F47] border-[#ded8cb]"
                          }`}
                        >
                          {lbl}
                        </div>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* 6. Incoming Offers */}
      <div className="bg-white rounded-xl shadow-md p-4 border border-[#e2dcd0] space-y-3">
        <div className="flex items-center justify-between">
          <span className="font-heading font-bold text-sm text-[#2D2D2D]">
            {t.myOffersTitle}
          </span>
          <span className="text-xs text-[#8B6F47]">{myOffers.length} Bids</span>
        </div>

        {myOffers.length === 0 ? (
          <div className="text-center py-4 text-xs text-[#8B6F47] bg-[#F5F1E8] rounded-xl p-3">
            No buyer offers pending review.
          </div>
        ) : (
          <div className="space-y-3">
            {myOffers.map((offer) => {
              const lot = lots.find((l) => l.id === offer.lotId);
              const buyer = buyers.find((b) => b.id === offer.buyerId);

              return (
                <div key={offer.id} className="bg-[#F5F1E8] p-3 rounded-xl border border-[#ded8cb] space-y-2">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="font-heading font-bold text-xs text-[#2D2D2D]">
                        {buyer ? buyer.name : "Agro Buyer"}
                      </span>
                      <span className="text-[11px] text-[#8B6F47] block">
                        {lot?.crop} ({lot?.quantity} Qtl)
                      </span>
                    </div>
                    <div className="text-right">
                      <span className="font-heading font-bold text-sm text-[#4A7C59] block">
                        ₹{offer.price} /qtl
                      </span>
                      <span className="text-[10px] font-bold uppercase text-[#8B6F47]">
                        {offer.status}
                      </span>
                    </div>
                  </div>

                  {offer.status === "pending" && (
                    <div className="flex gap-2 pt-1">
                      <button
                        onClick={() => acceptOffer(offer.id)}
                        className="flex-1 bg-[#4A7C59] text-white py-1.5 rounded-xl text-xs font-bold hover:bg-[#3d6749] cursor-pointer"
                      >
                        Accept
                      </button>
                      <button
                        onClick={() => rejectOffer(offer.id)}
                        className="flex-1 bg-white border border-[#C0392B] text-[#C0392B] py-1.5 rounded-xl text-xs font-bold hover:bg-[#fff5f5] cursor-pointer"
                      >
                        Decline
                      </button>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Modal: Mobile Grievance Form */}
      {grievanceTxnId && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl shadow-md p-4 max-w-sm w-full border border-[#ded8cb] space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-heading font-bold text-sm text-[#2D2D2D]">
                Report Grievance ({grievanceTxnId})
              </span>
              <button onClick={() => setGrievanceTxnId(null)} className="text-[#8B6F47]">
                <XCircle size={24} />
              </button>
            </div>
            <textarea
              rows={3}
              required
              placeholder="Describe issue (weight difference, transport, delay)..."
              value={grievanceText}
              onChange={(e) => setGrievanceText(e.target.value)}
              className="w-full bg-[#F5F1E8] border border-[#ded8cb] rounded-xl p-2.5 text-xs text-[#2D2D2D] focus:outline-none"
            />
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setGrievanceTxnId(null)}
                className="flex-1 bg-white border border-[#ded8cb] rounded-xl py-2 text-xs font-semibold"
              >
                Cancel
              </button>
              <button
                onClick={handleGrievanceSubmit}
                className="flex-1 bg-[#4A7C59] text-white rounded-xl py-2 text-xs font-bold hover:bg-[#3d6749]"
              >
                Submit
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
