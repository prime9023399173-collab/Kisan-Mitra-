import React, { useState } from "react";
import {
  TrendingUp,
  TrendingDown,
  Landmark,
  MapPin,
  AlertTriangle,
  Calendar
} from "lucide-react";
import { useApp } from "../context/AppContext";
import MiniPriceChart from "../components/MiniPriceChart";

export default function MobileMandi() {
  const { mandis, priceAlerts, t } = useApp();

  const [activeMandiId, setActiveMandiId] = useState(mandis[0]?.id || "mandi-1");
  const selectedMandi = mandis.find((m) => m.id === activeMandiId) || mandis[0];

  return (
    <div className="space-y-4 pb-20">
      {/* Header */}
      <div className="bg-white rounded-xl shadow-md p-4 border border-[#e2dcd0] flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="text-[#4A7C59]">
            <Landmark size={24} />
          </div>
          <div>
            <h2 className="font-heading font-bold text-base text-[#2D2D2D] m-0">
              APMC Mandi Rates
            </h2>
            <span className="text-[11px] text-[#8B6F47]">
              Real-time daily market benchmark rates
            </span>
          </div>
        </div>
      </div>

      {/* Selected Mandi Deep Dive Card */}
      {selectedMandi && (
        <div className="bg-white rounded-xl shadow-md p-4 border border-[#e2dcd0] space-y-3">
          <div className="flex items-start justify-between">
            <div>
              <span className="font-heading font-bold text-lg text-[#2D2D2D] block">
                {selectedMandi.crop}
              </span>
              <span className="text-xs text-[#8B6F47] flex items-center gap-1 mt-0.5">
                <MapPin size={24} className="w-3.5 h-3.5" />
                {selectedMandi.name} ({selectedMandi.location.split(",")[0]})
              </span>
            </div>
            <div className="text-right">
              <span className="font-heading font-bold text-xl text-[#4A7C59] block">
                ₹{selectedMandi.price}
              </span>
              <span className="text-[10px] text-[#8B6F47]">per quintal</span>
            </div>
          </div>

          <div className="pt-2">
            <MiniPriceChart
              history={selectedMandi.priceHistory}
              crop={selectedMandi.crop}
              currentPrice={selectedMandi.price}
            />
          </div>
        </div>
      )}

      {/* Mandi Rates List */}
      <div className="bg-white rounded-xl shadow-md p-4 border border-[#e2dcd0] space-y-3">
        <span className="font-heading font-bold text-sm text-[#2D2D2D] block">
          All Monitored Commodities
        </span>

        <div className="space-y-2">
          {mandis.map((m) => {
            const yesterday = m.priceHistory[m.priceHistory.length - 2];
            const change = Number((((m.price - yesterday) / yesterday) * 100).toFixed(1));
            const isUp = change >= 0;
            const isPicked = m.id === activeMandiId;

            return (
              <button
                key={m.id}
                onClick={() => setActiveMandiId(m.id)}
                className={`w-full p-3 rounded-xl border flex items-center justify-between text-left transition-colors cursor-pointer ${
                  isPicked
                    ? "bg-[#F5F1E8] border-[#4A7C59]"
                    : "bg-white border-[#ded8cb] hover:bg-[#F5F1E8]/50"
                }`}
              >
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="font-heading font-bold text-sm text-[#2D2D2D]">
                      {m.crop}
                    </span>
                    <span className="text-[11px] text-[#8B6F47]">• {m.name.split(" ")[0]}</span>
                  </div>
                  <span className="text-[10px] text-[#8B6F47] block mt-0.5">{m.lastUpdated}</span>
                </div>

                <div className="text-right">
                  <span className="font-heading font-bold text-sm text-[#2D2D2D] block">
                    ₹{m.price}
                  </span>
                  <span
                    className={`inline-flex items-center text-[11px] font-bold ${
                      isUp ? "text-[#4A7C59]" : "text-[#C0392B]"
                    }`}
                  >
                    {isUp ? "+" : ""}{change}%
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
