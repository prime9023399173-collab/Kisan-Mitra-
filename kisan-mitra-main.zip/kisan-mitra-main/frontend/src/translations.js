/**
 * Kisan Mitra - Localization Dictionary
 * Supports Hindi (हिन्दी), English, and Marathi (मराठी)
 */
export const translations = {
  hi: {
    appTitle: "किसान मित्र",
    appSubtitle: "कृषि व्यापार एवं मंडी सूचना नेटवर्क",
    farmerTab: "किसान डैशबोर्ड",
    buyerTab: "मंडी / व्यापारी डैशबोर्ड",
    ivrsTab: "IVRS कॉल सिम्युलेटर",
    adminTab: "मंडी अधिकारी",
    language: "भाषा",
    verifiedFarmer: "सत्यापित किसान",
    verifiedBuyer: "सत्यापित व्यापारी",
    phone: "फ़ोन",
    village: "गाँव",
    category: "श्रेणी",
    rating: "रेटिंग",
    activeDemand: "सक्रिय खरीद लक्ष्य",

    // Crop Names
    wheat: "गेहूं (Wheat)",
    soybean: "सोयाबीन (Soybean)",
    mustard: "सरसों (Mustard)",
    chana: "चना (Chana)",
    onion: "प्याज (Onion)",
    cotton: "कपास (Cotton)",
    paddy: "धान (Paddy)",

    // Recommendation
    recommendationTitle: "मंडी बिक्री सलाह (Sell Now / Wait)",
    waitRecommendation: "रुकें - भाव बढ़ रहे हैं (Wait)",
    waitReason: "पिछले 3 दिनों में भाव में 5% से अधिक तेजी दर्ज की गई है। रोककर रखने पर बेहतर मूल्य मिल सकता है।",
    sellRecommendation: "अभी बेचें - अच्छा भाव (Sell Now)",
    sellReason: "मंडी में पर्याप्त मांग है और भाव स्थिर हैं। समय पर बिक्री से तुरंत भुगतान प्राप्त करें।",
    benchmarkPrice: "आज का औसत मंडी भाव",

    // 3 Mandi Price Comparison
    mandiComparisonTitle: "3 मंडियों में आज का भाव",
    selectCropTip: "भाव और रुझान देखने के लिए ऊपर फसल कार्ड पर टैप करें",

    // Create Lot 3-Step
    createLotBtn: "नया लॉट बनाएं (Create Lot)",
    createLotModalTitle: "फसल लॉट बनाएं (3 सरल चरण)",
    step1Title: "चरण 1: फसल चुनें",
    step2Title: "चरण 2: मात्रा दर्ज करें (क्विंटल)",
    step3Title: "चरण 3: गुणवत्ता ग्रेड चुनें",
    nextStep: "आगे बढ़ें",
    prevStep: "पीछे जाएं",
    publishLot: "लॉट प्रकाशित करें",
    gradeA: "ग्रेड A (प्रीमियम नमी <10%, शुद्धता >98%)",
    gradeB: "ग्रेड B (मानक औसत गुणवत्ता)",
    gradeC: "ग्रेड C (व्यावसायिक ग्रेड)",

    // Stepper
    stepperListed: "सूचीबद्ध (Listed)",
    stepperMatched: "सौदा तय (Matched)",
    stepperPickedUp: "माल उठा (Picked Up)",
    stepperPaid: "भुगतान प्राप्त (Paid)",

    // My Offers
    myOffersTitle: "मेरे लॉट पर आए खरीदार ऑफर",
    acceptOffer: "स्वीकार करें",
    rejectOffer: "अस्वीकार करें",
    dealConfirmed: "सौदा पक्का! एस्क्रो में भुगतान सुरक्षित।",

    // Grievance
    reportProblem: "समस्या दर्ज करें (Report Problem)",
    grievanceTitle: "मंडी शिकायत निवारण",
    grievanceDesc: "तौल में अंतर, वाहन में देरी या भुगतान से जुड़ी समस्या दर्ज करें:",
    submitGrievance: "शिकायत दर्ज करें",
    grievanceStatusOpen: "खुली है (Open)",
    grievanceStatusReview: "जांच जारी (In Review)",
    grievanceStatusResolved: "समाधान हो गया (Resolved)",

    // Buyer Dashboard
    postDemandTitle: "खरीद मांग पोस्ट करें (Post Demand)",
    demandCrop: "फसल",
    demandQuantity: "मात्रा (क्विंटल)",
    demandGrade: "वांछित ग्रेड",
    demandPrice: "ऑफर दर (₹/क्विंटल)",
    submitDemand: "मांग प्रसारित करें",
    liveTickerTitle: "ट्रैक की जा रही फसलों का लाइव मंडी भाव",
    browseLotsTitle: "मांग अनुसार उपलब्ध किसान लॉट",
    sendOfferBtn: "डिजिटल ऑफर भेजें",
    aggregatedBatchesTitle: "संयुक्त लॉट बैच (Aggregated Nearby Batches)",
    batchSummary: "पास के किसानों का संयुक्त माल (परिवहन बचत)",

    // IVRS Simulator
    ivrsBanner: "IVRS किसान हेल्पलाइन सिम्युलेटर (Toll-Free 1800-KISAN)",
    telecomNote: "नोट: वास्तविक उत्पादन संस्करण टेलीकॉम IVR गेटवे (Twilio/Exotel) के साथ एकीकृत होता है।",
    startCall: "हेल्पलाइन कॉल शुरू करें",
    endCall: "कॉल समाप्त करें",
    callingText: "कॉल कनेक्ट हो रही है...",
    connectedCall: "कॉल सक्रिय है",
    ivrPress: "दबाएं"
  },
  en: {
    appTitle: "Kisan Mitra",
    appSubtitle: "Agricultural Trading & Mandi Information Network",
    farmerTab: "Farmer Dashboard",
    buyerTab: "Mandi / Buyer Dashboard",
    ivrsTab: "IVRS Simulator",
    adminTab: "Mandi Officer",
    language: "Language",
    verifiedFarmer: "Verified Farmer",
    verifiedBuyer: "Verified Buyer",
    phone: "Phone",
    village: "Village",
    category: "Category",
    rating: "Rating",
    activeDemand: "Active Sourcing Target",

    // Crop Names
    wheat: "Wheat",
    soybean: "Soybean",
    mustard: "Mustard",
    chana: "Chana",
    onion: "Onion",
    cotton: "Cotton",
    paddy: "Paddy",

    // Recommendation
    recommendationTitle: "Mandi Selling Advisory (Sell Now / Wait)",
    waitRecommendation: "Wait — Prices Rising",
    waitReason: "Prices have surged >5% over the past 3 days. Holding produce may yield higher realization.",
    sellRecommendation: "Sell Now — Strong Liquidity",
    sellReason: "Healthy market demand and stable APMC rates. Lock in guaranteed escrow payment now.",
    benchmarkPrice: "Today's APMC Mandi Benchmark",

    // 3 Mandi Price Comparison
    mandiComparisonTitle: "Today's Price Across 3 Regional Mandis",
    selectCropTip: "Tap on any crop icon card above to see regional mandi comparisons and 7-day trend.",

    // Create Lot 3-Step
    createLotBtn: "Create New Lot",
    createLotModalTitle: "List Produce Lot (3 Simple Steps)",
    step1Title: "Step 1: Select Commodity",
    step2Title: "Step 2: Enter Quantity (Quintals)",
    step3Title: "Step 3: Choose Quality Grade",
    nextStep: "Next Step",
    prevStep: "Go Back",
    publishLot: "Publish Lot to Mandi",
    gradeA: "Grade A (Premium moisture <10%, purity >98%)",
    gradeB: "Grade B (Standard fair average quality)",
    gradeC: "Grade C (Commercial processing grade)",

    // Stepper
    stepperListed: "Listed",
    stepperMatched: "Matched",
    stepperPickedUp: "Picked Up",
    stepperPaid: "Paid",

    // My Offers
    myOffersTitle: "Incoming Buyer Offers on My Lots",
    acceptOffer: "Accept Offer",
    rejectOffer: "Decline",
    dealConfirmed: "Deal Confirmed! Escrow transaction initiated.",

    // Grievance
    reportProblem: "Report a Problem",
    grievanceTitle: "Mandi Dispute & Grievance Desk",
    grievanceDesc: "Report weighing discrepancies, transport delays, or payment questions:",
    submitGrievance: "Submit to Mandi APMC",
    grievanceStatusOpen: "Open",
    grievanceStatusReview: "In Review",
    grievanceStatusResolved: "Resolved",

    // Buyer Dashboard
    postDemandTitle: "Post Procurement Demand",
    demandCrop: "Target Crop",
    demandQuantity: "Quantity (Quintals)",
    demandGrade: "Target Grade",
    demandPrice: "Offered Rate (₹/Qtl)",
    submitDemand: "Broadcast Demand",
    liveTickerTitle: "Live Price Ticker for Tracked Crops",
    browseLotsTitle: "Browse Available Farmer Lots",
    sendOfferBtn: "Send Digital Offer",
    aggregatedBatchesTitle: "Aggregated Nearby Batches",
    batchSummary: "Combined farmer produce batches (freight savings)",

    // IVRS Simulator
    ivrsBanner: "IVRS Farmer Helpline Simulator (Toll-Free 1800-KISAN)",
    telecomNote: "Production version integrates with a telecom IVR gateway (Twilio/Exotel)",
    startCall: "Start Simulated Helpline Call",
    endCall: "Hang Up Call",
    callingText: "Dialing Toll-Free APMC Gateway...",
    connectedCall: "Call Connected",
    ivrPress: "Press"
  },
  mr: {
    appTitle: "किसान मित्र",
    appSubtitle: "कृषी व्यापार आणि बाजार समिती माहिती",
    farmerTab: "शेतकरी डॅशबोर्ड",
    buyerTab: "खरेदीदार / व्यापारी डॅशबोर्ड",
    ivrsTab: "IVRS कॉल सिम्युलेटर",
    adminTab: "बाजार समिती अधिकारी",
    language: "भाषा",
    verifiedFarmer: "प्रमाणित शेतकरी",
    verifiedBuyer: "प्रमाणित व्यापारी",
    phone: "फोन",
    village: "गाव",
    category: "प्रवर्ग",
    rating: "रेटिंग",
    activeDemand: "खरेदीचे उद्दिष्ट",

    wheat: "गहू (Wheat)",
    soybean: "सोयाबीन (Soybean)",
    mustard: "मोहरी (Mustard)",
    chana: "हरभरा (Chana)",
    onion: "कांदा (Onion)",
    cotton: "कापूस (Cotton)",
    paddy: "तांदूळ (Paddy)",

    recommendationTitle: "बाजार विक्री सल्ला (Sell Now / Wait)",
    waitRecommendation: "थांबा - भाव वाढत आहेत (Wait)",
    waitReason: "गेल्या ३ दिवसांत भावात ५% पेक्षा जास्त वाढ झाली आहे. थोडा वेळ थांबल्यास चांगला दर मिळू शकतो.",
    sellRecommendation: "आता विका - चांगला भाव (Sell Now)",
    sellReason: "बाजारात चांगली मागणी आहे आणि दर स्थिर आहेत. त्वरित विक्री करून पैसे मिळवा.",
    benchmarkPrice: "आजचा सरासरी बाजार भाव",

    mandiComparisonTitle: "३ बाजारांमधील आजचे भाव",
    selectCropTip: "तुलना पाहण्यासाठी वरील पीक कार्डवर टॅप करा",

    createLotBtn: "नवीन लॉट तयार करा",
    createLotModalTitle: "लॉट नोंदणी (३ सोप्या पायऱ्या)",
    step1Title: "पायरी १: पीक निवडा",
    step2Title: "पायरी २: प्रमाण प्रविष्ट करा (क्विंटल)",
    step3Title: "पायरी ३: गुणवत्ता ग्रेड निवडा",
    nextStep: "पुढे जा",
    prevStep: "मागे या",
    publishLot: "लॉट प्रकाशित करा",
    gradeA: "ग्रेड A (उत्कृष्ट प्रत, ओलावा <१०%)",
    gradeB: "ग्रेड B (मध्यम प्रत)",
    gradeC: "ग्रेड C (व्यापारी प्रत)",

    stepperListed: "नोंदणीकृत (Listed)",
    stepperMatched: "सौदा निश्चित (Matched)",
    stepperPickedUp: "माल उचलला (Picked Up)",
    stepperPaid: "पैसे जमा (Paid)",

    myOffersTitle: "माझ्या लॉटवरील खरेदीदारांच्या ऑपर्स",
    acceptOffer: "स्वीकारा",
    rejectOffer: "नाकारा",
    dealConfirmed: "सौदा निश्चित झाला! सुरक्षित एस्क्रो व्यवहार सुरू.",

    reportProblem: "तक्रार नोंदवा",
    grievanceTitle: "बाजार समिती तक्रार निवारण कक्ष",
    grievanceDesc: "वजन, वाहतूक किंवा पेमेंट संबंधित तक्रार नोंदवा:",
    submitGrievance: "तक्रार दाखल करा",
    grievanceStatusOpen: "प्रलंबित (Open)",
    grievanceStatusReview: "तपासणी सुरू (In Review)",
    grievanceStatusResolved: "निकाली काढली (Resolved)",

    postDemandTitle: "खरेदी मागणी नोंदवा",
    demandCrop: "पीक",
    demandQuantity: "प्रमाण (क्विंटल)",
    demandGrade: "अपेक्षित ग्रेड",
    demandPrice: "ऑफर दर (₹/क्विंटल)",
    submitDemand: "मागणी प्रसारित करा",
    liveTickerTitle: "ट्रॅक केलेल्या पिकांचे थेट बाजार भाव",
    browseLotsTitle: "उपलब्ध शेतकरी लॉट्स",
    sendOfferBtn: "ऑफर पाठवा",
    aggregatedBatchesTitle: "एकत्रित लॉट बॅच (Aggregated Batches)",
    batchSummary: "जवळपासच्या शेतकऱ्यांचा एकत्रित माल (वाहतूक बचत)",

    ivrsBanner: "IVRS शेतकरी हेल्पलाईन सिम्युलेटर (Toll-Free 1800-KISAN)",
    telecomNote: "टीप: प्रत्यक्ष उत्पादन आवृत्ती टेलिकॉम IVR गेटवे (Twilio/Exotel) सोबत जोडलेली असते.",
    startCall: "कॉल सुरू करा",
    endCall: "कॉल बंद करा",
    callingText: "कॉल जोडला जात आहे...",
    connectedCall: "कॉल जोडला गेला",
    ivrPress: "दाबा"
  }
};
