# 🌾 Kisan Mitra (किसान मित्र)
### Agricultural Trading & Mandi Information Network

A comprehensive agricultural trading, produce lot management, and APMC mandi information platform built with **React**, **Tailwind CSS**, and **Lucide Icons**, strictly conforming to the custom design system and shared data models.

---

## 🎨 Design System

- **Colors**:
  - Primary Green: `#4A7C59`
  - Secondary Earth Brown: `#8B6F47`
  - Warm Off-White Background: `#F5F1E8`
  - Dark Text: `#2D2D2D`
  - Alert / Warning: `#D97706`
  - Success: `#4A7C59`
  - Error: `#C0392B`
- **Typography**:
  - Headings: `'Poppins', sans-serif`
  - UI Text: `'Inter', sans-serif`
- **Component Styling**:
  - Border radius: `12px` (`rounded-xl` in Tailwind)
  - Card style: White background, soft shadow (`shadow-md`), 16px padding (`p-4`)
  - Buttons: Solid green primary buttons, white text, `rounded-xl`, **strictly no gradients**
  - Icons: `lucide-react` icons strictly sized at `24px`
  - Layout & Spacing: Tailwind default scale, section padding `p-6`, card gap `gap-4`
  - **Negative Constraints**: Zero dark mode, zero glassmorphism, zero neon colors, zero gradients.

---

## 📊 Shared Data Model (`src/data.js`)

All data strictly follows the shared model:
- **`Mandi`**: `id, name, location, crop, price, priceHistory[7 days], lastUpdated`
- **`Farmer`**: `id, name, village, phone`
- **`Lot`**: `id, farmerId, crop, quantity, grade (A/B/C), status (listed/matched/pickedup/paid)`
- **`Buyer`**: `id, name, type, verified, rating, demand{crop, quantity}`
- **`Offer`**: `id, lotId, buyerId, price, status (pending/accepted/rejected)`
- **`Transaction`**: `id, offerId, paymentStatus, logisticsStatus`
- **`Grievance`**: `id, transactionId, message, status`
- **`PriceAlert`**: `id, crop, mandiId, changePercent, direction, timestamp`

---

## 🚀 Key Modules & Experiences

### 1. 🌾 Farmer Dashboard
- **Crop Icon Cards**: Large touch-friendly cards for Wheat, Soybean, Mustard, Chana, Onion, Cotton, Paddy.
- **3-Mandi Price Comparison**: Real-time rates across 3 regional APMC mandis with trend arrows.
- **"Sell Now / Wait" Recommendation**: Rule-based advisory (if 3-day price rise > 5%, recommends **Wait**; otherwise **Sell Now**).
- **Create Lot (3-Step Form)**: Icon-based, minimal typing flow (Crop -> Quantity Chips -> Quality Grade A/B/C).
- **Incoming Offers**: Bids from verified buyers with one-click Accept/Reject.
- **Lot Lifecycle Stepper**: `Listed → Matched → Picked Up → Paid`.
- **Grievance Desk**: Form to report discrepancies on transactions.

### 2. 📱 Mobile Application & PWA
- **Dual-Experience Switcher**: Toggle between Desktop Web Portal and Mobile Phone Shell.
- **5-Tab Native Bottom Navigation**:
  1. 🌾 **Kisan (Home)**: Crop cards, 3-mandi rates, Sell/Wait advisory.
  2. 📊 **Mandi**: Commodity ticker and 7-day sparklines.
  3. ➕ **Becho (Quick Sell)**: 3-step bottom sheet.
  4. 📞 **IVRS**: Simulated telecom helpline call.
  5. 💼 **Vyapari**: Buyer sourcing desk and batches.
- **PWA & Native Ready**: Includes `manifest.json` and `capacitor.config.json` for home screen install or building Android APKs via Capacitor.

### 3. 📞 Standalone IVRS Simulator
- Telecom voice helpline simulator for feature phone farmers.
- Interactive DTMF dialpad (0-9, *, #), speech bubble transcript, 3-mandi comparison readout, price alerts, and automated `Lot` generation.
- Production integration notice for Twilio/Exotel.

### 4. 💼 Mandi / Buyer Dashboard
- Data-dense table UI for commercial traders.
- Post Procurement Demand form.
- Live price ticker from 7-day APMC price history.
- Aggregated regional lot batches (with ~18% freight savings calculation).
- Browse matching lots and dispatch digital offers.

### 5. 🌐 Multi-Language Support
- Instant real-time language switcher supporting:
  - **हिन्दी (Hindi)**
  - **English (EN)**
  - **मराठी (Marathi)**

---

## 🛠️ Getting Started

### Prerequisites
- Node.js (v18+)
- npm

### Installation & Run

```bash
# Clone the repository
git clone <repository-url>
cd kisan-mitra

# Install dependencies
npm install

# Run Vite development server
npm run dev

# Build for production
npm run build
```

Open `http://localhost:5173` in your browser. For mobile network testing, connect your phone to the same Wi-Fi and open `http://<your-local-ip>:5173`.
