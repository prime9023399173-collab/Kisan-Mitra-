# Kisan Mitra API

Hono + TypeScript + PostgreSQL (Drizzle ORM). Runs on any Postgres 15+; with no `DATABASE_URL` in dev it uses embedded Postgres (PGlite), so `npm run dev` needs no setup.

```bash
npm install
npm run dev                 # embedded DB, auto-migrates, OTP printed to console
npm run seed                # demo data matching the frontend (logins below)
npm test                    # 30 tests on embedded Postgres
npm run test:pg             # same suite on a real server (edit the URL in package.json)
```
Production: set `DATABASE_URL`, `JWT_SECRET` (32+ chars), `CORS_ORIGINS`; run `npm run build && npm run migrate && npm start` (or `docker compose up`).
Seed logins (OTP `123456` when `OTP_FIXED_CODE` is set): farmer `+919826145120`, buyer `+919000000001`, mandi officer `+919000000100`, admin `+919000000101`.

## What the database guarantees (even for raw SQL)
- Lot / offer / payment / logistics / grievance **state machines** enforced by triggers; deal terms immutable; money moves only after delivery and goods only after escrow is funded (CHECKs).
- One accepted offer per lot, one open offer per buyer per lot (partial unique indexes); `amount_total` computed by the DB.
- Append-only audit log; append-only price time series; keyset-pagination indexes; latest-price view via LATERAL index probes.

## API (`/api/v1`, bearer JWT, errors are problem+json)
| Area | Endpoints |
|---|---|
| Auth | `POST /auth/otp`, `/auth/verify` (include `registration` for new numbers), `/auth/refresh`, `/auth/logout`; `GET/PATCH /me` |
| Market (public) | `GET /crops, /mandis?near=lat,lng&radiusKm, /prices, /prices/history, /price-alerts, /advisory?crop=` |
| Mandi staff | `POST /mandis/:id/prices` (own mandis only; alert on 2%+ move; over 40% needs `confirmLargeChange`) |
| Lots | `POST/GET /lots`, `GET /lots/:id`, `POST /lots/:id/cancel` |
| Offers | `POST /lots/:id/offers`, `GET /lots/:id/offers`, `GET /offers`, `POST /offers/:id/accept\|reject\|withdraw` |
| Deals | `GET /transactions[/:id]`, `POST /transactions/:id/logistics\|payment\|rating` |
| Support | `POST/GET /grievances`, `PATCH /grievances/:id`; `GET /buyers`, `PUT /buyers/me/demands` |
| Live | `GET /notifications`, `POST /notifications/read`, `GET /events` (SSE; use fetch with the Authorization header) |
| Admin | `/admin/users, /admin/mandis, /admin/buyers/:id/verify, /admin/msp, /admin/audit` |

## Security & reliability
Phone-OTP login (HMAC-hashed codes, attempt lockout, hourly cap); 15-min JWTs + rotating refresh tokens with reuse detection; role + ownership checks on every row; `Idempotency-Key` on writes (safe retries on flaky networks); rate limits; secure headers; CORS allow-list; body-size cap; row locks (lot, then offer) so concurrent accepts cannot double-sell; realtime via Postgres LISTEN/NOTIFY (works across instances, fires only on commit).

## Before real money / real users
1. **SMS/WhatsApp gateway**: implement `OtpSender` (`src/lib/otp.ts`); the console sender is dev-only.
2. **Payments**: escrow here is a status ledger. Connect a regulated payment provider to drive `in_escrow` to `paid`.
3. **MSP and mandi prices**: no official values are bundled. Load MSP via `PUT /admin/msp`; an Agmarknet/eNAM importer can write `price_observations` (`source='agmarknet'`).
4. Buyer KYC is manual (`/admin/buyers/:id/verify`); GSTIN is stored but not checked against the GST portal.
5. Add a gateway/Redis rate limiter when running more than one instance; enable database backups/PITR.
