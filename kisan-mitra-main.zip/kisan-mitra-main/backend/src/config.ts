import { z } from 'zod'

const bool = z.enum(['true', 'false']).transform((v) => v === 'true')

const schema = z.object({
  NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
  PORT: z.coerce.number().int().default(8787),
  LOG_LEVEL: z.enum(['fatal', 'error', 'warn', 'info', 'debug', 'trace', 'silent']).default('info'),
  /** Postgres URL. If omitted (dev only) an embedded Postgres (PGlite) is used. */
  DATABASE_URL: z.string().url().optional(),
  DB_POOL_MAX: z.coerce.number().int().min(1).default(10),
  PGLITE_DIR: z.string().default('./.data/pglite'),
  JWT_SECRET: z.string().min(32).optional(),
  ACCESS_TTL_SEC: z.coerce.number().int().default(900),
  REFRESH_TTL_DAYS: z.coerce.number().int().default(30),
  OTP_TTL_SEC: z.coerce.number().int().default(300),
  OTP_MAX_ATTEMPTS: z.coerce.number().int().default(5),
  OTP_MAX_PER_HOUR: z.coerce.number().int().default(5),
  /** Dev/test only: every OTP becomes this code. Refused in production. */
  OTP_FIXED_CODE: z.string().regex(/^\d{6}$/).optional(),
  CORS_ORIGINS: z.string().default('http://localhost:5173'),
  ALERT_THRESHOLD_PERCENT: z.coerce.number().min(0).default(2),
  MAX_PRICE_JUMP_PERCENT: z.coerce.number().min(1).default(40),
  /** Run pending migrations at boot. Default: on in dev, off in production (run `npm run migrate` as a release step). */
  AUTO_MIGRATE: bool.optional(),
  REQUIRE_VERIFIED_BUYERS: bool.default(true),
  /** Honour X-Forwarded-For for rate limiting (only behind a trusted proxy/load balancer). */
  TRUST_PROXY: bool.default(false),
  RATE_LIMIT_PER_MIN: z.coerce.number().int().default(240),
  /** Stricter per-IP limit on /auth/* (OTP abuse protection). */
  AUTH_RATE_LIMIT_PER_MIN: z.coerce.number().int().default(20),
})

export type Config = Omit<z.infer<typeof schema>, 'JWT_SECRET'> & { JWT_SECRET: string }

export function loadConfig(env: Record<string, string | undefined> = process.env): Config {
  const c = schema.parse(env)
  const prod = c.NODE_ENV === 'production'
  if (prod && !c.DATABASE_URL) throw new Error('DATABASE_URL is required in production')
  if (prod && !c.JWT_SECRET) throw new Error('JWT_SECRET (>=32 chars) is required in production')
  if (prod && c.OTP_FIXED_CODE) throw new Error('OTP_FIXED_CODE must not be set in production')
  return { ...c, JWT_SECRET: c.JWT_SECRET ?? 'dev-only-secret-dev-only-secret-dev-only!!' }
}
