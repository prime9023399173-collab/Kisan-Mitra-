import { and, desc, eq, sql, type SQL } from 'drizzle-orm'
import { Hono, type MiddlewareHandler } from 'hono'
import { z } from 'zod'
import type { AppEnv, Deps } from '../deps'
import { crops, mandiAdmins, mandiCrops, mandis, mspRates, priceAlerts, priceObservations } from '../db/schema'
import { me, requireRole, v } from '../http'
import { audit } from '../lib/audit'
import { publish } from '../lib/events'
import { AppError, forbidden, notFound } from '../lib/errors'
import { num } from '../lib/util'

const uuid = z.string().uuid()
const price = z.coerce.number().positive().max(999_999)

type PriceRow = {
  mandi_id: string; crop_id: string; price: string; min_price: string | null; max_price: string | null
  arrivals_qtl: string | null; observed_at: Date | string; mandi_name: string; district: string; state: string
  crop_name: string; history: number[]; distance_km?: number | null
}

/** Latest price per mandi/crop plus the last 7 daily closes (IST days). */
export async function listPrices(d: Deps, f: { cropId?: string; mandiId?: string; state?: string; near?: [number, number]; radiusKm?: number; limit?: number }) {
  const where: SQL[] = [sql`true`]
  if (f.cropId) where.push(sql`lp.crop_id = ${f.cropId}`)
  if (f.mandiId) where.push(sql`lp.mandi_id = ${f.mandiId}`)
  if (f.state) where.push(sql`lower(m.state) = lower(${f.state})`)
  const dist = f.near
    ? sql`(6371 * acos(least(1, greatest(-1, cos(radians(${f.near[0]})) * cos(radians(m.latitude)) * cos(radians(m.longitude) - radians(${f.near[1]})) + sin(radians(${f.near[0]})) * sin(radians(m.latitude))))))`
    : sql`NULL::float8`
  const inner = sql`
    SELECT lp.mandi_id, lp.crop_id, lp.price, lp.min_price, lp.max_price, lp.arrivals_qtl, lp.observed_at,
           m.name AS mandi_name, m.district, m.state, c.name AS crop_name, ${dist} AS distance_km,
           (SELECT coalesce(json_agg(h.price ORDER BY h.day), '[]'::json) FROM (
              SELECT dd.day, dd.price FROM (
                SELECT DISTINCT ON (x.day) x.day, x.price FROM (
                  SELECT (po.observed_at AT TIME ZONE 'Asia/Kolkata')::date AS day, po.price, po.observed_at, po.id
                  FROM price_observations po
                  WHERE po.mandi_id = lp.mandi_id AND po.crop_id = lp.crop_id AND po.observed_at >= now() - interval '14 days'
                ) x ORDER BY x.day DESC, x.observed_at DESC, x.id DESC
              ) dd ORDER BY dd.day DESC LIMIT 7
           ) h) AS history
    FROM v_latest_price lp JOIN mandis m ON m.id = lp.mandi_id JOIN crops c ON c.id = lp.crop_id
    WHERE ${sql.join(where, sql` AND `)}`
  const radius = f.near && f.radiusKm ? sql`WHERE distance_km <= ${f.radiusKm}` : sql``
  const order = f.near ? sql`ORDER BY distance_km ASC` : sql`ORDER BY price DESC`
  const res = (await d.db.execute(sql`SELECT * FROM (${inner}) q ${radius} ${order} LIMIT ${f.limit ?? 50}`)) as unknown as { rows: PriceRow[] }
  return res.rows.map((r) => ({
    mandiId: r.mandi_id, mandi: r.mandi_name, location: `${r.district}, ${r.state}`, cropId: r.crop_id, crop: r.crop_name,
    price: Number(r.price), minPrice: num(r.min_price), maxPrice: num(r.max_price), arrivalsQtl: num(r.arrivals_qtl),
    priceHistory: (r.history ?? []).map(Number), lastUpdated: new Date(r.observed_at).toISOString(),
    distanceKm: r.distance_km == null ? undefined : Math.round(Number(r.distance_km) * 10) / 10,
  }))
}

export async function recordPrice(d: Deps, actor: { id: string; role: string }, mandiId: string,
  input: { cropId: string; price: number; minPrice?: number; maxPrice?: number; arrivalsQtl?: number; confirmLargeChange?: boolean }) {
  if (actor.role === 'mandi_admin') {
    const [a] = await d.db.select().from(mandiAdmins).where(and(eq(mandiAdmins.userId, actor.id), eq(mandiAdmins.mandiId, mandiId)))
    if (!a) throw forbidden('You are not assigned to this mandi')
  }
  return d.db.transaction(async (tx) => {
    const [m] = await tx.select({ id: mandis.id }).from(mandis).where(eq(mandis.id, mandiId))
    if (!m) throw notFound('Mandi')
    // serialize concurrent updates for the same series so "previous price" is well-defined
    await tx.execute(sql`select pg_advisory_xact_lock(hashtext(${mandiId + ':' + input.cropId}))`)
    const [prev] = await tx.select({ price: priceObservations.price }).from(priceObservations)
      .where(and(eq(priceObservations.mandiId, mandiId), eq(priceObservations.cropId, input.cropId)))
      .orderBy(desc(priceObservations.observedAt), desc(priceObservations.id)).limit(1)
    const prevPrice = prev ? Number(prev.price) : null
    const pct = prevPrice ? ((input.price - prevPrice) / prevPrice) * 100 : 0
    if (prevPrice && Math.abs(pct) > d.cfg.MAX_PRICE_JUMP_PERCENT && !input.confirmLargeChange) {
      throw new AppError(422, 'price_change_too_large',
        `This is a ${pct.toFixed(1)}% change from ₹${prevPrice}. Re-send with confirmLargeChange=true if it is correct.`)
    }
    await tx.insert(mandiCrops).values({ mandiId, cropId: input.cropId }).onConflictDoNothing()
    const [obs] = await tx.insert(priceObservations).values({
      mandiId, cropId: input.cropId, price: String(input.price), minPrice: input.minPrice?.toString(), maxPrice: input.maxPrice?.toString(),
      arrivalsQtl: input.arrivalsQtl?.toString(), recordedBy: actor.id,
    }).returning()
    let alert: typeof priceAlerts.$inferSelect | undefined
    if (prevPrice && pct !== 0 && Math.abs(pct) >= d.cfg.ALERT_THRESHOLD_PERCENT) {
      ;[alert] = await tx.insert(priceAlerts).values({
        cropId: input.cropId, mandiId, oldPrice: String(prevPrice), newPrice: String(input.price),
        changePercent: pct.toFixed(2), direction: pct > 0 ? 'up' : 'down',
      }).returning()
      await publish(tx, { type: 'price_alert', data: { id: alert!.id, mandiId, cropId: input.cropId, changePercent: Number(pct.toFixed(2)), direction: alert!.direction } })
    }
    await audit(tx, actor.id, 'price.recorded', 'mandi', mandiId, { cropId: input.cropId, price: input.price, prev: prevPrice })
    return { observationId: obs!.id, price: input.price, previousPrice: prevPrice, alertCreated: !!alert }
  })
}

export async function advisory(d: Deps, cropId: string, mandiId?: string) {
  const [best] = await listPrices(d, { cropId, mandiId, limit: 1 })
  if (!best) throw notFound('Price data for this crop')
  const h = best.priceHistory
  const base = h.length >= 4 ? h[h.length - 4]! : h[0]
  const change3d = base && h.length > 1 ? ((best.price - base) / base) * 100 : 0
  const [msp] = await d.db.select().from(mspRates).where(eq(mspRates.cropId, cropId)).orderBy(desc(mspRates.effectiveFrom)).limit(1)
  const mspPrice = msp ? Number(msp.price) : null
  const recommendation = change3d > 5 ? 'wait' : 'sell_now'
  return {
    cropId, mandiId: best.mandiId, mandi: best.mandi, latestPrice: best.price,
    change3dPercent: Math.round(change3d * 10) / 10, recommendation,
    mspPrice, belowMsp: mspPrice != null && best.price < mspPrice,
    rule: 'wait if the last 3 daily closes rose more than 5%, otherwise sell now',
  }
}

export function marketRoutes(d: Deps, auth: MiddlewareHandler<AppEnv>) {
  const r = new Hono<AppEnv>()

  r.get('/crops', async (c) => c.json({ items: await d.db.select().from(crops).orderBy(crops.name) }))

  r.get('/mandis', v('query', z.object({
    state: z.string().max(80).optional(),
    near: z.string().regex(/^-?\d+(\.\d+)?,-?\d+(\.\d+)?$/).optional(),
    radiusKm: z.coerce.number().positive().max(2000).optional(),
  })), async (c) => {
    const q = c.req.valid('query')
    const near = q.near?.split(',').map(Number) as [number, number] | undefined
    const dist = near ? sql<number>`(6371 * acos(least(1, greatest(-1, cos(radians(${near[0]})) * cos(radians(${mandis.latitude})) * cos(radians(${mandis.longitude}) - radians(${near[1]})) + sin(radians(${near[0]})) * sin(radians(${mandis.latitude}))))))` : sql<number | null>`NULL`
    const rows = await d.db.select({ id: mandis.id, name: mandis.name, district: mandis.district, state: mandis.state,
      latitude: mandis.latitude, longitude: mandis.longitude, distanceKm: dist })
      .from(mandis).where(q.state ? sql`lower(${mandis.state}) = lower(${q.state})` : undefined)
      .orderBy(near ? dist : mandis.name).limit(200)
    const items = rows.filter((m) => !(near && q.radiusKm && m.distanceKm != null && m.distanceKm > q.radiusKm))
      .map((m) => ({ ...m, distanceKm: m.distanceKm == null ? undefined : Math.round(Number(m.distanceKm) * 10) / 10 }))
    return c.json({ items })
  })

  r.get('/prices', v('query', z.object({
    crop: z.string().max(40).optional(), mandiId: uuid.optional(), state: z.string().max(80).optional(),
    near: z.string().regex(/^-?\d+(\.\d+)?,-?\d+(\.\d+)?$/).optional(), radiusKm: z.coerce.number().positive().max(2000).optional(),
    limit: z.coerce.number().int().min(1).max(200).default(50),
  })), async (c) => {
    const q = c.req.valid('query')
    return c.json({ items: await listPrices(d, { cropId: q.crop, mandiId: q.mandiId, state: q.state, limit: q.limit,
      near: q.near?.split(',').map(Number) as [number, number] | undefined, radiusKm: q.radiusKm }) })
  })

  r.get('/prices/history', v('query', z.object({ mandiId: uuid, crop: z.string().max(40), days: z.coerce.number().int().min(1).max(365).default(30) })), async (c) => {
    const q = c.req.valid('query')
    const res = (await d.db.execute(sql`
      SELECT day::text AS day, price FROM (
        SELECT DISTINCT ON (x.day) x.day, x.price FROM (
          SELECT (observed_at AT TIME ZONE 'Asia/Kolkata')::date AS day, price, observed_at, id FROM price_observations
          WHERE mandi_id = ${q.mandiId} AND crop_id = ${q.crop} AND observed_at >= now() - make_interval(days => ${q.days})
        ) x ORDER BY x.day DESC, x.observed_at DESC, x.id DESC) t ORDER BY day`)) as unknown as { rows: { day: string; price: string }[] }
    return c.json({ items: res.rows.map((r) => ({ day: r.day, price: Number(r.price) })) })
  })

  r.get('/price-alerts', v('query', z.object({ limit: z.coerce.number().int().min(1).max(100).default(20) })), async (c) => {
    const rows = await d.db.select({ id: priceAlerts.id, cropId: priceAlerts.cropId, crop: crops.name, mandiId: priceAlerts.mandiId, mandi: mandis.name,
      changePercent: priceAlerts.changePercent, direction: priceAlerts.direction, createdAt: priceAlerts.createdAt })
      .from(priceAlerts).innerJoin(crops, eq(crops.id, priceAlerts.cropId)).innerJoin(mandis, eq(mandis.id, priceAlerts.mandiId))
      .orderBy(desc(priceAlerts.createdAt), desc(priceAlerts.id)).limit(c.req.valid('query').limit)
    return c.json({ items: rows.map((a) => ({ ...a, changePercent: Number(a.changePercent) })) })
  })

  r.get('/advisory', v('query', z.object({ crop: z.string().max(40), mandiId: uuid.optional() })), async (c) => {
    const q = c.req.valid('query')
    return c.json(await advisory(d, q.crop, q.mandiId))
  })

  r.post('/mandis/:id/prices', auth, requireRole('mandi_admin', 'admin'), v('param', z.object({ id: uuid })), v('json', z.object({
    cropId: z.string().max(40), price, minPrice: price.optional(), maxPrice: price.optional(),
    arrivalsQtl: z.coerce.number().min(0).max(1e8).optional(), confirmLargeChange: z.boolean().optional(),
  })), async (c) => c.json(await recordPrice(d, me(c), c.req.valid('param').id, c.req.valid('json')), 201))

  return r
}
