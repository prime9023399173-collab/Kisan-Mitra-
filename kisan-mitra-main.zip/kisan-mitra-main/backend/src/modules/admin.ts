import { and, desc, eq } from 'drizzle-orm'
import { Hono } from 'hono'
import { z } from 'zod'
import type { AppEnv, Deps } from '../deps'
import { auditLog, buyers, mandiAdmins, mandis, mspRates, users } from '../db/schema'
import { me, requireRole, v } from '../http'
import { audit, notify } from '../lib/audit'
import { AppError, notFound } from '../lib/errors'
import { normalizePhone } from '../lib/util'

const uuid = z.string().uuid()

export function adminRoutes(d: Deps) {
  const r = new Hono<AppEnv>()
  r.use('*', requireRole('admin'))

  r.post('/users', v('json', z.object({ phone: z.string().min(5).max(20), name: z.string().trim().min(2).max(120), role: z.enum(['mandi_admin', 'admin']) })), async (c) => {
    const b = c.req.valid('json')
    const [u] = await d.db.insert(users).values({ phone: normalizePhone(b.phone), name: b.name, role: b.role }).returning({ id: users.id })
    await audit(d.db, me(c).id, 'user.created', 'user', u!.id, { role: b.role })
    return c.json({ id: u!.id }, 201)
  })

  r.patch('/users/:id', v('param', z.object({ id: uuid })), v('json', z.object({ status: z.enum(['active', 'suspended']) })), async (c) => {
    const id = c.req.valid('param').id
    if (id === me(c).id) throw new AppError(409, 'invalid_state', 'You cannot change your own status')
    const res = await d.db.update(users).set({ status: c.req.valid('json').status }).where(eq(users.id, id)).returning({ id: users.id })
    if (!res.length) throw notFound('User')
    await audit(d.db, me(c).id, 'user.status', 'user', id, c.req.valid('json'))
    return c.json({ ok: true })
  })

  r.post('/mandis', v('json', z.object({
    name: z.string().trim().min(2).max(120), district: z.string().trim().min(2).max(120), state: z.string().trim().min(2).max(120),
    latitude: z.number().min(-90).max(90).optional(), longitude: z.number().min(-180).max(180).optional(),
  })), async (c) => {
    const [m] = await d.db.insert(mandis).values(c.req.valid('json')).returning()
    await audit(d.db, me(c).id, 'mandi.created', 'mandi', m!.id)
    return c.json(m, 201)
  })

  r.put('/mandis/:id/admins/:userId', v('param', z.object({ id: uuid, userId: uuid })), async (c) => {
    const { id, userId } = c.req.valid('param')
    const [u] = await d.db.select({ role: users.role }).from(users).where(eq(users.id, userId))
    if (!u) throw notFound('User')
    if (u.role !== 'mandi_admin') throw new AppError(422, 'invalid_role', 'User must have the mandi_admin role')
    await d.db.insert(mandiAdmins).values({ userId, mandiId: id }).onConflictDoNothing()
    await audit(d.db, me(c).id, 'mandi.admin_assigned', 'mandi', id, { userId })
    return c.json({ ok: true })
  })

  r.post('/buyers/:id/verify', v('param', z.object({ id: uuid })), v('json', z.object({ verified: z.boolean() })), async (c) => {
    const { verified } = c.req.valid('json'), id = c.req.valid('param').id
    await d.db.transaction(async (tx) => {
      const res = await tx.update(buyers).set({ verified, verifiedAt: verified ? new Date() : null, verifiedBy: verified ? me(c).id : null })
        .where(eq(buyers.userId, id)).returning({ id: buyers.userId })
      if (!res.length) throw notFound('Buyer')
      await notify(tx, id, 'buyer.verification', { verified })
      await audit(tx, me(c).id, 'buyer.verification', 'buyer', id, { verified })
    })
    return c.json({ ok: true })
  })

  r.put('/msp', v('json', z.object({ cropId: z.string().max(40), effectiveFrom: z.string().regex(/^\d{4}-\d{2}-\d{2}$/), season: z.string().trim().min(2).max(40), price: z.coerce.number().positive().max(999999) })), async (c) => {
    const b = c.req.valid('json')
    await d.db.insert(mspRates).values({ ...b, price: String(b.price) }).onConflictDoUpdate({ target: [mspRates.cropId, mspRates.effectiveFrom], set: { price: String(b.price), season: b.season } })
    await audit(d.db, me(c).id, 'msp.set', 'crop', b.cropId, b)
    return c.json({ ok: true })
  })

  r.get('/audit', v('query', z.object({ entity: z.string().max(40).optional(), entityId: z.string().max(80).optional(), limit: z.coerce.number().int().min(1).max(200).default(50) })), async (c) => {
    const q = c.req.valid('query')
    const rows = await d.db.select().from(auditLog).where(and(q.entity ? eq(auditLog.entity, q.entity) : undefined, q.entityId ? eq(auditLog.entityId, q.entityId) : undefined))
      .orderBy(desc(auditLog.id)).limit(q.limit)
    return c.json({ items: rows })
  })
  return r
}
