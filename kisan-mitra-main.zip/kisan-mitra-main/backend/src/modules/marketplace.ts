import { and, desc, eq, inArray, or, sql, type SQL } from 'drizzle-orm'
import { Hono, type MiddlewareHandler } from 'hono'
import { z } from 'zod'
import type { AppEnv, AuthUser, Deps } from '../deps'
import type { Executor } from '../db/client'
import { buyerRatings, buyers, crops, farmers, lots, mandiAdmins, offers, transactions, users } from '../db/schema'
import { me, requireRole, v } from '../http'
import { audit, notify } from '../lib/audit'
import { AppError, conflict, forbidden, notFound } from '../lib/errors'
import { cursorWhere, num, pageQuery, paginate } from '../lib/util'

const uuid = z.string().uuid()
const idParam = v('param', z.object({ id: uuid }))

const lotSelect = {
  id: lots.id, farmerId: lots.farmerId, cropId: lots.cropId, crop: crops.name, quantity: lots.quantityQtl, grade: lots.grade,
  status: lots.status, askingPrice: lots.askingPrice, mandiId: lots.mandiId, notes: lots.notes, createdAt: lots.createdAt,
  farmerName: users.name, village: farmers.village, district: farmers.district,
}
const lotQuery = (x: Executor) => x.select(lotSelect).from(lots)
  .innerJoin(crops, eq(crops.id, lots.cropId)).innerJoin(farmers, eq(farmers.userId, lots.farmerId)).innerJoin(users, eq(users.id, lots.farmerId))
const lotDto = (r: Awaited<ReturnType<ReturnType<typeof lotQuery>['limit']>>[number]) =>
  ({ ...r, quantity: Number(r.quantity), askingPrice: num(r.askingPrice) })

const offerSelect = {
  id: offers.id, lotId: offers.lotId, buyerId: offers.buyerId, price: offers.pricePerQtl, status: offers.status, message: offers.message,
  createdAt: offers.createdAt, decidedAt: offers.decidedAt, buyerName: buyers.businessName, buyerVerified: buyers.verified,
  ratingSum: buyers.ratingSum, ratingCount: buyers.ratingCount,
}
const offerQuery = (x: Executor) => x.select(offerSelect).from(offers).innerJoin(buyers, eq(buyers.userId, offers.buyerId))
const offerDto = (r: Awaited<ReturnType<ReturnType<typeof offerQuery>['limit']>>[number]) => {
  const { ratingSum, ratingCount, ...o } = r
  return { ...o, price: Number(o.price), buyerRating: ratingCount ? Math.round((Number(ratingSum) / ratingCount) * 10) / 10 : null }
}

const txnSelect = {
  id: transactions.id, offerId: transactions.offerId, lotId: transactions.lotId, farmerId: transactions.farmerId, buyerId: transactions.buyerId,
  quantity: transactions.quantityQtl, pricePerQtl: transactions.pricePerQtl, amountTotal: transactions.amountTotal,
  paymentStatus: transactions.paymentStatus, logisticsStatus: transactions.logisticsStatus, paymentRef: transactions.paymentRef,
  pickupAt: transactions.pickupAt, vehicleNo: transactions.vehicleNo, paidAt: transactions.paidAt, deliveredAt: transactions.deliveredAt,
  createdAt: transactions.createdAt, crop: crops.name, lotMandiId: lots.mandiId,
}
const txnQuery = (x: Executor) => x.select(txnSelect).from(transactions)
  .innerJoin(lots, eq(lots.id, transactions.lotId)).innerJoin(crops, eq(crops.id, lots.cropId))
const txnDto = (r: Awaited<ReturnType<ReturnType<typeof txnQuery>['limit']>>[number]) => {
  const { lotMandiId, ...t } = r
  return { ...t, quantity: Number(t.quantity), pricePerQtl: Number(t.pricePerQtl), amountTotal: Number(t.amountTotal) }
}

const mandiIdsOf = (x: Executor, userId: string) => x.select({ id: mandiAdmins.mandiId }).from(mandiAdmins).where(eq(mandiAdmins.userId, userId))

// ───────── lots ─────────
export async function createLot(d: Deps, user: AuthUser, i: { cropId: string; quantity: number; grade: 'A' | 'B' | 'C'; askingPrice?: number; mandiId?: string; notes?: string }) {
  return d.db.transaction(async (tx) => {
    const [f] = await tx.select().from(farmers).where(eq(farmers.userId, user.id))
    if (!f) throw forbidden('Only farmers can list produce')
    const [lot] = await tx.insert(lots).values({
      farmerId: user.id, cropId: i.cropId, quantityQtl: String(i.quantity), grade: i.grade,
      askingPrice: i.askingPrice?.toString(), mandiId: i.mandiId ?? f.preferredMandiId, notes: i.notes,
    }).returning({ id: lots.id })
    await audit(tx, user.id, 'lot.created', 'lot', lot!.id, { cropId: i.cropId, quantity: i.quantity })
    const [row] = await lotQuery(tx).where(eq(lots.id, lot!.id))
    return lotDto(row!)
  })
}

async function loadLotFor(d: Deps, user: AuthUser, id: string) {
  const [row] = await lotQuery(d.db).where(eq(lots.id, id))
  if (!row) throw notFound('Lot')
  if (user.role === 'farmer' && row.farmerId !== user.id) throw notFound('Lot')
  if (user.role === 'buyer' && row.status !== 'listed') {
    const [o] = await d.db.select({ id: offers.id }).from(offers).where(and(eq(offers.lotId, id), eq(offers.buyerId, user.id))).limit(1)
    if (!o) throw notFound('Lot')
  }
  return row
}

export async function cancelLot(d: Deps, user: AuthUser, id: string) {
  return d.db.transaction(async (tx) => {
    const [lot] = await tx.select().from(lots).where(eq(lots.id, id)).for('update')
    if (!lot || (user.role !== 'admin' && lot.farmerId !== user.id)) throw notFound('Lot')
    if (lot.status !== 'listed') throw conflict('lot_not_listed', 'Only listed lots can be cancelled')
    const rejected = await tx.update(offers).set({ status: 'rejected', decidedAt: new Date() })
      .where(and(eq(offers.lotId, id), eq(offers.status, 'pending'))).returning({ id: offers.id, buyerId: offers.buyerId })
    await tx.update(lots).set({ status: 'cancelled' }).where(eq(lots.id, id))
    for (const o of rejected) await notify(tx, o.buyerId, 'offer.rejected', { offerId: o.id, lotId: id, reason: 'lot_cancelled' })
    await audit(tx, user.id, 'lot.cancelled', 'lot', id)
    return { id, status: 'cancelled' as const }
  })
}

// ───────── offers ─────────
export async function createOffer(d: Deps, user: AuthUser, lotId: string, i: { price: number; message?: string }) {
  return d.db.transaction(async (tx) => {
    const [lot] = await tx.select().from(lots).where(eq(lots.id, lotId)).for('update')
    if (!lot) throw notFound('Lot')
    if (lot.status !== 'listed') throw conflict('lot_not_listed', 'This lot is no longer available')
    const [b] = await tx.select().from(buyers).where(eq(buyers.userId, user.id))
    if (!b) throw forbidden('Only buyers can make offers')
    if (d.cfg.REQUIRE_VERIFIED_BUYERS && !b.verified) throw new AppError(403, 'buyer_not_verified', 'Your business must be verified before you can make offers')
    const [dup] = await tx.select({ id: offers.id }).from(offers).where(and(eq(offers.lotId, lotId), eq(offers.buyerId, user.id), eq(offers.status, 'pending')))
    if (dup) throw conflict('offer_exists', 'You already have an open offer on this lot. Withdraw it first.')
    const [o] = await tx.insert(offers).values({ lotId, buyerId: user.id, pricePerQtl: String(i.price), message: i.message }).returning({ id: offers.id })
    await notify(tx, lot.farmerId, 'offer.received', { offerId: o!.id, lotId, price: i.price })
    await audit(tx, user.id, 'offer.created', 'offer', o!.id, { lotId, price: i.price })
    const [row] = await offerQuery(tx).where(eq(offers.id, o!.id))
    return offerDto(row!)
  })
}

/** Locks lot first, then offer - same order everywhere to stay deadlock-free. */
async function lockLotAndOffer(tx: Executor, offerId: string) {
  const [probe] = await tx.select({ lotId: offers.lotId }).from(offers).where(eq(offers.id, offerId))
  if (!probe) throw notFound('Offer')
  const [lot] = await tx.select().from(lots).where(eq(lots.id, probe.lotId)).for('update')
  const [offer] = await tx.select().from(offers).where(eq(offers.id, offerId)).for('update')
  return { lot: lot!, offer: offer! }
}

export async function acceptOffer(d: Deps, user: AuthUser, offerId: string) {
  return d.db.transaction(async (tx) => {
    const { lot, offer } = await lockLotAndOffer(tx, offerId)
    if (user.role !== 'admin' && lot.farmerId !== user.id) throw notFound('Offer')
    if (offer.status !== 'pending') throw conflict('offer_not_pending', `This offer is already ${offer.status}`)
    if (lot.status !== 'listed') throw conflict('lot_not_listed', 'This lot is no longer available')
    const now = new Date()
    await tx.update(offers).set({ status: 'accepted', decidedAt: now }).where(eq(offers.id, offer.id))
    const rejected = await tx.update(offers).set({ status: 'rejected', decidedAt: now })
      .where(and(eq(offers.lotId, lot.id), eq(offers.status, 'pending'))).returning({ id: offers.id, buyerId: offers.buyerId })
    await tx.update(lots).set({ status: 'matched' }).where(eq(lots.id, lot.id))
    const [t] = await tx.insert(transactions).values({
      offerId: offer.id, lotId: lot.id, farmerId: lot.farmerId, buyerId: offer.buyerId,
      quantityQtl: lot.quantityQtl, pricePerQtl: offer.pricePerQtl,
    }).returning({ id: transactions.id })
    await notify(tx, offer.buyerId, 'offer.accepted', { offerId: offer.id, lotId: lot.id, transactionId: t!.id })
    for (const o of rejected) await notify(tx, o.buyerId, 'offer.rejected', { offerId: o.id, lotId: lot.id, reason: 'other_offer_accepted' })
    await audit(tx, user.id, 'offer.accepted', 'offer', offer.id, { transactionId: t!.id, rejected: rejected.length })
    const [row] = await txnQuery(tx).where(eq(transactions.id, t!.id))
    return txnDto(row!)
  })
}

async function decideOffer(d: Deps, user: AuthUser, offerId: string, to: 'rejected' | 'withdrawn') {
  return d.db.transaction(async (tx) => {
    const { lot, offer } = await lockLotAndOffer(tx, offerId)
    const owner = to === 'rejected' ? lot.farmerId : offer.buyerId
    if (user.role !== 'admin' && owner !== user.id) throw notFound('Offer')
    if (offer.status !== 'pending') throw conflict('offer_not_pending', `This offer is already ${offer.status}`)
    await tx.update(offers).set({ status: to, decidedAt: new Date() }).where(eq(offers.id, offer.id))
    if (to === 'rejected') await notify(tx, offer.buyerId, 'offer.rejected', { offerId: offer.id, lotId: lot.id, reason: 'declined' })
    else await notify(tx, lot.farmerId, 'offer.withdrawn', { offerId: offer.id, lotId: lot.id })
    await audit(tx, user.id, `offer.${to}`, 'offer', offer.id)
    const [row] = await offerQuery(tx).where(eq(offers.id, offer.id))
    return offerDto(row!)
  })
}

// ───────── transactions ─────────
type TxnRow = Awaited<ReturnType<ReturnType<typeof txnQuery>['limit']>>[number]

async function loadTxn(d: Deps | { db: Executor }, user: AuthUser, id: string): Promise<TxnRow> {
  const [t] = await txnQuery(d.db).where(eq(transactions.id, id))
  if (!t) throw notFound('Transaction')
  if (!(await canSeeTxn(d.db, user, t))) throw notFound('Transaction')
  return t
}
async function canSeeTxn(x: Executor, user: AuthUser, t: TxnRow) {
  if (user.role === 'admin') return true
  if (user.role === 'farmer') return t.farmerId === user.id
  if (user.role === 'buyer') return t.buyerId === user.id
  if (!t.lotMandiId) return false
  const [m] = await x.select().from(mandiAdmins).where(and(eq(mandiAdmins.userId, user.id), eq(mandiAdmins.mandiId, t.lotMandiId)))
  return !!m
}
const isBuyerSide = (user: AuthUser, t: TxnRow) => user.role === 'admin' || user.role === 'mandi_admin' || (user.role === 'buyer' && t.buyerId === user.id)

const nextLogistics = { pickup_scheduled: 'in_transit', in_transit: 'delivered' } as const

export async function updateLogistics(d: Deps, user: AuthUser, id: string, to: 'in_transit' | 'delivered', extra: { vehicleNo?: string; pickupAt?: Date }) {
  return d.db.transaction(async (tx) => {
    const t = await loadTxn({ db: tx }, user, id)
    if (!isBuyerSide(user, t)) throw forbidden('Only the buyer or mandi staff can update logistics')
    await tx.select({ id: transactions.id }).from(transactions).where(eq(transactions.id, id)).for('update')
    const [cur] = await tx.select({ l: transactions.logisticsStatus, p: transactions.paymentStatus }).from(transactions).where(eq(transactions.id, id))
    if (cur!.l === to) return txnDto((await txnQuery(tx).where(eq(transactions.id, id)))[0]!)
    if (nextLogistics[cur!.l as keyof typeof nextLogistics] !== to) throw conflict('invalid_state', `Cannot move from ${cur!.l} to ${to}`)
    if (to === 'in_transit' && cur!.p === 'pending') throw conflict('escrow_not_funded', 'Escrow must be funded before the produce is picked up')
    await tx.update(transactions).set({
      logisticsStatus: to, vehicleNo: extra.vehicleNo ?? undefined, pickupAt: extra.pickupAt ?? undefined,
      deliveredAt: to === 'delivered' ? new Date() : undefined,
    }).where(eq(transactions.id, id))
    if (to === 'in_transit') await tx.update(lots).set({ status: 'pickedup' }).where(and(eq(lots.id, t.lotId), eq(lots.status, 'matched')))
    await notify(tx, t.farmerId, 'transaction.logistics', { transactionId: id, status: to })
    await audit(tx, user.id, 'transaction.logistics', 'transaction', id, { to })
    return txnDto((await txnQuery(tx).where(eq(transactions.id, id)))[0]!)
  })
}

export async function updatePayment(d: Deps, user: AuthUser, id: string, to: 'in_escrow' | 'paid' | 'refunded', paymentRef?: string) {
  return d.db.transaction(async (tx) => {
    const t = await loadTxn({ db: tx }, user, id)
    if (to === 'refunded' ? user.role !== 'admin' : !(user.role === 'admin' || (user.role === 'buyer' && t.buyerId === user.id))) {
      throw forbidden(to === 'refunded' ? 'Only an admin can refund' : 'Only the buyer can fund or release payment')
    }
    await tx.select({ id: transactions.id }).from(transactions).where(eq(transactions.id, id)).for('update')
    const [cur] = await tx.select({ l: transactions.logisticsStatus, p: transactions.paymentStatus }).from(transactions).where(eq(transactions.id, id))
    if (cur!.p === to) return txnDto((await txnQuery(tx).where(eq(transactions.id, id)))[0]!)
    const ok = (cur!.p === 'pending' && to === 'in_escrow') || (cur!.p === 'in_escrow' && (to === 'paid' || to === 'refunded'))
    if (!ok) throw conflict('invalid_state', `Cannot move payment from ${cur!.p} to ${to}`)
    if (to === 'paid' && cur!.l !== 'delivered') throw conflict('not_delivered', 'Payment can only be released after delivery')
    await tx.update(transactions).set({ paymentStatus: to, paymentRef: paymentRef ?? undefined, paidAt: to === 'paid' ? new Date() : undefined }).where(eq(transactions.id, id))
    if (to === 'paid') await tx.update(lots).set({ status: 'paid' }).where(eq(lots.id, t.lotId))
    if (to === 'refunded') await tx.update(lots).set({ status: 'cancelled' }).where(and(eq(lots.id, t.lotId), inArray(lots.status, ['matched', 'pickedup'])))
    await notify(tx, t.farmerId, 'transaction.payment', { transactionId: id, status: to })
    if (user.id !== t.buyerId) await notify(tx, t.buyerId, 'transaction.payment', { transactionId: id, status: to })
    await audit(tx, user.id, 'transaction.payment', 'transaction', id, { to })
    return txnDto((await txnQuery(tx).where(eq(transactions.id, id)))[0]!)
  })
}

export async function rateBuyer(d: Deps, user: AuthUser, id: string, stars: number, comment?: string) {
  return d.db.transaction(async (tx) => {
    const t = await loadTxn({ db: tx }, user, id)
    if (user.role !== 'farmer' || t.farmerId !== user.id) throw forbidden('Only the farmer on this deal can rate the buyer')
    if (t.paymentStatus !== 'paid') throw conflict('not_paid', 'You can rate the buyer once payment is complete')
    const ins = await tx.insert(buyerRatings).values({ transactionId: id, buyerId: t.buyerId, stars, comment }).onConflictDoNothing().returning({ id: buyerRatings.transactionId })
    if (!ins.length) throw conflict('already_rated', 'You already rated this deal')
    await tx.update(buyers).set({ ratingSum: sql`${buyers.ratingSum} + ${stars}`, ratingCount: sql`${buyers.ratingCount} + 1` }).where(eq(buyers.userId, t.buyerId))
    return { ok: true }
  })
}

// ───────── routes ─────────
export function marketplaceRoutes(d: Deps, idem: MiddlewareHandler<AppEnv>) {
  const r = new Hono<AppEnv>()

  r.post('/lots', idem, requireRole('farmer'), v('json', z.object({
    cropId: z.string().max(40), quantity: z.coerce.number().positive().max(100000), grade: z.enum(['A', 'B', 'C']),
    askingPrice: z.coerce.number().positive().max(999999).optional(), mandiId: uuid.optional(), notes: z.string().trim().max(1000).optional(),
  })), async (c) => c.json(await createLot(d, me(c), c.req.valid('json')), 201))

  r.get('/lots', v('query', pageQuery.extend({
    crop: z.string().max(40).optional(), status: z.enum(['listed', 'matched', 'pickedup', 'paid', 'cancelled']).optional(), grade: z.enum(['A', 'B', 'C']).optional(),
  })), async (c) => {
    const u = me(c), q = c.req.valid('query')
    const where: (SQL | undefined)[] = [cursorWhere(q.cursor, lots.createdAt, lots.id)]
    if (q.crop) where.push(eq(lots.cropId, q.crop))
    if (q.grade) where.push(eq(lots.grade, q.grade))
    if (q.status) where.push(eq(lots.status, q.status))
    if (u.role === 'farmer') where.push(eq(lots.farmerId, u.id))
    if (u.role === 'buyer') where.push(or(eq(lots.status, 'listed'), sql`exists (select 1 from ${offers} where ${offers.lotId} = ${lots.id} and ${offers.buyerId} = ${u.id})`))
    if (u.role === 'mandi_admin') where.push(sql`${lots.mandiId} in (${mandiIdsOf(d.db, u.id)})`)
    const rows = await lotQuery(d.db).where(and(...where)).orderBy(desc(lots.createdAt), desc(lots.id)).limit(q.limit + 1)
    const p = paginate(rows, q.limit)
    return c.json({ items: p.items.map(lotDto), nextCursor: p.nextCursor })
  })

  r.get('/lots/:id', idParam, async (c) => c.json(lotDto(await loadLotFor(d, me(c), c.req.valid('param').id))))
  r.post('/lots/:id/cancel', idem, requireRole('farmer', 'admin'), idParam, async (c) => c.json(await cancelLot(d, me(c), c.req.valid('param').id)))

  r.post('/lots/:id/offers', idem, requireRole('buyer'), idParam, v('json', z.object({
    price: z.coerce.number().positive().max(999999), message: z.string().trim().max(500).optional(),
  })), async (c) => c.json(await createOffer(d, me(c), c.req.valid('param').id, c.req.valid('json')), 201))

  r.get('/lots/:id/offers', idParam, async (c) => {
    const u = me(c), lot = await loadLotFor(d, u, c.req.valid('param').id)
    const rows = await offerQuery(d.db).where(and(eq(offers.lotId, lot.id), u.role === 'buyer' ? eq(offers.buyerId, u.id) : undefined)).orderBy(desc(offers.pricePerQtl), desc(offers.createdAt))
    return c.json({ items: rows.map(offerDto) })
  })

  r.get('/offers', v('query', pageQuery.extend({ status: z.enum(['pending', 'accepted', 'rejected', 'withdrawn']).optional(), lotId: uuid.optional() })), async (c) => {
    const u = me(c), q = c.req.valid('query')
    const where: (SQL | undefined)[] = [cursorWhere(q.cursor, offers.createdAt, offers.id)]
    if (q.status) where.push(eq(offers.status, q.status))
    if (q.lotId) where.push(eq(offers.lotId, q.lotId))
    if (u.role === 'buyer') where.push(eq(offers.buyerId, u.id))
    else if (u.role === 'farmer') where.push(sql`${offers.lotId} in (select ${lots.id} from ${lots} where ${lots.farmerId} = ${u.id})`)
    else if (u.role === 'mandi_admin') where.push(sql`${offers.lotId} in (select ${lots.id} from ${lots} where ${lots.mandiId} in (${mandiIdsOf(d.db, u.id)}))`)
    const rows = await offerQuery(d.db).where(and(...where)).orderBy(desc(offers.createdAt), desc(offers.id)).limit(q.limit + 1)
    const p = paginate(rows, q.limit)
    return c.json({ items: p.items.map(offerDto), nextCursor: p.nextCursor })
  })

  r.post('/offers/:id/accept', idem, requireRole('farmer', 'admin'), idParam, async (c) => c.json(await acceptOffer(d, me(c), c.req.valid('param').id)))
  r.post('/offers/:id/reject', idem, requireRole('farmer', 'admin'), idParam, async (c) => c.json(await decideOffer(d, me(c), c.req.valid('param').id, 'rejected')))
  r.post('/offers/:id/withdraw', idem, requireRole('buyer', 'admin'), idParam, async (c) => c.json(await decideOffer(d, me(c), c.req.valid('param').id, 'withdrawn')))

  r.get('/transactions', v('query', pageQuery), async (c) => {
    const u = me(c), q = c.req.valid('query')
    const where: (SQL | undefined)[] = [cursorWhere(q.cursor, transactions.createdAt, transactions.id)]
    if (u.role === 'farmer') where.push(eq(transactions.farmerId, u.id))
    if (u.role === 'buyer') where.push(eq(transactions.buyerId, u.id))
    if (u.role === 'mandi_admin') where.push(sql`${lots.mandiId} in (${mandiIdsOf(d.db, u.id)})`)
    const rows = await txnQuery(d.db).where(and(...where)).orderBy(desc(transactions.createdAt), desc(transactions.id)).limit(q.limit + 1)
    const p = paginate(rows, q.limit)
    return c.json({ items: p.items.map(txnDto), nextCursor: p.nextCursor })
  })

  r.get('/transactions/:id', idParam, async (c) => {
    const u = me(c), t = await loadTxn(d, u, c.req.valid('param').id)
    const [f] = await d.db.select({ name: users.name, phone: users.phone }).from(users).where(eq(users.id, t.farmerId))
    const [b] = await d.db.select({ name: buyers.businessName, phone: users.phone }).from(buyers).innerJoin(users, eq(users.id, buyers.userId)).where(eq(buyers.userId, t.buyerId))
    return c.json({ ...txnDto(t), farmer: f, buyer: b })
  })

  r.post('/transactions/:id/logistics', idem, idParam, v('json', z.object({
    status: z.enum(['in_transit', 'delivered']), vehicleNo: z.string().trim().max(20).optional(), pickupAt: z.coerce.date().optional(),
  })), async (c) => { const b = c.req.valid('json'); return c.json(await updateLogistics(d, me(c), c.req.valid('param').id, b.status, b)) })

  r.post('/transactions/:id/payment', idem, idParam, v('json', z.object({
    status: z.enum(['in_escrow', 'paid', 'refunded']), paymentRef: z.string().trim().max(100).optional(),
  })), async (c) => { const b = c.req.valid('json'); return c.json(await updatePayment(d, me(c), c.req.valid('param').id, b.status, b.paymentRef)) })

  r.post('/transactions/:id/rating', idem, idParam, v('json', z.object({ stars: z.coerce.number().int().min(1).max(5), comment: z.string().trim().max(500).optional() })),
    async (c) => c.json(await rateBuyer(d, me(c), c.req.valid('param').id, c.req.valid('json').stars, c.req.valid('json').comment), 201))

  return r
}
