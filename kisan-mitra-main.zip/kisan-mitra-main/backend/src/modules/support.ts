import { and, desc, eq, inArray, isNull, sql, type SQL } from 'drizzle-orm'
import { Hono } from 'hono'
import { streamSSE } from 'hono/streaming'
import { z } from 'zod'
import type { AppEnv, AuthUser, Deps } from '../deps'
import { buyerDemands, buyers, crops, grievances, lots, mandiAdmins, notifications, transactions } from '../db/schema'
import { me, requireRole, v } from '../http'
import { audit, notify } from '../lib/audit'
import { conflict, notFound } from '../lib/errors'
import { cursorWhere, num, pageQuery, paginate } from '../lib/util'

const uuid = z.string().uuid()
const idParam = v('param', z.object({ id: uuid }))

const grvSelect = {
  id: grievances.id, transactionId: grievances.transactionId, raisedBy: grievances.raisedBy, message: grievances.message, status: grievances.status,
  resolutionNote: grievances.resolutionNote, createdAt: grievances.createdAt, resolvedAt: grievances.resolvedAt,
}
const scopeSql = (u: AuthUser): SQL | undefined => {
  if (u.role === 'admin') return undefined
  if (u.role === 'mandi_admin') return sql`exists (select 1 from ${transactions} t join ${lots} l on l.id = t.lot_id join ${mandiAdmins} ma on ma.mandi_id = l.mandi_id
      where t.id = ${grievances.transactionId} and ma.user_id = ${u.id})`
  return sql`exists (select 1 from ${transactions} t where t.id = ${grievances.transactionId} and (t.farmer_id = ${u.id} or t.buyer_id = ${u.id}))`
}

export function supportRoutes(d: Deps) {
  const r = new Hono<AppEnv>()

  r.post('/grievances', v('json', z.object({ transactionId: uuid, message: z.string().trim().min(5).max(2000) })), async (c) => {
    const u = me(c), b = c.req.valid('json')
    const g = await d.db.transaction(async (tx) => {
      const [t] = await tx.select({ id: transactions.id, farmerId: transactions.farmerId, buyerId: transactions.buyerId, mandiId: lots.mandiId })
        .from(transactions).innerJoin(lots, eq(lots.id, transactions.lotId)).where(eq(transactions.id, b.transactionId))
      if (!t || (t.farmerId !== u.id && t.buyerId !== u.id)) throw notFound('Transaction')
      const [row] = await tx.insert(grievances).values({ transactionId: t.id, raisedBy: u.id, message: b.message }).returning(grvSelect)
      const other = t.farmerId === u.id ? t.buyerId : t.farmerId
      await notify(tx, other, 'grievance.raised', { grievanceId: row!.id, transactionId: t.id })
      if (t.mandiId) {
        const staff = await tx.select({ id: mandiAdmins.userId }).from(mandiAdmins).where(eq(mandiAdmins.mandiId, t.mandiId))
        for (const s of staff) await notify(tx, s.id, 'grievance.raised', { grievanceId: row!.id, transactionId: t.id })
      }
      await audit(tx, u.id, 'grievance.raised', 'grievance', row!.id, { transactionId: t.id })
      return row!
    })
    return c.json(g, 201)
  })

  r.get('/grievances', v('query', pageQuery.extend({ status: z.enum(['open', 'in_review', 'resolved']).optional(), transactionId: uuid.optional() })), async (c) => {
    const u = me(c), q = c.req.valid('query')
    const where = [cursorWhere(q.cursor, grievances.createdAt, grievances.id), scopeSql(u),
      q.status ? eq(grievances.status, q.status) : undefined, q.transactionId ? eq(grievances.transactionId, q.transactionId) : undefined]
    const rows = await d.db.select(grvSelect).from(grievances).where(and(...where)).orderBy(desc(grievances.createdAt), desc(grievances.id)).limit(q.limit + 1)
    const p = paginate(rows, q.limit)
    return c.json({ items: p.items, nextCursor: p.nextCursor })
  })

  r.patch('/grievances/:id', requireRole('mandi_admin', 'admin'), idParam, v('json', z.object({
    status: z.enum(['in_review', 'resolved']), resolutionNote: z.string().trim().min(3).max(2000).optional(),
  })), async (c) => {
    const u = me(c), b = c.req.valid('json')
    if (b.status === 'resolved' && !b.resolutionNote) throw conflict('resolution_note_required', 'Add a short note explaining the resolution')
    const out = await d.db.transaction(async (tx) => {
      const id = c.req.valid('param').id
      const [g] = await tx.select(grvSelect).from(grievances).where(and(eq(grievances.id, id), scopeSql(u))).for('update')
      if (!g) throw notFound('Grievance')
      const [row] = await tx.update(grievances).set({
        status: b.status, resolutionNote: b.resolutionNote ?? g.resolutionNote,
        resolvedBy: b.status === 'resolved' ? u.id : null, resolvedAt: b.status === 'resolved' ? new Date() : null,
      }).where(eq(grievances.id, id)).returning(grvSelect)
      await notify(tx, g.raisedBy, 'grievance.updated', { grievanceId: id, status: b.status })
      await audit(tx, u.id, 'grievance.updated', 'grievance', id, { status: b.status })
      return row!
    })
    return c.json(out)
  })

  const typeLabel = { institutional: 'Institutional Buyer', processor: 'Processor / Mill', fpo: 'Aggregator / FPO', retail: 'Retail Chain', trader: 'Trader' } as const

  r.get('/buyers', v('query', z.object({ crop: z.string().max(40).optional() })), async (c) => {
    const q = c.req.valid('query')
    const rows = await d.db.select({ id: buyers.userId, businessName: buyers.businessName, type: buyers.type, verified: buyers.verified,
      ratingSum: buyers.ratingSum, ratingCount: buyers.ratingCount }).from(buyers).where(eq(buyers.verified, true)).limit(200)
    const demands = rows.length ? await d.db.select({ buyerId: buyerDemands.buyerId, cropId: buyerDemands.cropId, crop: crops.name, quantity: buyerDemands.quantityQtl, maxPrice: buyerDemands.maxPrice })
      .from(buyerDemands).innerJoin(crops, eq(crops.id, buyerDemands.cropId))
      .where(and(eq(buyerDemands.active, true), inArray(buyerDemands.buyerId, rows.map((x) => x.id)), q.crop ? eq(buyerDemands.cropId, q.crop) : undefined)) : []
    const items = rows.map((b) => ({
      id: b.id, name: b.businessName, type: typeLabel[b.type], verified: b.verified,
      rating: b.ratingCount ? Math.round((Number(b.ratingSum) / b.ratingCount) * 10) / 10 : null,
      demand: demands.filter((x) => x.buyerId === b.id).map((x) => ({ cropId: x.cropId, crop: x.crop, quantity: Number(x.quantity), maxPrice: num(x.maxPrice) })),
    })).filter((b) => !q.crop || b.demand.length > 0)
    return c.json({ items })
  })

  r.get('/buyers/me/demands', requireRole('buyer'), async (c) => {
    const rows = await d.db.select().from(buyerDemands).where(eq(buyerDemands.buyerId, me(c).id))
    return c.json({ items: rows.map((x) => ({ cropId: x.cropId, quantity: Number(x.quantityQtl), maxPrice: num(x.maxPrice), active: x.active })) })
  })

  r.put('/buyers/me/demands', requireRole('buyer'), v('json', z.object({
    cropId: z.string().max(40), quantity: z.coerce.number().positive().max(1e8), maxPrice: z.coerce.number().positive().max(999999).optional(), active: z.boolean().default(true),
  })), async (c) => {
    const b = c.req.valid('json')
    const vals = { buyerId: me(c).id, cropId: b.cropId, quantityQtl: String(b.quantity), maxPrice: b.maxPrice?.toString() ?? null, active: b.active }
    await d.db.insert(buyerDemands).values(vals).onConflictDoUpdate({ target: [buyerDemands.buyerId, buyerDemands.cropId], set: { quantityQtl: vals.quantityQtl, maxPrice: vals.maxPrice, active: b.active } })
    return c.json({ ok: true })
  })

  r.get('/notifications', v('query', pageQuery.extend({ unread: z.enum(['true', 'false']).optional() })), async (c) => {
    const u = me(c), q = c.req.valid('query')
    const rows = await d.db.select().from(notifications)
      .where(and(eq(notifications.userId, u.id), cursorWhere(q.cursor, notifications.createdAt, notifications.id), q.unread === 'true' ? isNull(notifications.readAt) : undefined))
      .orderBy(desc(notifications.createdAt), desc(notifications.id)).limit(q.limit + 1)
    const p = paginate(rows, q.limit)
    const [{ n } = { n: 0 }] = await d.db.select({ n: sql<number>`count(*)::int` }).from(notifications).where(and(eq(notifications.userId, u.id), isNull(notifications.readAt)))
    return c.json({ items: p.items, nextCursor: p.nextCursor, unreadCount: n })
  })

  r.post('/notifications/read', v('json', z.object({ ids: z.array(uuid).max(100).optional(), all: z.boolean().optional() })), async (c) => {
    const u = me(c), b = c.req.valid('json')
    if (!b.all && !b.ids?.length) return c.json({ updated: 0 })
    const res = await d.db.update(notifications).set({ readAt: new Date() })
      .where(and(eq(notifications.userId, u.id), isNull(notifications.readAt), b.all ? undefined : inArray(notifications.id, b.ids!))).returning({ id: notifications.id })
    return c.json({ updated: res.length })
  })

  /** Server-Sent Events. Use fetch-based SSE (Authorization header) - EventSource cannot send headers. */
  r.get('/events', (c) => {
    const u = me(c)
    return streamSSE(c, async (stream) => {
      const unsub = d.bus.subscribe((e) => {
        if (e.userId && e.userId !== u.id) return
        void stream.writeSSE({ event: e.type, data: JSON.stringify(e.data ?? {}) }).catch(() => {})
      })
      stream.onAbort(unsub)
      await stream.writeSSE({ event: 'ready', data: '{}' })
      while (!stream.aborted) { await stream.sleep(25_000); await stream.writeSSE({ event: 'ping', data: '' }).catch(() => {}) }
      unsub()
    })
  })
  return r
}
