import { and, desc, eq, gt, isNull, sql } from 'drizzle-orm'
import { Hono } from 'hono'
import { jwtVerify, SignJWT } from 'jose'
import { z } from 'zod'
import type { MiddlewareHandler } from 'hono'
import type { AppEnv, AuthUser, Deps } from '../deps'
import { buyers, farmers, otpChallenges, refreshTokens, users } from '../db/schema'
import { me, v } from '../http'
import { AppError } from '../lib/errors'
import { hmac, normalizePhone, randomToken, safeEqual, sha256 } from '../lib/util'
import { audit } from '../lib/audit'

const ISS = 'kisan-mitra', AUD = 'km-api'
// loose length bounds here so normalizePhone() produces the friendly "invalid_phone" error
const phoneField = z.string().min(5).max(20)

export async function requestOtp(d: Deps, rawPhone: string) {
  const phone = normalizePhone(rawPhone)
  const since = new Date(Date.now() - 3600_000)
  const [{ n } = { n: 0 }] = await d.db.select({ n: sql<number>`count(*)::int` }).from(otpChallenges)
    .where(and(eq(otpChallenges.phone, phone), gt(otpChallenges.createdAt, since)))
  if (n >= d.cfg.OTP_MAX_PER_HOUR) throw new AppError(429, 'otp_rate_limited', 'Too many codes requested. Try again later.')
  const code = d.cfg.OTP_FIXED_CODE ?? String(Math.floor(100000 + Math.random() * 900000)).padStart(6, '0')
  await d.db.insert(otpChallenges).values({
    phone, codeHash: hmac(d.cfg.JWT_SECRET, `otp:${phone}:${code}`),
    expiresAt: new Date(Date.now() + d.cfg.OTP_TTL_SEC * 1000),
  })
  await d.otp.send(phone, code)
  return { expiresInSec: d.cfg.OTP_TTL_SEC }
}

export const registrationSchema = z.discriminatedUnion('role', [
  z.object({ role: z.literal('farmer'), name: z.string().trim().min(2).max(120),
    village: z.string().trim().min(2).max(120), district: z.string().trim().max(120).optional(), state: z.string().trim().max(120).optional() }),
  z.object({ role: z.literal('buyer'), name: z.string().trim().min(2).max(120),
    businessName: z.string().trim().min(2).max(160),
    type: z.enum(['institutional', 'processor', 'fpo', 'retail', 'trader']),
    gstin: z.string().trim().toUpperCase().regex(/^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z][1-9A-Z]Z[0-9A-Z]$/, 'Invalid GSTIN').optional() }),
])

export async function verifyOtp(d: Deps, rawPhone: string, code: string, registration: z.infer<typeof registrationSchema> | undefined, userAgent?: string) {
  const phone = normalizePhone(rawPhone)
  // Failed attempts must persist, so the outcome is decided inside the tx but errors are thrown after commit.
  const outcome = await d.db.transaction(async (tx) => {
    const [ch] = await tx.select().from(otpChallenges)
      .where(and(eq(otpChallenges.phone, phone), isNull(otpChallenges.consumedAt), gt(otpChallenges.expiresAt, new Date())))
      .orderBy(desc(otpChallenges.createdAt)).limit(1).for('update')
    if (!ch) return { err: new AppError(400, 'otp_invalid', 'Code is invalid or expired') }
    if (ch.attempts >= d.cfg.OTP_MAX_ATTEMPTS) return { err: new AppError(429, 'otp_locked', 'Too many wrong attempts. Request a new code.') }
    if (!safeEqual(hmac(d.cfg.JWT_SECRET, `otp:${phone}:${code}`), ch.codeHash)) {
      await tx.update(otpChallenges).set({ attempts: ch.attempts + 1 }).where(eq(otpChallenges.id, ch.id))
      return { err: new AppError(400, 'otp_invalid', 'Code is invalid or expired') }
    }
    let [user] = await tx.select().from(users).where(eq(users.phone, phone))
    if (!user) {
      // Correct code but no account yet: keep the code usable so the client can resubmit with registration details.
      if (!registration) return { err: new AppError(422, 'registration_required', 'New number: send name and role to register') }
      ;[user] = await tx.insert(users).values({ phone, role: registration.role, name: registration.name }).returning()
      if (registration.role === 'farmer') {
        await tx.insert(farmers).values({ userId: user!.id, village: registration.village, district: registration.district, state: registration.state })
      } else {
        await tx.insert(buyers).values({ userId: user!.id, businessName: registration.businessName, type: registration.type, gstin: registration.gstin })
      }
      await audit(tx, user!.id, 'user.registered', 'user', user!.id, { role: registration.role })
    }
    if (user!.status !== 'active') return { err: new AppError(403, 'account_suspended', 'This account is suspended') }
    await tx.update(otpChallenges).set({ consumedAt: new Date() }).where(eq(otpChallenges.id, ch.id))
    await tx.update(users).set({ lastLoginAt: new Date() }).where(eq(users.id, user!.id))
    return { user: user! }
  })
  if ('err' in outcome && outcome.err) throw outcome.err
  const user = (outcome as { user: typeof users.$inferSelect }).user
  const { _rowId, ...tokens } = await issueTokens(d, user, undefined, userAgent)
  void _rowId
  return { user: publicUser(user), ...tokens }
}

export const publicUser = (u: typeof users.$inferSelect): AuthUser => ({ id: u.id, role: u.role, name: u.name, phone: u.phone, language: u.language })

async function issueTokens(d: Deps, user: typeof users.$inferSelect, familyId?: string, userAgent?: string, tx = d.db) {
  const accessToken = await new SignJWT({ role: user.role })
    .setProtectedHeader({ alg: 'HS256' }).setSubject(user.id).setIssuer(ISS).setAudience(AUD)
    .setIssuedAt().setExpirationTime(`${d.cfg.ACCESS_TTL_SEC}s`)
    .sign(new TextEncoder().encode(d.cfg.JWT_SECRET))
  const refreshToken = `rt_${randomToken(32)}`
  const [row] = await tx.insert(refreshTokens).values({
    userId: user.id, familyId: familyId ?? crypto.randomUUID(), tokenHash: sha256(refreshToken),
    expiresAt: new Date(Date.now() + d.cfg.REFRESH_TTL_DAYS * 86400_000), userAgent: userAgent?.slice(0, 300),
  }).returning({ id: refreshTokens.id })
  return { accessToken, refreshToken, expiresInSec: d.cfg.ACCESS_TTL_SEC, _rowId: row!.id }
}

export async function rotateRefresh(d: Deps, token: string, userAgent?: string) {
  const out = await d.db.transaction(async (tx) => {
    const [rt] = await tx.select().from(refreshTokens).where(eq(refreshTokens.tokenHash, sha256(token))).for('update')
    if (!rt) return { err: new AppError(401, 'invalid_refresh', 'Invalid refresh token') }
    if (rt.revokedAt) {
      // A rotated token was presented again => likely theft. Kill the whole family.
      await tx.update(refreshTokens).set({ revokedAt: new Date() }).where(and(eq(refreshTokens.familyId, rt.familyId), isNull(refreshTokens.revokedAt)))
      return { err: new AppError(401, 'refresh_reused', 'Session revoked. Please sign in again.') }
    }
    if (rt.expiresAt < new Date()) return { err: new AppError(401, 'invalid_refresh', 'Refresh token expired') }
    const [user] = await tx.select().from(users).where(eq(users.id, rt.userId))
    if (!user || user.status !== 'active') return { err: new AppError(401, 'invalid_refresh', 'Account unavailable') }
    const next = await issueTokens(d, user, rt.familyId, userAgent, tx)
    await tx.update(refreshTokens).set({ revokedAt: new Date(), replacedBy: next._rowId }).where(eq(refreshTokens.id, rt.id))
    return { next }
  })
  if ('err' in out && out.err) throw out.err
  const { _rowId, ...tokens } = (out as { next: Awaited<ReturnType<typeof issueTokens>> }).next
  void _rowId
  return tokens
}

export async function revokeFamily(d: Deps, token: string) {
  const [rt] = await d.db.select().from(refreshTokens).where(eq(refreshTokens.tokenHash, sha256(token)))
  if (rt) await d.db.update(refreshTokens).set({ revokedAt: new Date() }).where(and(eq(refreshTokens.familyId, rt.familyId), isNull(refreshTokens.revokedAt)))
}

export const authenticate = (d: Deps): MiddlewareHandler<AppEnv> => async (c, next) => {
  const h = c.req.header('authorization')
  const token = h?.startsWith('Bearer ') ? h.slice(7) : undefined
  if (!token) throw new AppError(401, 'unauthorized', 'Missing bearer token')
  let sub: string | undefined
  try {
    const { payload } = await jwtVerify(token, new TextEncoder().encode(d.cfg.JWT_SECRET), { issuer: ISS, audience: AUD, algorithms: ['HS256'] })
    sub = payload.sub
  } catch { throw new AppError(401, 'unauthorized', 'Invalid or expired token') }
  const [u] = await d.db.select().from(users).where(eq(users.id, sub!))
  if (!u || u.status !== 'active') throw new AppError(401, 'unauthorized', 'Account unavailable')
  c.set('user', publicUser(u))
  await next()
}

export function authRoutes(d: Deps) {
  const r = new Hono<AppEnv>()
  r.post('/otp', v('json', z.object({ phone: phoneField })), async (c) =>
    c.json({ ok: true, ...(await requestOtp(d, c.req.valid('json').phone)) }))
  r.post('/verify', v('json', z.object({
    phone: phoneField, code: z.string().regex(/^\d{6}$/),
    registration: registrationSchema.optional(),
  })), async (c) => {
    const b = c.req.valid('json')
    return c.json(await verifyOtp(d, b.phone, b.code, b.registration, c.req.header('user-agent')))
  })
  r.post('/refresh', v('json', z.object({ refreshToken: z.string().min(10).max(200) })), async (c) =>
    c.json(await rotateRefresh(d, c.req.valid('json').refreshToken, c.req.header('user-agent'))))
  r.post('/logout', v('json', z.object({ refreshToken: z.string().min(10).max(200) })), async (c) => {
    await revokeFamily(d, c.req.valid('json').refreshToken)
    return c.json({ ok: true })
  })
  return r
}

export function meRoutes(d: Deps) {
  const r = new Hono<AppEnv>()
  r.get('/', async (c) => c.json(me(c)))
  r.patch('/', v('json', z.object({ name: z.string().trim().min(2).max(120).optional(), language: z.enum(['hi', 'en', 'mr']).optional() })), async (c) => {
    const [u] = await d.db.update(users).set(c.req.valid('json')).where(eq(users.id, me(c).id)).returning()
    return c.json(publicUser(u!))
  })
  return r
}
