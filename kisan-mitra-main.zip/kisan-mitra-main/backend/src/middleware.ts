import { and, eq } from 'drizzle-orm'
import type { Context, MiddlewareHandler } from 'hono'
import { getConnInfo } from '@hono/node-server/conninfo'
import type { AppEnv, Deps } from './deps'
import { idempotencyKeys } from './db/schema'
import { AppError } from './lib/errors'
import { sha256 } from './lib/util'

export function clientIp(c: Context, trustProxy: boolean) {
  if (trustProxy) { const f = c.req.header('x-forwarded-for')?.split(',')[0]?.trim(); if (f) return f }
  try { return getConnInfo(c).remote.address ?? 'unknown' } catch { return 'unknown' }
}

/** Fixed-window in-memory limiter. Per-instance: put a gateway/Redis limiter in front when you scale out. */
export function rateLimit(d: Deps, max: number, name = 'api'): MiddlewareHandler {
  const hits = new Map<string, { n: number; reset: number }>()
  setInterval(() => { const now = Date.now(); for (const [k, h] of hits) if (h.reset < now) hits.delete(k) }, 60_000).unref()
  return async (c, next) => {
    const key = `${name}:${clientIp(c, d.cfg.TRUST_PROXY)}`, now = Date.now()
    let h = hits.get(key)
    if (!h || h.reset < now) { h = { n: 0, reset: now + 60_000 }; hits.set(key, h) }
    if (++h.n > max) {
      c.header('Retry-After', String(Math.ceil((h.reset - now) / 1000)))
      throw new AppError(429, 'rate_limited', 'Too many requests. Slow down and retry shortly.')
    }
    await next()
  }
}

/**
 * Idempotency-Key support for unsafe requests (essential on flaky rural networks):
 * the first request claims the key, retries replay the stored response, concurrent duplicates get 409.
 */
export const idempotency = (d: Deps): MiddlewareHandler<AppEnv> => async (c, next) => {
  const key = c.req.header('idempotency-key')
  if (!key) return next()
  if (!/^[A-Za-z0-9_\-:.]{8,128}$/.test(key)) throw new AppError(400, 'invalid_idempotency_key', 'Idempotency-Key must be 8-128 URL-safe characters')
  const userId = c.get('user').id
  const hash = sha256(`${c.req.method} ${c.req.path}\n${await c.req.text()}`)
  const claimed = await d.db.insert(idempotencyKeys).values({ userId, key, requestHash: hash }).onConflictDoNothing().returning({ key: idempotencyKeys.key })
  if (!claimed.length) {
    const [row] = await d.db.select().from(idempotencyKeys).where(and(eq(idempotencyKeys.userId, userId), eq(idempotencyKeys.key, key)))
    if (!row) throw new AppError(409, 'request_in_progress', 'Retry shortly')
    if (row.requestHash !== hash) throw new AppError(422, 'idempotency_key_reuse', 'This Idempotency-Key was used with a different request')
    if (row.statusCode == null) throw new AppError(409, 'request_in_progress', 'The original request is still being processed')
    return new Response(row.response, { status: row.statusCode, headers: { 'content-type': 'application/json', 'idempotent-replay': 'true' } })
  }
  await next()
  if (c.res.status >= 500) {
    await d.db.delete(idempotencyKeys).where(and(eq(idempotencyKeys.userId, userId), eq(idempotencyKeys.key, key)))
    return
  }
  await d.db.update(idempotencyKeys).set({ statusCode: c.res.status, response: await c.res.clone().text() })
    .where(and(eq(idempotencyKeys.userId, userId), eq(idempotencyKeys.key, key)))
}
