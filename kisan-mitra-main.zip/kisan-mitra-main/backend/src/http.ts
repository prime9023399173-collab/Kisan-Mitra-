import { zValidator } from '@hono/zod-validator'
import type { Context, MiddlewareHandler } from 'hono'
import type { ZodType } from 'zod'
import type { AppEnv, AuthUser, Role } from './deps'
import { AppError, forbidden } from './lib/errors'

/** zod validation that fails with our problem+json shape. */
export const v = <T extends ZodType>(target: 'json' | 'query' | 'param', schema: T) =>
  zValidator(target, schema, (result) => {
    if (!result.success) {
      throw new AppError(400, 'validation_error', 'Request validation failed',
        result.error.issues.map((i) => ({ path: i.path.join('.'), message: i.message })))
    }
  })

export const requireRole = (...roles: Role[]): MiddlewareHandler<AppEnv> => async (c, next) => {
  if (!roles.includes(c.get('user').role)) throw forbidden()
  await next()
}

export const me = (c: Context<AppEnv>): AuthUser => c.get('user')
