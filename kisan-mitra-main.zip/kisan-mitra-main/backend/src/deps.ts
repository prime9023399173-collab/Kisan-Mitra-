import type { Config } from './config'
import type { Db } from './db/client'
import type { EventBus } from './lib/events'
import type { OtpSender } from './lib/otp'

export interface Deps { db: Db; cfg: Config; bus: EventBus; otp: OtpSender }
export type Role = 'farmer' | 'buyer' | 'mandi_admin' | 'admin'
export interface AuthUser { id: string; role: Role; name: string; phone: string; language: 'hi' | 'en' | 'mr' }
export type AppEnv = { Variables: { user: AuthUser; requestId: string } }
