import { createHash } from 'node:crypto'
import { sql } from 'drizzle-orm'
import { readdirSync, readFileSync } from 'node:fs'
import { join } from 'node:path'
import type { DbHandle } from './client'

const lit = (s: string) => `'${s.replace(/'/g, "''")}'`

/**
 * Minimal forward-only migration runner: lexical order, one transaction per file,
 * checksum-verified, serialized across instances with an advisory lock.
 */
export async function migrate(h: DbHandle, dir = process.env.MIGRATIONS_DIR ?? join(process.cwd(), 'migrations')) {
  await h.execRaw(`CREATE TABLE IF NOT EXISTS _migrations (
    name text PRIMARY KEY, checksum text NOT NULL, applied_at timestamptz NOT NULL DEFAULT now())`)
  const res = (await h.db.execute(sql`select name, checksum from _migrations`)) as unknown as { rows: { name: string; checksum: string }[] }
  const applied = new Map(res.rows.map((r) => [r.name, r.checksum]))
  const files = readdirSync(dir).filter((f) => f.endsWith('.sql')).sort()
  const ran: string[] = []
  for (const f of files) {
    const body = readFileSync(join(dir, f), 'utf8')
    const sum = createHash('sha256').update(body).digest('hex')
    const prev = applied.get(f)
    if (prev) {
      if (prev !== sum) throw new Error(`Migration ${f} was modified after being applied`)
      continue
    }
    await h.execRaw(`BEGIN; SELECT pg_advisory_xact_lock(727274); ${body}
      INSERT INTO _migrations (name, checksum) VALUES (${lit(f)}, ${lit(sum)}); COMMIT;`)
    ran.push(f)
  }
  return ran
}
