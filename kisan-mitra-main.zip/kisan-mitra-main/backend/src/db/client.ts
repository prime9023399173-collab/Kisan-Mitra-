import { sql } from 'drizzle-orm'
import type { PgDatabase } from 'drizzle-orm/pg-core'
import * as schema from './schema'
import type { Config } from '../config'
import type { EventBus } from '../lib/events'

export type Db = PgDatabase<any, typeof schema>
/** A Db or a transaction handle - services accept either. */
export type Executor = Db

export interface DbHandle {
  db: Db
  kind: 'pg' | 'pglite'
  /** Run multi-statement SQL (migrations). */
  execRaw(sqlText: string): Promise<void>
  /** Forward LISTEN/NOTIFY events into the in-process bus. Returns a stopper. */
  listen(channel: string, bus: EventBus): Promise<() => Promise<void>>
  close(): Promise<void>
}

export async function connectDb(cfg: Pick<Config, 'DATABASE_URL' | 'DB_POOL_MAX' | 'PGLITE_DIR'>, opts: { memory?: boolean } = {}): Promise<DbHandle> {
  if (cfg.DATABASE_URL && !opts.memory) {
    const { default: pg } = await import('pg')
    const { drizzle } = await import('drizzle-orm/node-postgres')
    const pool = new pg.Pool({
      connectionString: cfg.DATABASE_URL,
      max: cfg.DB_POOL_MAX,
      idleTimeoutMillis: 30_000,
      connectionTimeoutMillis: 5_000,
      statement_timeout: 15_000,
      idle_in_transaction_session_timeout: 30_000,
    })
    pool.on('error', (e) => console.error('pg pool error', e.message))
    const db = drizzle(pool, { schema }) as unknown as Db
    return {
      db, kind: 'pg',
      execRaw: async (s) => { await pool.query(s) },
      async listen(channel, bus) {
        let stopped = false
        let client: InstanceType<typeof pg.Client> | undefined
        const start = async (): Promise<void> => {
          if (stopped) return
          const c = new pg.Client({ connectionString: cfg.DATABASE_URL })
          c.on('notification', (m) => { if (m.payload) bus.dispatchRaw(m.payload) })
          const retry = () => { if (!stopped) setTimeout(() => void start().catch(retry), 2000).unref() }
          c.on('error', retry); c.on('end', retry)
          await c.connect()
          await c.query(`LISTEN ${channel}`)
          client = c
        }
        await start()
        return async () => { stopped = true; await client?.end().catch(() => {}) }
      },
      close: () => pool.end(),
    }
  }
  const { PGlite } = await import('@electric-sql/pglite')
  const { drizzle } = await import('drizzle-orm/pglite')
  if (!opts.memory && cfg.PGLITE_DIR) {
    const fs = await import('node:fs')
    fs.mkdirSync(cfg.PGLITE_DIR, { recursive: true })
  }
  const client = new PGlite(opts.memory ? undefined : cfg.PGLITE_DIR)
  await client.waitReady
  const db = drizzle(client, { schema }) as unknown as Db
  return {
    db, kind: 'pglite',
    execRaw: async (s) => { await client.exec(s) },
    async listen(channel, bus) {
      const unsub = await client.listen(channel, (payload) => bus.dispatchRaw(payload))
      return async () => { await unsub() }
    },
    close: () => client.close(),
  }
}

export const ping = (db: Db) => db.execute(sql`select 1`)
