import { sql } from 'drizzle-orm'
import {
  bigint, boolean, doublePrecision, integer, jsonb, numeric, pgEnum, pgTable, primaryKey,
  smallint, text, timestamp, uuid, date,
} from 'drizzle-orm/pg-core'

const ts = (name: string) => timestamp(name, { withTimezone: true, mode: 'date' })
const createdAt = () => ts('created_at').notNull().default(sql`now_ms()`)

export const userRole = pgEnum('user_role', ['farmer', 'buyer', 'mandi_admin', 'admin'])
export const userStatus = pgEnum('user_status', ['active', 'suspended'])
export const langCode = pgEnum('lang_code', ['hi', 'en', 'mr'])
export const cropGrade = pgEnum('crop_grade', ['A', 'B', 'C'])
export const lotStatus = pgEnum('lot_status', ['listed', 'matched', 'pickedup', 'paid', 'cancelled'])
export const offerStatus = pgEnum('offer_status', ['pending', 'accepted', 'rejected', 'withdrawn'])
export const paymentStatus = pgEnum('payment_status', ['pending', 'in_escrow', 'paid', 'refunded'])
export const logisticsStatus = pgEnum('logistics_status', ['pickup_scheduled', 'in_transit', 'delivered'])
export const grievanceStatus = pgEnum('grievance_status', ['open', 'in_review', 'resolved'])
export const buyerType = pgEnum('buyer_type', ['institutional', 'processor', 'fpo', 'retail', 'trader'])

export const users = pgTable('users', {
  id: uuid('id').primaryKey().defaultRandom(),
  phone: text('phone').notNull().unique(),
  role: userRole('role').notNull(),
  name: text('name').notNull(),
  language: langCode('language').notNull().default('hi'),
  status: userStatus('status').notNull().default('active'),
  lastLoginAt: ts('last_login_at'),
  createdAt: createdAt(),
  updatedAt: ts('updated_at').notNull().default(sql`now_ms()`),
})

export const otpChallenges = pgTable('otp_challenges', {
  id: uuid('id').primaryKey().defaultRandom(),
  phone: text('phone').notNull(),
  codeHash: text('code_hash').notNull(),
  attempts: integer('attempts').notNull().default(0),
  expiresAt: ts('expires_at').notNull(),
  consumedAt: ts('consumed_at'),
  createdAt: createdAt(),
})

export const refreshTokens = pgTable('refresh_tokens', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: uuid('user_id').notNull().references(() => users.id),
  familyId: uuid('family_id').notNull(),
  tokenHash: text('token_hash').notNull().unique(),
  expiresAt: ts('expires_at').notNull(),
  revokedAt: ts('revoked_at'),
  replacedBy: uuid('replaced_by'),
  userAgent: text('user_agent'),
  createdAt: createdAt(),
})

export const crops = pgTable('crops', {
  id: text('id').primaryKey(),
  name: text('name').notNull(),
  nameHi: text('name_hi').notNull(),
  nameMr: text('name_mr').notNull(),
})

export const mandis = pgTable('mandis', {
  id: uuid('id').primaryKey().defaultRandom(),
  name: text('name').notNull(),
  district: text('district').notNull(),
  state: text('state').notNull(),
  latitude: doublePrecision('latitude'),
  longitude: doublePrecision('longitude'),
  createdAt: createdAt(),
})

export const mandiAdmins = pgTable('mandi_admins', {
  userId: uuid('user_id').notNull().references(() => users.id),
  mandiId: uuid('mandi_id').notNull().references(() => mandis.id),
}, (t) => [primaryKey({ columns: [t.userId, t.mandiId] })])

export const mandiCrops = pgTable('mandi_crops', {
  mandiId: uuid('mandi_id').notNull().references(() => mandis.id),
  cropId: text('crop_id').notNull().references(() => crops.id),
}, (t) => [primaryKey({ columns: [t.mandiId, t.cropId] })])

export const priceObservations = pgTable('price_observations', {
  id: bigint('id', { mode: 'number' }).primaryKey().generatedAlwaysAsIdentity(),
  mandiId: uuid('mandi_id').notNull().references(() => mandis.id),
  cropId: text('crop_id').notNull().references(() => crops.id),
  price: numeric('price', { precision: 10, scale: 2 }).notNull(),
  minPrice: numeric('min_price', { precision: 10, scale: 2 }),
  maxPrice: numeric('max_price', { precision: 10, scale: 2 }),
  arrivalsQtl: numeric('arrivals_qtl', { precision: 12, scale: 2 }),
  source: text('source').notNull().default('admin'),
  recordedBy: uuid('recorded_by').references(() => users.id),
  observedAt: ts('observed_at').notNull().default(sql`now_ms()`),
})

export const mspRates = pgTable('msp_rates', {
  cropId: text('crop_id').notNull().references(() => crops.id),
  effectiveFrom: date('effective_from').notNull(),
  season: text('season').notNull(),
  price: numeric('price', { precision: 10, scale: 2 }).notNull(),
}, (t) => [primaryKey({ columns: [t.cropId, t.effectiveFrom] })])

export const priceAlerts = pgTable('price_alerts', {
  id: uuid('id').primaryKey().defaultRandom(),
  cropId: text('crop_id').notNull().references(() => crops.id),
  mandiId: uuid('mandi_id').notNull().references(() => mandis.id),
  oldPrice: numeric('old_price', { precision: 10, scale: 2 }).notNull(),
  newPrice: numeric('new_price', { precision: 10, scale: 2 }).notNull(),
  changePercent: numeric('change_percent', { precision: 7, scale: 2 }).notNull(),
  direction: text('direction').notNull(),
  createdAt: createdAt(),
})

export const farmers = pgTable('farmers', {
  userId: uuid('user_id').primaryKey().references(() => users.id),
  village: text('village').notNull(),
  district: text('district'),
  state: text('state'),
  preferredMandiId: uuid('preferred_mandi_id').references(() => mandis.id),
})

export const buyers = pgTable('buyers', {
  userId: uuid('user_id').primaryKey().references(() => users.id),
  businessName: text('business_name').notNull(),
  type: buyerType('type').notNull(),
  gstin: text('gstin').unique(),
  verified: boolean('verified').notNull().default(false),
  verifiedAt: ts('verified_at'),
  verifiedBy: uuid('verified_by').references(() => users.id),
  ratingSum: numeric('rating_sum', { precision: 10, scale: 2 }).notNull().default('0'),
  ratingCount: integer('rating_count').notNull().default(0),
})

export const buyerDemands = pgTable('buyer_demands', {
  id: uuid('id').primaryKey().defaultRandom(),
  buyerId: uuid('buyer_id').notNull().references(() => buyers.userId),
  cropId: text('crop_id').notNull().references(() => crops.id),
  quantityQtl: numeric('quantity_qtl', { precision: 12, scale: 2 }).notNull(),
  maxPrice: numeric('max_price', { precision: 10, scale: 2 }),
  active: boolean('active').notNull().default(true),
  updatedAt: ts('updated_at').notNull().default(sql`now_ms()`),
})

export const lots = pgTable('lots', {
  id: uuid('id').primaryKey().defaultRandom(),
  farmerId: uuid('farmer_id').notNull().references(() => farmers.userId),
  cropId: text('crop_id').notNull().references(() => crops.id),
  quantityQtl: numeric('quantity_qtl', { precision: 10, scale: 2 }).notNull(),
  grade: cropGrade('grade').notNull(),
  status: lotStatus('status').notNull().default('listed'),
  askingPrice: numeric('asking_price', { precision: 10, scale: 2 }),
  mandiId: uuid('mandi_id').references(() => mandis.id),
  notes: text('notes'),
  createdAt: createdAt(),
  updatedAt: ts('updated_at').notNull().default(sql`now_ms()`),
})

export const offers = pgTable('offers', {
  id: uuid('id').primaryKey().defaultRandom(),
  lotId: uuid('lot_id').notNull().references(() => lots.id),
  buyerId: uuid('buyer_id').notNull().references(() => buyers.userId),
  pricePerQtl: numeric('price_per_qtl', { precision: 10, scale: 2 }).notNull(),
  status: offerStatus('status').notNull().default('pending'),
  message: text('message'),
  createdAt: createdAt(),
  decidedAt: ts('decided_at'),
})

export const transactions = pgTable('transactions', {
  id: uuid('id').primaryKey().defaultRandom(),
  offerId: uuid('offer_id').notNull().unique().references(() => offers.id),
  lotId: uuid('lot_id').notNull().references(() => lots.id),
  farmerId: uuid('farmer_id').notNull().references(() => farmers.userId),
  buyerId: uuid('buyer_id').notNull().references(() => buyers.userId),
  quantityQtl: numeric('quantity_qtl', { precision: 10, scale: 2 }).notNull(),
  pricePerQtl: numeric('price_per_qtl', { precision: 10, scale: 2 }).notNull(),
  amountTotal: numeric('amount_total', { precision: 14, scale: 2 }).generatedAlwaysAs(sql`quantity_qtl * price_per_qtl`),
  paymentStatus: paymentStatus('payment_status').notNull().default('pending'),
  logisticsStatus: logisticsStatus('logistics_status').notNull().default('pickup_scheduled'),
  paymentRef: text('payment_ref'),
  pickupAt: ts('pickup_at'),
  vehicleNo: text('vehicle_no'),
  paidAt: ts('paid_at'),
  deliveredAt: ts('delivered_at'),
  createdAt: createdAt(),
  updatedAt: ts('updated_at').notNull().default(sql`now_ms()`),
})

export const buyerRatings = pgTable('buyer_ratings', {
  transactionId: uuid('transaction_id').primaryKey().references(() => transactions.id),
  buyerId: uuid('buyer_id').notNull().references(() => buyers.userId),
  stars: smallint('stars').notNull(),
  comment: text('comment'),
  createdAt: createdAt(),
})

export const grievances = pgTable('grievances', {
  id: uuid('id').primaryKey().defaultRandom(),
  transactionId: uuid('transaction_id').notNull().references(() => transactions.id),
  raisedBy: uuid('raised_by').notNull().references(() => users.id),
  message: text('message').notNull(),
  status: grievanceStatus('status').notNull().default('open'),
  resolutionNote: text('resolution_note'),
  resolvedBy: uuid('resolved_by').references(() => users.id),
  resolvedAt: ts('resolved_at'),
  createdAt: createdAt(),
  updatedAt: ts('updated_at').notNull().default(sql`now_ms()`),
})

export const notifications = pgTable('notifications', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: uuid('user_id').notNull().references(() => users.id),
  kind: text('kind').notNull(),
  payload: jsonb('payload').notNull().default({}),
  readAt: ts('read_at'),
  createdAt: createdAt(),
})

export const auditLog = pgTable('audit_log', {
  id: bigint('id', { mode: 'number' }).primaryKey().generatedAlwaysAsIdentity(),
  actorUserId: uuid('actor_user_id'),
  action: text('action').notNull(),
  entity: text('entity').notNull(),
  entityId: text('entity_id').notNull(),
  data: jsonb('data').notNull().default({}),
  at: ts('at').notNull().default(sql`now_ms()`),
})

export const idempotencyKeys = pgTable('idempotency_keys', {
  userId: uuid('user_id').notNull().references(() => users.id),
  key: text('key').notNull(),
  requestHash: text('request_hash').notNull(),
  statusCode: integer('status_code'),
  response: text('response'),
  createdAt: createdAt(),
}, (t) => [primaryKey({ columns: [t.userId, t.key] })])
