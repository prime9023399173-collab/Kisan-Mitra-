import { Hono } from 'hono'
import { bodyLimit } from 'hono/body-limit'
import { cors } from 'hono/cors'
import { HTTPException } from 'hono/http-exception'
import { secureHeaders } from 'hono/secure-headers'
import type { Logger } from 'pino'
import type { AppEnv, Deps } from './deps'
import { ping } from './db/client'
import { AppError, fromDbError } from './lib/errors'
import { idempotency, rateLimit } from './middleware'
import { adminRoutes } from './modules/admin'
import { authenticate, authRoutes, meRoutes } from './modules/auth'
import { marketRoutes } from './modules/market'
import { marketplaceRoutes } from './modules/marketplace'
import { supportRoutes } from './modules/support'

import { integrationRoutes } from './modules/integration'
import { serveStatic } from '@hono/node-server/serve-static'
import * as fs from 'node:fs'
import * as path from 'node:path'

export function createApp(d: Deps, log?: Logger) {
  const app = new Hono<AppEnv>()
  const auth = authenticate(d)

  app.use('*', async (c, next) => {
    const rid = c.req.header('x-request-id')?.slice(0, 64) || crypto.randomUUID()
    c.set('requestId', rid); c.header('X-Request-Id', rid)
    const t0 = performance.now()
    await next()
    log?.info({ rid, method: c.req.method, path: c.req.path, status: c.res.status, ms: Math.round(performance.now() - t0), user: c.get('user')?.id })
  })
  app.use('*', secureHeaders())
  app.use('*', cors({
    origin: (origin) => {
      // Allow localhost, 127.0.0.1, Firebase Hosting, Vercel, or configured origins
      if (!origin) return '*'
      if (origin.includes('localhost') || origin.includes('127.0.0.1') || origin.includes('web.app') || origin.includes('firebaseapp.com')) {
        return origin
      }
      const allowed = d.cfg.CORS_ORIGINS.split(',').map((s) => s.trim())
      if (allowed.includes('*') || allowed.includes(origin)) return origin
      return origin
    },
    allowHeaders: ['Authorization', 'Content-Type', 'Idempotency-Key', 'X-Request-Id'],
    allowMethods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
    exposeHeaders: ['X-Request-Id', 'Idempotent-Replay', 'Retry-After'],
    maxAge: 600,
  }))
  app.use('*', bodyLimit({ maxSize: 100 * 1024, onError: () => { throw new AppError(413, 'payload_too_large', 'Request body too large') } }))

  app.get('/healthz', (c) => c.json({ ok: true }))
  app.get('/readyz', async (c) => {
    try { await ping(d.db); return c.json({ ok: true }) } catch { return c.json({ ok: false }, 503) }
  })

  // Mount direct integration routes: /api/sync, /api/chat, /api/slots
  app.route('/api', integrationRoutes(d))

  const api = new Hono<AppEnv>()
  api.use('*', rateLimit(d, d.cfg.RATE_LIMIT_PER_MIN))
  api.use('/auth/*', rateLimit(d, d.cfg.AUTH_RATE_LIMIT_PER_MIN, 'auth'))
  for (const p of ['/lots', '/offers', '/transactions', '/grievances', '/buyers', '/notifications', '/events', '/me', '/admin']) {
    api.use(p, auth); api.use(`${p}/*`, auth)
  }
  api.route('/auth', authRoutes(d))
  api.route('/me', meRoutes(d))
  api.route('/admin', adminRoutes(d))
  api.route('/', marketRoutes(d, auth))
  api.route('/', marketplaceRoutes(d, idempotency(d)))
  api.route('/', supportRoutes(d))
  api.route('/', integrationRoutes(d))
  app.route('/api/v1', api)

  // Serve compiled frontend SPA if dist folder exists
  const frontendDist = path.resolve(process.cwd(), '../frontend/dist')
  if (fs.existsSync(frontendDist)) {
    app.use('/*', serveStatic({ root: '../frontend/dist' }))
    app.get('*', serveStatic({ path: '../frontend/dist/index.html' }))
  }

  app.notFound((c) => c.json(problem(new AppError(404, 'not_found', 'Route not found'), c.get('requestId')), 404, { 'content-type': 'application/problem+json' }))
  app.onError((err, c) => {
    let e: AppError | null = err instanceof AppError ? err : null
    if (!e && err instanceof HTTPException) e = new AppError(err.status, 'http_error', err.message)
    if (!e) e = fromDbError(err)
    if (!e) { log?.error({ err, rid: c.get('requestId') }, 'unhandled error'); e = new AppError(500, 'internal_error', 'Something went wrong') }
    return c.json(problem(e, c.get('requestId')), e.status as 400, { 'content-type': 'application/problem+json' })
  })
  return app
}

const problem = (e: AppError, requestId: string) => ({
  type: 'about:blank', title: e.code, status: e.status, code: e.code, detail: e.message, errors: e.details, requestId,
})
