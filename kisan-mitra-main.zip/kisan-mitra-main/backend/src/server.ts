import { serve } from '@hono/node-server'
import { lt, or, sql } from 'drizzle-orm'
import pino from 'pino'
import { createApp } from './app'
import { loadConfig } from './config'
import { connectDb } from './db/client'
import { migrate } from './db/migrate'
import { idempotencyKeys, otpChallenges, refreshTokens } from './db/schema'
import { CHANNEL, EventBus } from './lib/events'
import { ConsoleOtpSender } from './lib/otp'
import { seedDemo } from './scripts/seed-data'

async function main() {
  const cfg = loadConfig()
  const log = pino({ level: cfg.LOG_LEVEL, ...(cfg.NODE_ENV === 'development' ? { transport: { target: 'pino-pretty' } } : {}) })
  const h = await connectDb(cfg)
  log.info({ db: h.kind }, 'database connected')
  if (cfg.AUTO_MIGRATE ?? cfg.NODE_ENV !== 'production') {
    const ran = await migrate(h); if (ran.length) log.info({ ran }, 'migrations applied')
    if (cfg.NODE_ENV !== 'production') {
      try { await seedDemo(h.db) } catch {}
    }
  }
  const bus = new EventBus()
  const stopListen = await h.listen(CHANNEL, bus)
  const app = createApp({ db: h.db, cfg, bus, otp: new ConsoleOtpSender() }, log)
  const server = serve({ fetch: app.fetch, port: cfg.PORT }, (i) => log.info(`Kisan Mitra API listening on :${i.port}`))

  // housekeeping: expire short-lived rows
  const sweep = setInterval(async () => {
    try {
      await h.db.delete(idempotencyKeys).where(lt(idempotencyKeys.createdAt, sql`now() - interval '24 hours'`))
      await h.db.delete(otpChallenges).where(lt(otpChallenges.createdAt, sql`now() - interval '1 day'`))
      await h.db.delete(refreshTokens).where(or(lt(refreshTokens.expiresAt, sql`now() - interval '7 days'`)))
    } catch (e) { log.warn({ err: e }, 'sweep failed') }
  }, 3600_000)
  sweep.unref()

  const shutdown = async (sig: string) => {
    log.info({ sig }, 'shutting down')
    clearInterval(sweep)
    server.close()
    await stopListen().catch(() => {})
    await h.close().catch(() => {})
    process.exit(0)
  }
  process.on('SIGTERM', () => void shutdown('SIGTERM'))
  process.on('SIGINT', () => void shutdown('SIGINT'))
}
main().catch((e) => { console.error(e); process.exit(1) })
