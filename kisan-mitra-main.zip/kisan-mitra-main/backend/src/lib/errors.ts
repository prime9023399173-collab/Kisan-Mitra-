export class AppError extends Error {
  constructor(public status: number, public code: string, message: string, public details?: unknown) {
    super(message)
  }
}
export const notFound = (what = 'Resource') => new AppError(404, 'not_found', `${what} not found`)
export const forbidden = (msg = 'You are not allowed to do that') => new AppError(403, 'forbidden', msg)
export const conflict = (code: string, msg: string) => new AppError(409, code, msg)

/** Map Postgres/driver errors to API errors. Drizzle wraps driver errors in `.cause`. */
export function fromDbError(err: unknown): AppError | null {
  const e = err as { code?: string; cause?: { code?: string; message?: string; constraint?: string }; message?: string }
  const code = e?.cause?.code ?? e?.code
  const msg = e?.cause?.message ?? e?.message ?? ''
  switch (code) {
    case '23505': return new AppError(409, 'conflict', 'This record already exists or conflicts with another')
    case '23503': return new AppError(422, 'invalid_reference', 'A referenced record does not exist')
    case '23514': return new AppError(409, 'invalid_state', msg.replace(/^.*?:\s*/, '') || 'That change is not allowed in the current state')
    case '22P02': case '22003': return new AppError(400, 'invalid_input', 'Malformed value')
    default: return null
  }
}
