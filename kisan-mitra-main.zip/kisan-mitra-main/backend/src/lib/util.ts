import { createHash, createHmac, randomBytes, timingSafeEqual } from 'node:crypto'
import { and, eq, lt, or, type SQL } from 'drizzle-orm'
import type { AnyPgColumn } from 'drizzle-orm/pg-core'
import { z } from 'zod'
import { AppError } from './errors'

export const sha256 = (s: string) => createHash('sha256').update(s).digest('hex')
export const hmac = (key: string, s: string) => createHmac('sha256', key).update(s).digest('hex')
export const randomToken = (bytes = 32) => randomBytes(bytes).toString('base64url')
export function safeEqual(a: string, b: string) {
  const x = Buffer.from(a), y = Buffer.from(b)
  return x.length === y.length && timingSafeEqual(x, y)
}

/** Indian mobile numbers only. Accepts "98261 45120", "+91 98261 45120", "919826145120". */
export function normalizePhone(raw: string): string {
  const d = raw.replace(/[\s\-()]/g, '').replace(/^\+/, '')
  const m = /^(?:91|0)?([6-9]\d{9})$/.exec(d)
  if (!m) throw new AppError(400, 'invalid_phone', 'Enter a valid 10-digit Indian mobile number')
  return `+91${m[1]}`
}

export const num = (v: string | number | null | undefined) => (v == null ? null : Number(v))

// ── keyset pagination over (created_at DESC, id DESC) ──
export const pageQuery = z.object({
  limit: z.coerce.number().int().min(1).max(100).default(25),
  cursor: z.string().max(200).optional(),
})
export const encodeCursor = (createdAt: Date, id: string) => Buffer.from(`${createdAt.toISOString()}|${id}`).toString('base64url')
export function cursorWhere(cursor: string | undefined, createdCol: AnyPgColumn, idCol: AnyPgColumn): SQL | undefined {
  if (!cursor) return undefined
  const [iso, id] = Buffer.from(cursor, 'base64url').toString().split('|')
  const d = new Date(iso ?? '')
  if (!id || Number.isNaN(d.getTime())) throw new AppError(400, 'invalid_cursor', 'Invalid cursor')
  return or(lt(createdCol, d), and(eq(createdCol, d), lt(idCol, id)))
}
export function paginate<T extends { createdAt: Date; id: string }>(rows: T[], limit: number) {
  const items = rows.slice(0, limit)
  const last = items.at(-1)
  return { items, nextCursor: rows.length > limit && last ? encodeCursor(last.createdAt, last.id) : null }
}
