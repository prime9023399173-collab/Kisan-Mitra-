/** Delivery of one-time codes. Plug an SMS/WhatsApp gateway in by implementing this interface. */
export interface OtpSender { send(phone: string, code: string): Promise<void> }

export class ConsoleOtpSender implements OtpSender {
  async send(phone: string, code: string) { console.log(`[otp] ${phone} -> ${code}`) }
}
