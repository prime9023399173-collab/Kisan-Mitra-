import type { Executor } from '../db/client'
import { auditLog, notifications } from '../db/schema'
import { publish } from './events'

export const audit = (tx: Executor, actorUserId: string | null, action: string, entity: string, entityId: string, data: Record<string, unknown> = {}) =>
  tx.insert(auditLog).values({ actorUserId, action, entity, entityId, data })

/** Persist an in-app notification and push it to the user's live streams (delivered on commit). */
export async function notify(tx: Executor, userId: string, kind: string, payload: Record<string, unknown> = {}) {
  const [n] = await tx.insert(notifications).values({ userId, kind, payload }).returning({ id: notifications.id })
  await publish(tx, { type: 'notification', userId, data: { id: n!.id, kind, ...payload } })
}
