import { sql } from 'drizzle-orm'
import type { Executor } from '../db/client'

export const CHANNEL = 'km_events'
export type BusEvent = { type: string; userId?: string; data?: Record<string, unknown> }

/** In-process fan-out. Cross-instance delivery is done by Postgres LISTEN/NOTIFY (see DbHandle.listen). */
export class EventBus {
  private subs = new Set<(e: BusEvent) => void>()
  subscribe(fn: (e: BusEvent) => void) { this.subs.add(fn); return () => { this.subs.delete(fn) } }
  dispatchRaw(payload: string) {
    let e: BusEvent
    try { e = JSON.parse(payload) } catch { return }
    for (const fn of this.subs) { try { fn(e) } catch { /* a bad subscriber must not break others */ } }
  }
}

/**
 * Publish inside the caller's transaction: Postgres delivers NOTIFY only on COMMIT,
 * so clients never hear about changes that were rolled back. Keep payloads tiny (8 KB cap).
 */
export async function publish(tx: Executor, e: BusEvent) {
  await tx.execute(sql`select pg_notify(${CHANNEL}, ${JSON.stringify(e)})`)
}
