import { loadConfig } from '../config'
import { connectDb } from '../db/client'
import { users } from '../db/schema'
import { normalizePhone } from '../lib/util'

const [phone, name, role = 'admin'] = process.argv.slice(2)
if (!phone || !name || !['admin', 'mandi_admin'].includes(role)) {
  console.error('Usage: npm run create-admin -- <phone> "<name>" [admin|mandi_admin]'); process.exit(1)
}
const h = await connectDb(loadConfig())
const [u] = await h.db.insert(users).values({ phone: normalizePhone(phone), name, role: role as 'admin' }).returning({ id: users.id })
console.log(`Created ${role} ${u!.id}. They can now sign in with an OTP sent to ${normalizePhone(phone)}.`)
await h.close()
