import { sql } from 'drizzle-orm'
import type { Db } from '../db/client'
import * as s from '../db/schema'

/** Demo dataset mirroring the frontend's sample data (consistent states). Phones are fictional test numbers. */
export async function seedDemo(db: Db) {
  const [{ n } = { n: 0 }] = await db.select({ n: sql<number>`count(*)::int` }).from(s.users)
  if (n > 0) return { skipped: true as const }
  return db.transaction(async (tx) => {
    const mk = async (phone: string, role: 'farmer' | 'buyer' | 'mandi_admin' | 'admin', name: string, language: 'hi' | 'en' | 'mr' = 'hi') =>
      (await tx.insert(s.users).values({ phone, role, name, language }).returning({ id: s.users.id }))[0]!.id

    const mandiRows = await tx.insert(s.mandis).values([
      { name: 'Neemuch Mandi', district: 'Neemuch', state: 'Madhya Pradesh', latitude: 24.4764, longitude: 74.8624 },
      { name: 'Indore APMC', district: 'Indore', state: 'Madhya Pradesh', latitude: 22.7196, longitude: 75.8577 },
      { name: 'Mandsaur Krishi Mandi', district: 'Mandsaur', state: 'Madhya Pradesh', latitude: 24.0725, longitude: 75.069 },
      { name: 'Nashik APMC', district: 'Nashik', state: 'Maharashtra', latitude: 19.9975, longitude: 73.7898 },
      { name: 'Ujjain Grain Market', district: 'Ujjain', state: 'Madhya Pradesh', latitude: 23.1765, longitude: 75.7885 },
      { name: 'Karnal Mandi', district: 'Karnal', state: 'Haryana', latitude: 29.6857, longitude: 76.9905 },
    ]).returning()
    const mandi = Object.fromEntries(mandiRows.map((m) => [m.district, m.id]))

    const series: [string, string, number[]][] = [
      ['Neemuch', 'soybean', [4500, 4550, 4610, 4580, 4650, 4700, 4720]],
      ['Indore', 'wheat', [2390, 2410, 2420, 2450, 2460, 2470, 2480]],
      ['Mandsaur', 'mustard', [5600, 5580, 5520, 5490, 5470, 5460, 5450]],
      ['Nashik', 'onion', [1600, 1650, 1720, 1750, 1800, 1820, 1850]],
      ['Ujjain', 'chana', [5850, 5880, 5900, 5920, 5950, 5970, 5980]],
      ['Karnal', 'paddy', [3200, 3180, 3160, 3150, 3140, 3130, 3120]],
    ]
    const day = 86400_000
    for (const [d, crop, prices] of series) {
      await tx.insert(s.mandiCrops).values({ mandiId: mandi[d]!, cropId: crop })
      await tx.insert(s.priceObservations).values(prices.map((p, i) => ({
        mandiId: mandi[d]!, cropId: crop, price: String(p), source: 'import', observedAt: new Date(Date.now() - (prices.length - 1 - i) * day - 3600_000),
      })))
      const [a, b] = [prices.at(-2)!, prices.at(-1)!]
      if (a !== b) await tx.insert(s.priceAlerts).values({ cropId: crop, mandiId: mandi[d]!, oldPrice: String(a), newPrice: String(b),
        changePercent: (((b - a) / a) * 100).toFixed(2), direction: b > a ? 'up' : 'down' })
    }

    const admin = await mk('+919000000101', 'admin', 'Platform Admin', 'en')
    const staff = await mk('+919000000100', 'mandi_admin', 'Neemuch Mandi Officer')
    await tx.insert(s.mandiAdmins).values([{ userId: staff, mandiId: mandi.Neemuch! }, { userId: staff, mandiId: mandi.Indore! }])

    const farmerSpecs = [
      ['+919826145120', 'Ramesh Patel', 'Pipliya Mandi, Malwa', 'Mandsaur'], ['+919414078219', 'Baldev Singh', 'Kotra, Mandsaur', 'Mandsaur'],
      ['+919755211409', 'Savita Bai', 'Barwaha, Khargone', 'Indore'], ['+919893462155', 'Jagdish Meena', 'Shamgarh, Ratlam', 'Neemuch'],
    ] as const
    const F: string[] = []
    for (const [phone, name, village, m] of farmerSpecs) {
      const id = await mk(phone, 'farmer', name)
      await tx.insert(s.farmers).values({ userId: id, village, preferredMandiId: mandi[m]! }); F.push(id)
    }
    const buyerSpecs = [
      ['+919000000001', 'AgroHarvest Agri-Ventures', 'institutional', true, 120, 25, 'wheat', 500],
      ['+919000000002', 'Malwa Oil & Flour Mills', 'processor', true, 115, 25, 'soybean', 350],
      ['+919000000003', 'Kisan Seva Farmers Producer Org', 'fpo', true, 122.5, 25, 'chana', 200],
      ['+919000000004', 'FreshField Foods Network', 'retail', false, 105, 25, 'mustard', 150],
    ] as const
    const B: string[] = []
    for (const [phone, name, type, verified, sum, count, crop, qty] of buyerSpecs) {
      const id = await mk(phone, 'buyer', name, 'en')
      await tx.insert(s.buyers).values({ userId: id, businessName: name, type, verified, verifiedAt: verified ? new Date() : null, ratingSum: String(sum), ratingCount: count })
      await tx.insert(s.buyerDemands).values({ buyerId: id, cropId: crop, quantityQtl: String(qty) }); B.push(id)
    }

    const L = (await tx.insert(s.lots).values([
      { farmerId: F[0]!, cropId: 'soybean', quantityQtl: '45', grade: 'A', status: 'listed', mandiId: mandi.Neemuch },
      { farmerId: F[0]!, cropId: 'wheat', quantityQtl: '80', grade: 'A', status: 'pickedup', mandiId: mandi.Indore },
      { farmerId: F[1]!, cropId: 'mustard', quantityQtl: '35', grade: 'B', status: 'matched', mandiId: mandi.Mandsaur },
      { farmerId: F[2]!, cropId: 'chana', quantityQtl: '60', grade: 'A', status: 'paid', mandiId: mandi.Ujjain },
      { farmerId: F[3]!, cropId: 'wheat', quantityQtl: '120', grade: 'B', status: 'listed', mandiId: mandi.Neemuch },
      { farmerId: F[1]!, cropId: 'soybean', quantityQtl: '50', grade: 'C', status: 'listed', mandiId: mandi.Neemuch },
    ]).returning({ id: s.lots.id })).map((x) => x.id)

    const now = new Date()
    const O = (await tx.insert(s.offers).values([
      { lotId: L[1]!, buyerId: B[0]!, pricePerQtl: '2490', status: 'accepted', decidedAt: now },
      { lotId: L[0]!, buyerId: B[1]!, pricePerQtl: '4750', status: 'pending' },
      { lotId: L[2]!, buyerId: B[3]!, pricePerQtl: '5420', status: 'accepted', decidedAt: now },
      { lotId: L[3]!, buyerId: B[2]!, pricePerQtl: '6010', status: 'accepted', decidedAt: now },
      { lotId: L[4]!, buyerId: B[0]!, pricePerQtl: '2420', status: 'pending' },
      { lotId: L[0]!, buyerId: B[2]!, pricePerQtl: '4680', status: 'rejected', decidedAt: now },
    ]).returning({ id: s.offers.id })).map((x) => x.id)

    const lotInfo = async (i: number) => (await tx.select().from(s.lots).where(sql`${s.lots.id} = ${L[i]!}`))[0]!
    const mkTxn = async (offer: number, lot: number, buyer: number, offerPrice: string, extra: Partial<typeof s.transactions.$inferInsert>) => {
      const l = await lotInfo(lot)
      return (await tx.insert(s.transactions).values({ offerId: O[offer]!, lotId: l.id, farmerId: l.farmerId, buyerId: B[buyer]!, quantityQtl: l.quantityQtl, pricePerQtl: offerPrice, ...extra }).returning({ id: s.transactions.id }))[0]!.id
    }
    const T1 = await mkTxn(0, 1, 0, '2490', { paymentStatus: 'in_escrow', logisticsStatus: 'in_transit' })
    await mkTxn(2, 2, 3, '5420', { paymentStatus: 'pending', logisticsStatus: 'pickup_scheduled' })
    const T3 = await mkTxn(3, 3, 2, '6010', { paymentStatus: 'paid', logisticsStatus: 'delivered', paidAt: now, deliveredAt: now })

    await tx.insert(s.grievances).values([
      { transactionId: T1, raisedBy: F[0]!, message: 'Transporter truck delayed by 4 hours; small weight difference observed on weighing slip.', status: 'in_review' },
      { transactionId: T3, raisedBy: F[2]!, message: 'Bank transfer acknowledgment slip was uploaded late by the buyer.', status: 'resolved', resolutionNote: 'Buyer confirmed; slip verified.', resolvedBy: staff, resolvedAt: now },
    ])
    return { skipped: false as const, admin, staff }
  })
}
