import { loadConfig } from '../config'
import { connectDb } from '../db/client'
import { migrate } from '../db/migrate'

const h = await connectDb(loadConfig())
const ran = await migrate(h)
console.log(ran.length ? `Applied: ${ran.join(', ')}` : 'Database is up to date')
await h.close()
