import { loadConfig } from '../config'
import { connectDb } from '../db/client'
import { migrate } from '../db/migrate'
import { seedDemo } from './seed-data'

const cfg = loadConfig()
if (cfg.NODE_ENV === 'production' && process.env.SEED_ALLOW_PRODUCTION !== 'yes') {
  console.error('Refusing to seed demo data in production (set SEED_ALLOW_PRODUCTION=yes to override).'); process.exit(1)
}
const h = await connectDb(cfg)
await migrate(h)
const r = await seedDemo(h.db)
console.log(r.skipped ? 'Database already has users - nothing seeded.' : 'Demo data seeded. Sign in with any seeded phone, e.g. +919826145120 (farmer), +919000000001 (buyer), +919000000100 (mandi admin), +919000000101 (admin).')
await h.close()
