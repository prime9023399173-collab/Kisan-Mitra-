import { defineConfig } from 'vitest/config'
export default defineConfig({
  test: { include: ['test/**/*.test.ts'], testTimeout: 60_000, hookTimeout: 120_000, fileParallelism: !process.env.TEST_DATABASE_URL },
})
