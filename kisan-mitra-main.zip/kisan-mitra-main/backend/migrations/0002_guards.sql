-- Data-integrity guards that hold no matter which client or script touches the DB.

CREATE FUNCTION touch_updated_at() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN NEW.updated_at := now_ms(); RETURN NEW; END $$;

CREATE TRIGGER users_touch        BEFORE UPDATE ON users        FOR EACH ROW EXECUTE FUNCTION touch_updated_at();
CREATE TRIGGER lots_touch         BEFORE UPDATE ON lots         FOR EACH ROW EXECUTE FUNCTION touch_updated_at();
CREATE TRIGGER transactions_touch BEFORE UPDATE ON transactions FOR EACH ROW EXECUTE FUNCTION touch_updated_at();
CREATE TRIGGER grievances_touch   BEFORE UPDATE ON grievances   FOR EACH ROW EXECUTE FUNCTION touch_updated_at();
CREATE TRIGGER demands_touch      BEFORE UPDATE ON buyer_demands FOR EACH ROW EXECUTE FUNCTION touch_updated_at();

CREATE FUNCTION guard_lot_status() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.status = OLD.status THEN RETURN NEW; END IF;
  IF (OLD.status::text, NEW.status::text) IN
     (('listed','matched'),('listed','cancelled'),('matched','pickedup'),
      ('matched','cancelled'),('pickedup','paid'),('pickedup','cancelled')) THEN RETURN NEW; END IF;
  RAISE EXCEPTION 'illegal lot status transition % -> %', OLD.status, NEW.status USING ERRCODE = '23514';
END $$;
CREATE TRIGGER lots_status_guard BEFORE UPDATE OF status ON lots FOR EACH ROW EXECUTE FUNCTION guard_lot_status();

CREATE FUNCTION guard_offer_status() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.status = OLD.status THEN RETURN NEW; END IF;
  IF OLD.status = 'pending' THEN RETURN NEW; END IF;
  RAISE EXCEPTION 'offer is already % and cannot change', OLD.status USING ERRCODE = '23514';
END $$;
CREATE TRIGGER offers_status_guard BEFORE UPDATE OF status ON offers FOR EACH ROW EXECUTE FUNCTION guard_offer_status();

CREATE FUNCTION guard_transaction() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.offer_id <> OLD.offer_id OR NEW.lot_id <> OLD.lot_id OR NEW.farmer_id <> OLD.farmer_id
     OR NEW.buyer_id <> OLD.buyer_id OR NEW.quantity_qtl <> OLD.quantity_qtl OR NEW.price_per_qtl <> OLD.price_per_qtl THEN
    RAISE EXCEPTION 'transaction terms are immutable' USING ERRCODE = '23514';
  END IF;
  IF NEW.payment_status <> OLD.payment_status AND
     (OLD.payment_status::text, NEW.payment_status::text) NOT IN
     (('pending','in_escrow'),('in_escrow','paid'),('in_escrow','refunded')) THEN
    RAISE EXCEPTION 'illegal payment transition % -> %', OLD.payment_status, NEW.payment_status USING ERRCODE = '23514';
  END IF;
  IF NEW.logistics_status <> OLD.logistics_status AND
     (OLD.logistics_status::text, NEW.logistics_status::text) NOT IN
     (('pickup_scheduled','in_transit'),('in_transit','delivered')) THEN
    RAISE EXCEPTION 'illegal logistics transition % -> %', OLD.logistics_status, NEW.logistics_status USING ERRCODE = '23514';
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER transactions_guard BEFORE UPDATE ON transactions FOR EACH ROW EXECUTE FUNCTION guard_transaction();

CREATE FUNCTION guard_grievance_status() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.status = OLD.status THEN RETURN NEW; END IF;
  IF (OLD.status::text, NEW.status::text) IN (('open','in_review'),('open','resolved'),('in_review','resolved')) THEN RETURN NEW; END IF;
  RAISE EXCEPTION 'illegal grievance transition % -> %', OLD.status, NEW.status USING ERRCODE = '23514';
END $$;
CREATE TRIGGER grievances_status_guard BEFORE UPDATE OF status ON grievances FOR EACH ROW EXECUTE FUNCTION guard_grievance_status();

CREATE FUNCTION audit_log_immutable() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN RAISE EXCEPTION 'audit_log is append-only' USING ERRCODE = '23514'; END $$;
CREATE TRIGGER audit_no_update BEFORE UPDATE OR DELETE ON audit_log FOR EACH ROW EXECUTE FUNCTION audit_log_immutable();
CREATE TRIGGER audit_no_truncate BEFORE TRUNCATE ON audit_log FOR EACH STATEMENT EXECUTE FUNCTION audit_log_immutable();

CREATE VIEW v_latest_price AS
SELECT mc.mandi_id, mc.crop_id, p.price, p.min_price, p.max_price, p.arrivals_qtl, p.observed_at
FROM mandi_crops mc
CROSS JOIN LATERAL (
  SELECT po.price, po.min_price, po.max_price, po.arrivals_qtl, po.observed_at
  FROM price_observations po
  WHERE po.mandi_id = mc.mandi_id AND po.crop_id = mc.crop_id
  ORDER BY po.observed_at DESC, po.id DESC LIMIT 1
) p;
