-- Kisan Mitra core schema (PostgreSQL 15+). Money = INR, quantities = quintals.

CREATE TYPE user_role        AS ENUM ('farmer','buyer','mandi_admin','admin');
CREATE TYPE user_status      AS ENUM ('active','suspended');
CREATE TYPE lang_code        AS ENUM ('hi','en','mr');
CREATE TYPE crop_grade       AS ENUM ('A','B','C');
CREATE TYPE lot_status       AS ENUM ('listed','matched','pickedup','paid','cancelled');
CREATE TYPE offer_status     AS ENUM ('pending','accepted','rejected','withdrawn');
CREATE TYPE payment_status   AS ENUM ('pending','in_escrow','paid','refunded');
CREATE TYPE logistics_status AS ENUM ('pickup_scheduled','in_transit','delivered');
CREATE TYPE grievance_status AS ENUM ('open','in_review','resolved');
CREATE TYPE buyer_type       AS ENUM ('institutional','processor','fpo','retail','trader');

-- Millisecond-precision clock so timestamps round-trip through JS Dates (keyset pagination relies on it).
CREATE FUNCTION now_ms() RETURNS timestamptz LANGUAGE sql VOLATILE AS
$$ SELECT date_trunc('milliseconds', clock_timestamp()) $$;

-- ───────────── identity ─────────────
CREATE TABLE users (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  phone         text NOT NULL UNIQUE CHECK (phone ~ '^\+91[6-9][0-9]{9}$'),
  role          user_role   NOT NULL,
  name          text        NOT NULL CHECK (length(btrim(name)) BETWEEN 2 AND 120),
  language      lang_code   NOT NULL DEFAULT 'hi',
  status        user_status NOT NULL DEFAULT 'active',
  last_login_at timestamptz,
  created_at    timestamptz NOT NULL DEFAULT now_ms(),
  updated_at    timestamptz NOT NULL DEFAULT now_ms()
);

CREATE TABLE otp_challenges (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  phone       text        NOT NULL,
  code_hash   text        NOT NULL,
  attempts    integer     NOT NULL DEFAULT 0,
  expires_at  timestamptz NOT NULL,
  consumed_at timestamptz,
  created_at  timestamptz NOT NULL DEFAULT now_ms()
);
CREATE INDEX otp_challenges_phone_created_idx ON otp_challenges (phone, created_at DESC);

CREATE TABLE refresh_tokens (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  family_id   uuid NOT NULL,
  token_hash  text NOT NULL UNIQUE,
  expires_at  timestamptz NOT NULL,
  revoked_at  timestamptz,
  replaced_by uuid,
  user_agent  text,
  created_at  timestamptz NOT NULL DEFAULT now_ms()
);
CREATE INDEX refresh_tokens_user_idx   ON refresh_tokens (user_id);
CREATE INDEX refresh_tokens_family_idx ON refresh_tokens (family_id);

-- ───────────── reference + market data ─────────────
CREATE TABLE crops (
  id      text PRIMARY KEY CHECK (id ~ '^[a-z][a-z0-9_]*$'),
  name    text NOT NULL,
  name_hi text NOT NULL,
  name_mr text NOT NULL
);

CREATE TABLE mandis (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name       text NOT NULL,
  district   text NOT NULL,
  state      text NOT NULL,
  latitude   double precision CHECK (latitude  BETWEEN -90  AND 90),
  longitude  double precision CHECK (longitude BETWEEN -180 AND 180),
  created_at timestamptz NOT NULL DEFAULT now_ms(),
  UNIQUE (name, district, state)
);

CREATE TABLE mandi_admins (
  user_id  uuid NOT NULL REFERENCES users(id)  ON DELETE CASCADE,
  mandi_id uuid NOT NULL REFERENCES mandis(id) ON DELETE CASCADE,
  PRIMARY KEY (user_id, mandi_id)
);

CREATE TABLE mandi_crops (
  mandi_id uuid NOT NULL REFERENCES mandis(id) ON DELETE CASCADE,
  crop_id  text NOT NULL REFERENCES crops(id),
  PRIMARY KEY (mandi_id, crop_id)
);

-- Append-only price time series (modal price, INR/quintal).
CREATE TABLE price_observations (
  id           bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  mandi_id     uuid NOT NULL REFERENCES mandis(id) ON DELETE CASCADE,
  crop_id      text NOT NULL REFERENCES crops(id),
  price        numeric(10,2) NOT NULL CHECK (price > 0 AND price < 1000000),
  min_price    numeric(10,2) CHECK (min_price > 0),
  max_price    numeric(10,2) CHECK (max_price > 0),
  arrivals_qtl numeric(12,2) CHECK (arrivals_qtl >= 0),
  source       text NOT NULL DEFAULT 'admin' CHECK (source IN ('admin','agmarknet','import')),
  recorded_by  uuid REFERENCES users(id) ON DELETE SET NULL,
  observed_at  timestamptz NOT NULL DEFAULT now_ms(),
  CHECK (min_price IS NULL OR max_price IS NULL OR min_price <= max_price)
);
CREATE INDEX price_obs_series_idx ON price_observations (mandi_id, crop_id, observed_at DESC, id DESC);

CREATE TABLE msp_rates (
  crop_id        text NOT NULL REFERENCES crops(id),
  effective_from date NOT NULL,
  season         text NOT NULL,
  price          numeric(10,2) NOT NULL CHECK (price > 0),
  PRIMARY KEY (crop_id, effective_from)
);

CREATE TABLE price_alerts (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  crop_id        text NOT NULL REFERENCES crops(id),
  mandi_id       uuid NOT NULL REFERENCES mandis(id) ON DELETE CASCADE,
  old_price      numeric(10,2) NOT NULL,
  new_price      numeric(10,2) NOT NULL,
  change_percent numeric(7,2)  NOT NULL,
  direction      text NOT NULL CHECK (direction IN ('up','down')),
  created_at     timestamptz NOT NULL DEFAULT now_ms()
);
CREATE INDEX price_alerts_created_idx ON price_alerts (created_at DESC, id DESC);

-- ───────────── participants ─────────────
CREATE TABLE farmers (
  user_id             uuid PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  village             text NOT NULL,
  district            text,
  state               text,
  preferred_mandi_id  uuid REFERENCES mandis(id) ON DELETE SET NULL
);

CREATE TABLE buyers (
  user_id       uuid PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  business_name text NOT NULL CHECK (length(btrim(business_name)) >= 2),
  type          buyer_type NOT NULL,
  gstin         text UNIQUE CHECK (gstin ~ '^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z][1-9A-Z]Z[0-9A-Z]$'),
  verified      boolean NOT NULL DEFAULT false,
  verified_at   timestamptz,
  verified_by   uuid REFERENCES users(id) ON DELETE SET NULL,
  rating_sum    numeric(10,2) NOT NULL DEFAULT 0 CHECK (rating_sum >= 0),
  rating_count  integer NOT NULL DEFAULT 0 CHECK (rating_count >= 0),
  CHECK (NOT verified OR verified_at IS NOT NULL)
);

CREATE TABLE buyer_demands (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  buyer_id     uuid NOT NULL REFERENCES buyers(user_id) ON DELETE CASCADE,
  crop_id      text NOT NULL REFERENCES crops(id),
  quantity_qtl numeric(12,2) NOT NULL CHECK (quantity_qtl > 0),
  max_price    numeric(10,2) CHECK (max_price > 0),
  active       boolean NOT NULL DEFAULT true,
  updated_at   timestamptz NOT NULL DEFAULT now_ms(),
  UNIQUE (buyer_id, crop_id)
);

-- ───────────── marketplace ─────────────
CREATE TABLE lots (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  farmer_id      uuid NOT NULL REFERENCES farmers(user_id),
  crop_id        text NOT NULL REFERENCES crops(id),
  quantity_qtl   numeric(10,2) NOT NULL CHECK (quantity_qtl > 0 AND quantity_qtl <= 100000),
  grade          crop_grade NOT NULL,
  status         lot_status NOT NULL DEFAULT 'listed',
  asking_price   numeric(10,2) CHECK (asking_price > 0),
  mandi_id       uuid REFERENCES mandis(id) ON DELETE SET NULL,
  notes          text CHECK (length(notes) <= 1000),
  created_at     timestamptz NOT NULL DEFAULT now_ms(),
  updated_at     timestamptz NOT NULL DEFAULT now_ms()
);
CREATE INDEX lots_market_idx ON lots (crop_id, created_at DESC, id DESC) WHERE status = 'listed';
CREATE INDEX lots_farmer_idx ON lots (farmer_id, created_at DESC, id DESC);
CREATE INDEX lots_mandi_idx  ON lots (mandi_id);

CREATE TABLE offers (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lot_id        uuid NOT NULL REFERENCES lots(id),
  buyer_id      uuid NOT NULL REFERENCES buyers(user_id),
  price_per_qtl numeric(10,2) NOT NULL CHECK (price_per_qtl > 0 AND price_per_qtl < 1000000),
  status        offer_status NOT NULL DEFAULT 'pending',
  message       text CHECK (length(message) <= 500),
  created_at    timestamptz NOT NULL DEFAULT now_ms(),
  decided_at    timestamptz,
  CHECK ((status = 'pending') = (decided_at IS NULL))
);
CREATE INDEX offers_lot_idx   ON offers (lot_id, status);
CREATE INDEX offers_buyer_idx ON offers (buyer_id, created_at DESC, id DESC);
CREATE UNIQUE INDEX offers_one_accepted_per_lot ON offers (lot_id) WHERE status = 'accepted';
CREATE UNIQUE INDEX offers_one_pending_per_buyer ON offers (lot_id, buyer_id) WHERE status = 'pending';

CREATE TABLE transactions (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  offer_id         uuid NOT NULL UNIQUE REFERENCES offers(id),
  lot_id           uuid NOT NULL REFERENCES lots(id),
  farmer_id        uuid NOT NULL REFERENCES farmers(user_id),
  buyer_id         uuid NOT NULL REFERENCES buyers(user_id),
  quantity_qtl     numeric(10,2) NOT NULL CHECK (quantity_qtl > 0),
  price_per_qtl    numeric(10,2) NOT NULL CHECK (price_per_qtl > 0),
  amount_total     numeric(14,2) GENERATED ALWAYS AS (quantity_qtl * price_per_qtl) STORED,
  payment_status   payment_status   NOT NULL DEFAULT 'pending',
  logistics_status logistics_status NOT NULL DEFAULT 'pickup_scheduled',
  payment_ref      text,
  pickup_at        timestamptz,
  vehicle_no       text,
  paid_at          timestamptz,
  delivered_at     timestamptz,
  created_at       timestamptz NOT NULL DEFAULT now_ms(),
  updated_at       timestamptz NOT NULL DEFAULT now_ms(),
  CONSTRAINT paid_requires_delivery  CHECK (payment_status <> 'paid' OR logistics_status = 'delivered'),
  CONSTRAINT movement_requires_funds CHECK (logistics_status = 'pickup_scheduled' OR payment_status <> 'pending')
);
CREATE INDEX transactions_farmer_idx ON transactions (farmer_id, created_at DESC, id DESC);
CREATE INDEX transactions_buyer_idx  ON transactions (buyer_id,  created_at DESC, id DESC);
CREATE INDEX transactions_lot_idx    ON transactions (lot_id);

CREATE TABLE buyer_ratings (
  transaction_id uuid PRIMARY KEY REFERENCES transactions(id),
  buyer_id       uuid NOT NULL REFERENCES buyers(user_id),
  stars          smallint NOT NULL CHECK (stars BETWEEN 1 AND 5),
  comment        text CHECK (length(comment) <= 500),
  created_at     timestamptz NOT NULL DEFAULT now_ms()
);

CREATE TABLE grievances (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  transaction_id  uuid NOT NULL REFERENCES transactions(id),
  raised_by       uuid NOT NULL REFERENCES users(id),
  message         text NOT NULL CHECK (length(btrim(message)) BETWEEN 5 AND 2000),
  status          grievance_status NOT NULL DEFAULT 'open',
  resolution_note text,
  resolved_by     uuid REFERENCES users(id) ON DELETE SET NULL,
  resolved_at     timestamptz,
  created_at      timestamptz NOT NULL DEFAULT now_ms(),
  updated_at      timestamptz NOT NULL DEFAULT now_ms(),
  CHECK ((status = 'resolved') = (resolved_at IS NOT NULL))
);
CREATE INDEX grievances_txn_idx    ON grievances (transaction_id);
CREATE INDEX grievances_status_idx ON grievances (status, created_at DESC);

-- ───────────── platform ─────────────
CREATE TABLE notifications (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id    uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind       text NOT NULL,
  payload    jsonb NOT NULL DEFAULT '{}'::jsonb,
  read_at    timestamptz,
  created_at timestamptz NOT NULL DEFAULT now_ms()
);
CREATE INDEX notifications_user_idx   ON notifications (user_id, created_at DESC, id DESC);
CREATE INDEX notifications_unread_idx ON notifications (user_id) WHERE read_at IS NULL;

CREATE TABLE audit_log (
  id            bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  actor_user_id uuid,
  action        text NOT NULL,
  entity        text NOT NULL,
  entity_id     text NOT NULL,
  data          jsonb NOT NULL DEFAULT '{}'::jsonb,
  at            timestamptz NOT NULL DEFAULT now_ms()
);
CREATE INDEX audit_entity_idx ON audit_log (entity, entity_id, at DESC);

CREATE TABLE idempotency_keys (
  user_id      uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  key          text NOT NULL,
  request_hash text NOT NULL,
  status_code  integer,
  response     text,
  created_at   timestamptz NOT NULL DEFAULT now_ms(),
  PRIMARY KEY (user_id, key)
);
CREATE INDEX idempotency_created_idx ON idempotency_keys (created_at);
