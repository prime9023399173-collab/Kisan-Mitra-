INSERT INTO crops (id, name, name_hi, name_mr) VALUES
  ('wheat',   'Wheat',   'गेहूं',   'गहू'),
  ('soybean', 'Soybean', 'सोयाबीन', 'सोयाबीन'),
  ('mustard', 'Mustard', 'सरसों',   'मोहरी'),
  ('chana',   'Chana',   'चना',     'हरभरा'),
  ('onion',   'Onion',   'प्याज',   'कांदा'),
  ('cotton',  'Cotton',  'कपास',    'कापूस'),
  ('paddy',   'Paddy',   'धान',     'भात')
ON CONFLICT (id) DO NOTHING;
