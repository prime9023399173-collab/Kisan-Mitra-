import { sql } from 'drizzle-orm'
import { createApp } from '../src/app'
import { loadConfig } from '../src/config'
import { connectDb, type DbHandle } from '../src/db/client'
import { migrate } from '../src/db/migrate'
import { CHANNEL, EventBus } from '../src/lib/events'
import { seedDemo } from '../src/scripts/seed-data'

export interface Ctx { h: DbHandle; app: ReturnType<typeof createApp>; bus: EventBus; stop: () => Promise<void>; sent: Map<string, string> }

/** Fresh isolated DB per call. Uses TEST_DATABASE_URL (real Postgres) if set, else in-memory PGlite. */
export async function setup(opts: { seed?: boolean; env?: Record<string, string> } = {}): Promise<Ctx> {
  const cfg = loadConfig({ NODE_ENV: 'test', OTP_FIXED_CODE: '123456', LOG_LEVEL: 'silent', RATE_LIMIT_PER_MIN: '100000', AUTH_RATE_LIMIT_PER_MIN: '100000', ...(process.env.TEST_DATABASE_URL ? { DATABASE_URL: process.env.TEST_DATABASE_URL } : {}), ...opts.env })
  const h = await connectDb(cfg, { memory: !process.env.TEST_DATABASE_URL })
  if (h.kind === 'pg') await h.execRaw('DROP SCHEMA public CASCADE; CREATE SCHEMA public;')
  await migrate(h)
  if (opts.seed) await seedDemo(h.db)
  const bus = new EventBus()
  const stopListen = await h.listen(CHANNEL, bus)
  const sent = new Map<string, string>()
  const app = createApp({ db: h.db, cfg, bus, otp: { send: async (p, c) => { sent.set(p, c) } } })
  return { h, app, bus, sent, stop: async () => { await stopListen(); await h.close() } }
}

export type Client = ReturnType<typeof client>
export function client(app: Ctx['app'], token?: string) {
  const call = async (method: string, path: string, body?: unknown, headers: Record<string, string> = {}) => {
    const res = await app.request(`/api/v1${path}`, {
      method, headers: { 'content-type': 'application/json', ...(token ? { authorization: `Bearer ${token}` } : {}), ...headers },
      body: body === undefined ? undefined : JSON.stringify(body),
    })
    const text = await res.text()
    let json: any; try { json = JSON.parse(text) } catch { json = text }
    return { status: res.status, json, headers: res.headers }
  }
  return { get: (p: string) => call('GET', p), post: (p: string, b?: unknown, h?: Record<string, string>) => call('POST', p, b ?? {}, h), put: (p: string, b?: unknown) => call('PUT', p, b ?? {}), patch: (p: string, b?: unknown) => call('PATCH', p, b ?? {}) }
}

export async function login(ctx: Ctx, phone: string, registration?: unknown) {
  const anon = client(ctx.app)
  await anon.post('/auth/otp', { phone })
  const r = await anon.post('/auth/verify', { phone, code: '123456', registration })
  if (r.status !== 200) throw new Error(`login failed ${r.status} ${JSON.stringify(r.json)}`)
  return { ...r.json, api: client(ctx.app, r.json.accessToken) } as { user: { id: string }; accessToken: string; refreshToken: string; api: Client }
}

export const rows = async <T = any>(h: DbHandle, q: ReturnType<typeof sql>) => ((await h.db.execute(q)) as unknown as { rows: T[] }).rows
