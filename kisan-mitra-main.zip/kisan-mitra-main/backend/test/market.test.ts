import { afterAll, beforeAll, describe, expect, it } from 'vitest'
import { client, login, rows, setup, type Ctx, type Client } from './helpers'
import { sql } from 'drizzle-orm'

let ctx: Ctx
let admin: { api: Client }, staff: { api: Client }, farmer: { api: Client; accessToken: string }
let neemuch: string, mandsaur: string
beforeAll(async () => {
  ctx = await setup({ seed: true })
  admin = await login(ctx, '+919000000101'); staff = await login(ctx, '+919000000100'); farmer = await login(ctx, '+919826145120')
  const m = await rows(ctx.h, sql`select id, district from mandis`)
  neemuch = m.find((x) => x.district === 'Neemuch').id; mandsaur = m.find((x) => x.district === 'Mandsaur').id
})
afterAll(() => ctx.stop())

describe('market data', () => {
  it('is publicly readable: latest price + 7-day history in the frontend shape', async () => {
    const anon = client(ctx.app)
    const r = await anon.get('/prices?crop=soybean')
    expect(r.status).toBe(200)
    expect(r.json.items[0]).toMatchObject({ mandi: 'Neemuch Mandi', crop: 'Soybean', price: 4720, priceHistory: [4500, 4550, 4610, 4580, 4650, 4700, 4720] })
    expect((await anon.get('/crops')).json.items).toHaveLength(7)
    expect((await anon.get('/price-alerts')).json.items.length).toBeGreaterThan(0)
  })

  it('finds the nearest mandis', async () => {
    const anon = client(ctx.app)
    const r = await anon.get('/mandis?near=22.72,75.86&radiusKm=100')
    expect(r.json.items.map((m: any) => m.name)).toEqual(expect.arrayContaining(['Indore APMC', 'Ujjain Grain Market']))
    expect(r.json.items[0].name).toBe('Indore APMC')
    expect(r.json.items.some((m: any) => m.name === 'Karnal Mandi')).toBe(false)
  })

  it('mandi staff can only update their own mandis; alerts fire past the threshold', async () => {
    expect((await staff.api.post(`/mandis/${mandsaur}/prices`, { cropId: 'mustard', price: 5000 })).status).toBe(403)
    expect((await farmer.api.post(`/mandis/${neemuch}/prices`, { cropId: 'soybean', price: 5000 })).status).toBe(403)
    const stream: any[] = []; const off = ctx.bus.subscribe((e) => stream.push(e))
    const r = await staff.api.post(`/mandis/${neemuch}/prices`, { cropId: 'soybean', price: 4900, arrivalsQtl: 1200 })
    expect(r.status).toBe(201); expect(r.json).toMatchObject({ previousPrice: 4720, alertCreated: true })
    await new Promise((res) => setTimeout(res, 150)); off()
    expect(stream.find((e) => e.type === 'price_alert')?.data).toMatchObject({ direction: 'up', cropId: 'soybean' })
    const tiny = await staff.api.post(`/mandis/${neemuch}/prices`, { cropId: 'soybean', price: 4905 })
    expect(tiny.json.alertCreated).toBe(false)
    const now = await client(ctx.app).get(`/prices?crop=soybean&mandiId=${neemuch}`)
    expect(now.json.items[0].price).toBe(4905)
  })

  it('blocks fat-finger price jumps unless confirmed', async () => {
    const bad = await admin.api.post(`/mandis/${neemuch}/prices`, { cropId: 'soybean', price: 49050 })
    expect(bad.status).toBe(422); expect(bad.json.code).toBe('price_change_too_large')
    expect((await admin.api.post(`/mandis/${neemuch}/prices`, { cropId: 'soybean', price: 49050, confirmLargeChange: true })).status).toBe(201)
  })

  it('gives sell-now/wait advice from the 3-day trend, flags prices below MSP', async () => {
    const anon = client(ctx.app)
    expect((await anon.get('/advisory?crop=onion')).json).toMatchObject({ recommendation: 'wait' })
    expect((await anon.get('/advisory?crop=wheat')).json).toMatchObject({ recommendation: 'sell_now', belowMsp: false })
    await admin.api.put('/admin/msp', { cropId: 'wheat', effectiveFrom: '2026-04-01', season: 'Rabi 2026-27 (test value)', price: 3000 })
    expect((await anon.get('/advisory?crop=wheat')).json).toMatchObject({ mspPrice: 3000, belowMsp: true })
  })

  it('serves the daily-close history series', async () => {
    const r = await client(ctx.app).get(`/prices/history?mandiId=${mandsaur}&crop=mustard&days=30`)
    expect(r.json.items.map((x: any) => x.price)).toEqual([5600, 5580, 5520, 5490, 5470, 5460, 5450])
  })
})
