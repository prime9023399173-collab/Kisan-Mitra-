import { afterAll, beforeAll, describe, expect, it } from 'vitest'
import { rows, setup, type Ctx } from './helpers'
import { sql } from 'drizzle-orm'

let ctx: Ctx
beforeAll(async () => { ctx = await setup({ seed: true }) })
afterAll(() => ctx.stop())

const fails = async (q: string, re: RegExp) => {
  await expect(ctx.h.db.execute(sql.raw(q))).rejects.toSatisfy((e: any) => re.test(String(e?.cause?.message ?? e?.message)))
}

describe('database-level guarantees (hold even for raw SQL)', () => {
  it('lot state machine rejects illegal jumps', async () => {
    await fails(`UPDATE lots SET status='paid' WHERE status='listed'`, /illegal lot status/)
    await fails(`UPDATE lots SET status='listed' WHERE status='paid'`, /illegal lot status/)
  })
  it('decided offers are frozen', async () => {
    await fails(`UPDATE offers SET status='pending', decided_at=NULL WHERE status='accepted'`, /already accepted/)
  })
  it('transactions: no skipping, no early release, no moving goods unfunded, terms immutable', async () => {
    await fails(`UPDATE transactions SET payment_status='paid' WHERE payment_status='pending'`, /illegal payment|paid_requires_delivery/)
    await fails(`UPDATE transactions SET logistics_status='in_transit' WHERE payment_status='pending'`, /movement_requires_funds/)
    await fails(`UPDATE transactions SET logistics_status='delivered' WHERE logistics_status='pickup_scheduled'`, /illegal logistics/)
    await fails(`UPDATE transactions SET price_per_qtl = 1`, /immutable/)
  })
  it('only one accepted offer per lot; one pending per buyer', async () => {
    await fails(`INSERT INTO offers (lot_id, buyer_id, price_per_qtl, status, decided_at)
      SELECT lot_id, buyer_id, 1, 'accepted', now() FROM offers WHERE status='accepted' LIMIT 1`, /offers_one_accepted_per_lot/)
    await fails(`INSERT INTO offers (lot_id, buyer_id, price_per_qtl) SELECT lot_id, buyer_id, 1 FROM offers WHERE status='pending' LIMIT 1`, /offers_one_pending_per_buyer/)
  })
  it('input sanity is enforced by CHECK constraints', async () => {
    await fails(`UPDATE lots SET quantity_qtl = -5`, /check constraint/)
    await fails(`UPDATE users SET phone = '12345' WHERE role='admin'`, /check constraint/)
    await fails(`INSERT INTO price_observations (mandi_id, crop_id, price) SELECT id, 'wheat', 0 FROM mandis LIMIT 1`, /check constraint/)
  })
  it('audit log is append-only; amount_total is computed by the database', async () => {
    await ctx.h.db.execute(sql`INSERT INTO audit_log (action, entity, entity_id) VALUES ('test','x','1')`)
    await fails(`UPDATE audit_log SET action='tampered'`, /append-only/)
    await fails(`DELETE FROM audit_log`, /append-only/)
    const r = await rows(ctx.h, sql`select quantity_qtl::float q, price_per_qtl::float p, amount_total::float a from transactions limit 1`)
    expect(r[0].a).toBeCloseTo(r[0].q * r[0].p, 2)
  })
  it('updated_at moves on update', async () => {
    const before = await rows(ctx.h, sql`select updated_at from lots order by id limit 1`)
    await new Promise((r) => setTimeout(r, 15))
    await ctx.h.db.execute(sql`UPDATE lots SET notes='touched' WHERE id = (select id from lots order by id limit 1)`)
    const after = await rows(ctx.h, sql`select updated_at from lots order by id limit 1`)
    expect(new Date(after[0].updated_at).getTime()).toBeGreaterThan(new Date(before[0].updated_at).getTime())
  })
})
