import { afterAll, beforeAll, describe, expect, it } from 'vitest'
import { login, rows, setup, type Ctx, type Client } from './helpers'
import { sql } from 'drizzle-orm'

let ctx: Ctx
let ramesh: { api: Client; user: { id: string } }, baldev: { api: Client }, agro: { api: Client; user: { id: string } }, malwa: { api: Client }, fresh: { api: Client }
let staff: { api: Client }, admin: { api: Client }
beforeAll(async () => {
  ctx = await setup({ seed: true })
  ramesh = await login(ctx, '+919826145120'); baldev = await login(ctx, '+919414078219')
  agro = await login(ctx, '+919000000001'); malwa = await login(ctx, '+919000000002'); fresh = await login(ctx, '+919000000004')
  staff = await login(ctx, '+919000000100'); admin = await login(ctx, '+919000000101')
})
afterAll(() => ctx.stop())

describe('end-to-end deal flow', () => {
  let lotId: string, offerA: string, offerB: string, txnId: string

  it('farmer lists a lot; it is visible to buyers, hidden from other farmers', async () => {
    const r = await ramesh.api.post('/lots', { cropId: 'wheat', quantity: 40, grade: 'A', askingPrice: 2500 }, { 'Idempotency-Key': 'lot-create-0001' })
    expect(r.status).toBe(201); lotId = r.json.id
    expect(r.json).toMatchObject({ crop: 'Wheat', quantity: 40, grade: 'A', status: 'listed', mandiId: expect.any(String) })
    expect((await agro.api.get(`/lots/${lotId}`)).status).toBe(200)
    expect((await baldev.api.get(`/lots/${lotId}`)).status).toBe(404)
    expect((await agro.api.post('/lots', { cropId: 'wheat', quantity: 1, grade: 'A' })).status).toBe(403)
  })

  it('replays idempotent retries instead of duplicating', async () => {
    const again = await ramesh.api.post('/lots', { cropId: 'wheat', quantity: 40, grade: 'A', askingPrice: 2500 }, { 'Idempotency-Key': 'lot-create-0001' })
    expect(again.status).toBe(201); expect(again.json.id).toBe(lotId); expect(again.headers.get('idempotent-replay')).toBe('true')
    const clash = await ramesh.api.post('/lots', { cropId: 'wheat', quantity: 99, grade: 'A' }, { 'Idempotency-Key': 'lot-create-0001' })
    expect(clash.status).toBe(422)
    const n = await rows(ctx.h, sql`select count(*)::int n from lots where farmer_id = ${ramesh.user.id} and quantity_qtl = 40`)
    expect(n[0].n).toBe(1)
  })

  it('only verified buyers can offer; one open offer per buyer', async () => {
    const un = await fresh.api.post(`/lots/${lotId}/offers`, { price: 2450 })
    expect(un.status).toBe(403); expect(un.json.code).toBe('buyer_not_verified')
    const a = await agro.api.post(`/lots/${lotId}/offers`, { price: 2480 }); expect(a.status).toBe(201); offerA = a.json.id
    const b = await malwa.api.post(`/lots/${lotId}/offers`, { price: 2520 }); expect(b.status).toBe(201); offerB = b.json.id
    expect((await agro.api.post(`/lots/${lotId}/offers`, { price: 2490 })).json.code).toBe('offer_exists')
    expect((await ramesh.api.post(`/lots/${lotId}/offers`, { price: 1 })).status).toBe(403)
    const list = await ramesh.api.get(`/lots/${lotId}/offers`)
    expect(list.json.items.map((o: any) => o.price)).toEqual([2520, 2480])
  })

  it('farmer got notified of both offers', async () => {
    const n = await ramesh.api.get('/notifications?unread=true')
    expect(n.json.items.filter((x: any) => x.kind === 'offer.received').length).toBeGreaterThanOrEqual(2)
    expect((await ramesh.api.post('/notifications/read', { all: true })).json.updated).toBeGreaterThan(0)
    expect((await ramesh.api.get('/notifications?unread=true')).json.unreadCount).toBe(0)
  })

  it('only the owning farmer can accept; accepting is atomic and rejects rivals', async () => {
    expect((await baldev.api.post(`/offers/${offerB}/accept`)).status).toBe(404)
    expect((await agro.api.post(`/offers/${offerB}/accept`)).status).toBe(403)
    const acc = await ramesh.api.post(`/offers/${offerB}/accept`)
    expect(acc.status).toBe(200)
    expect(acc.json).toMatchObject({ quantity: 40, pricePerQtl: 2520, amountTotal: 100800, paymentStatus: 'pending', logisticsStatus: 'pickup_scheduled' })
    txnId = acc.json.id
    const st = await rows(ctx.h, sql`select (select status from lots where id=${lotId}) lot, (select status from offers where id=${offerA}) rival`)
    expect(st[0]).toEqual({ lot: 'matched', rival: 'rejected' })
    expect((await ramesh.api.post(`/offers/${offerA}/accept`)).json.code).toBe('offer_not_pending')
    expect((await agro.api.get('/notifications')).json.items.some((x: any) => x.kind === 'offer.rejected')).toBe(true)
  })

  it('enforces the money/logistics rules', async () => {
    const t = (c: Client, path: string, body: unknown) => c.post(`/transactions/${txnId}/${path}`, body)
    expect((await t(malwa.api, 'logistics', { status: 'in_transit' })).json.code).toBe('escrow_not_funded')
    expect((await t(ramesh.api, 'payment', { status: 'in_escrow' })).status).toBe(403)
    expect((await t(malwa.api, 'payment', { status: 'in_escrow', paymentRef: 'UPI-123' })).json.paymentStatus).toBe('in_escrow')
    expect((await t(ramesh.api, 'logistics', { status: 'in_transit' })).status).toBe(403)
    expect((await t(malwa.api, 'payment', { status: 'paid' })).json.code).toBe('not_delivered')
    const moving = await t(malwa.api, 'logistics', { status: 'in_transit', vehicleNo: 'MP09AB1234' })
    expect(moving.json.logisticsStatus).toBe('in_transit')
    expect((await ramesh.api.get(`/lots/${lotId}`)).json.status).toBe('pickedup')
    expect((await t(malwa.api, 'logistics', { status: 'delivered' })).json.logisticsStatus).toBe('delivered')
    expect((await t(malwa.api, 'payment', { status: 'paid' })).json.paymentStatus).toBe('paid')
    expect((await ramesh.api.get(`/lots/${lotId}`)).json.status).toBe('paid')
    expect((await t(admin.api, 'payment', { status: 'refunded' })).json.code).toBe('invalid_state')
  })

  it('shows contact details to the two parties only, and lets the farmer rate once', async () => {
    const d = await ramesh.api.get(`/transactions/${txnId}`)
    expect(d.json.buyer.phone).toBe('+919000000002')
    expect((await baldev.api.get(`/transactions/${txnId}`)).status).toBe(404)
    expect((await fresh.api.get(`/transactions/${txnId}`)).status).toBe(404)
    expect((await ramesh.api.post(`/transactions/${txnId}/rating`, { stars: 5 })).status).toBe(201)
    expect((await ramesh.api.post(`/transactions/${txnId}/rating`, { stars: 1 })).json.code).toBe('already_rated')
    const b = await ramesh.api.get('/buyers')
    expect(b.json.items.find((x: any) => x.name.startsWith('Malwa')).rating).toBeCloseTo(4.6, 1)
  })

  it('grievances: parties raise, scoped staff resolve', async () => {
    const g = await ramesh.api.post('/grievances', { transactionId: txnId, message: 'Weighing slip differs by 2 quintals' })
    expect(g.status).toBe(201)
    expect((await baldev.api.post('/grievances', { transactionId: txnId, message: 'Not my deal at all' })).status).toBe(404)
    expect((await ramesh.api.patch(`/grievances/${g.json.id}`, { status: 'resolved', resolutionNote: 'ok' })).status).toBe(403)
    expect((await staff.api.patch(`/grievances/${g.json.id}`, { status: 'resolved' })).json.code).toBe('resolution_note_required')
    const res = await admin.api.patch(`/grievances/${g.json.id}`, { status: 'resolved', resolutionNote: 'Reweighed, difference refunded' })
    expect(res.json.status).toBe('resolved')
    expect((await admin.api.patch(`/grievances/${g.json.id}`, { status: 'in_review' })).status).toBe(409)
  })

  it('audit trail captured the deal', async () => {
    const a = await admin.api.get(`/admin/audit?entity=offer&entityId=${offerB}`)
    expect(a.json.items.map((x: any) => x.action)).toEqual(expect.arrayContaining(['offer.created', 'offer.accepted']))
    expect((await ramesh.api.get('/admin/audit')).status).toBe(403)
  })
})

describe('concurrency & cancellation', () => {
  it('two simultaneous accepts on one lot: exactly one wins', async () => {
    const lot = (await baldev.api.post('/lots', { cropId: 'soybean', quantity: 10, grade: 'B' })).json.id
    const o1 = (await agro.api.post(`/lots/${lot}/offers`, { price: 4700 })).json.id
    const o2 = (await malwa.api.post(`/lots/${lot}/offers`, { price: 4710 })).json.id
    const [r1, r2] = await Promise.all([baldev.api.post(`/offers/${o1}/accept`), baldev.api.post(`/offers/${o2}/accept`)])
    expect([r1.status, r2.status].sort()).toEqual([200, 409])
    const n = await rows(ctx.h, sql`select count(*)::int n from transactions where lot_id = ${lot}`)
    expect(n[0].n).toBe(1)
  })

  it('cancelling a lot rejects open offers and blocks new ones', async () => {
    const lot = (await baldev.api.post('/lots', { cropId: 'chana', quantity: 5, grade: 'A' })).json.id
    const o = (await agro.api.post(`/lots/${lot}/offers`, { price: 5900 })).json.id
    expect((await baldev.api.post(`/lots/${lot}/cancel`)).json.status).toBe('cancelled')
    expect((await rows(ctx.h, sql`select status from offers where id = ${o}`))[0].status).toBe('rejected')
    expect((await malwa.api.post(`/lots/${lot}/offers`, { price: 5800 })).json.code).toBe('lot_not_listed')
  })

  it('withdraw works for the buyer only; pagination walks all lots without gaps', async () => {
    const lot = (await baldev.api.post('/lots', { cropId: 'mustard', quantity: 7, grade: 'C' })).json.id
    const o = (await agro.api.post(`/lots/${lot}/offers`, { price: 5000 })).json.id
    expect((await malwa.api.post(`/offers/${o}/withdraw`)).status).toBe(404)
    expect((await agro.api.post(`/offers/${o}/withdraw`)).json.status).toBe('withdrawn')
    const seen = new Set<string>(); let cursor = ''; let pages = 0
    do {
      const p = await baldev.api.get(`/lots?limit=2${cursor ? `&cursor=${cursor}` : ''}`)
      for (const l of p.json.items) { expect(seen.has(l.id)).toBe(false); seen.add(l.id) }
      cursor = p.json.nextCursor ?? ''; pages++
    } while (cursor && pages < 20)
    const total = await rows(ctx.h, sql`select count(*)::int n from lots l join users u on u.id = l.farmer_id where u.phone = '+919414078219'`)
    expect(seen.size).toBe(total[0].n)
  })
})
