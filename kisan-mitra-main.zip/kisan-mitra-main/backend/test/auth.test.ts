import { afterAll, beforeAll, describe, expect, it } from 'vitest'
import { client, login, setup, type Ctx } from './helpers'

let ctx: Ctx
beforeAll(async () => { ctx = await setup() })
afterAll(() => ctx.stop())

describe('phone OTP auth', () => {
  it('requires registration for a new number, without burning the code', async () => {
    const api = client(ctx.app)
    expect((await api.post('/auth/otp', { phone: '98765 43210' })).status).toBe(200)
    const first = await api.post('/auth/verify', { phone: '+919876543210', code: '123456' })
    expect(first.status).toBe(422); expect(first.json.code).toBe('registration_required')
    const ok = await api.post('/auth/verify', { phone: '+919876543210', code: '123456', registration: { role: 'farmer', name: 'Test Kisan', village: 'Pipliya' } })
    expect(ok.status).toBe(200)
    expect(ok.json.user).toMatchObject({ role: 'farmer', phone: '+919876543210' })
    const me = await client(ctx.app, ok.json.accessToken).get('/me')
    expect(me.json.name).toBe('Test Kisan')
  })

  it('rejects bad phones and wrong codes, then locks after max attempts', async () => {
    const api = client(ctx.app)
    expect((await api.post('/auth/otp', { phone: '12345' })).json.code).toBe('invalid_phone')
    await api.post('/auth/otp', { phone: '+919811111111' })
    for (let i = 0; i < 5; i++) expect((await api.post('/auth/verify', { phone: '+919811111111', code: '000000' })).json.code).toBe('otp_invalid')
    expect((await api.post('/auth/verify', { phone: '+919811111111', code: '123456' })).json.code).toBe('otp_locked')
  })

  it('limits OTP requests per phone per hour', async () => {
    const api = client(ctx.app); let last = 200
    for (let i = 0; i < 6; i++) last = (await api.post('/auth/otp', { phone: '+919822222222' })).status
    expect(last).toBe(429)
  })

  it('rotates refresh tokens and revokes the family on reuse', async () => {
    const s = await login(ctx, '+919833333333', { role: 'buyer', name: 'Buyer One', businessName: 'Buyer Co', type: 'trader' })
    const api = client(ctx.app)
    const r1 = await api.post('/auth/refresh', { refreshToken: s.refreshToken })
    expect(r1.status).toBe(200)
    const reuse = await api.post('/auth/refresh', { refreshToken: s.refreshToken })
    expect(reuse.status).toBe(401); expect(reuse.json.code).toBe('refresh_reused')
    expect((await api.post('/auth/refresh', { refreshToken: r1.json.refreshToken })).status).toBe(401) // family revoked
  })

  it('protects routes and enforces suspension immediately', async () => {
    expect((await client(ctx.app).get('/lots')).status).toBe(401)
    expect((await client(ctx.app, 'garbage').get('/lots')).status).toBe(401)
    const s = await login(ctx, '+919844444444', { role: 'farmer', name: 'Soon Suspended', village: 'Test Village' })
    expect((await s.api.get('/lots')).status).toBe(200)
    await ctx.h.execRaw(`UPDATE users SET status='suspended' WHERE phone='+919844444444'`)
    expect((await s.api.get('/lots')).status).toBe(401)
  })
})
